<?php
/**
 * Plugin Name: Smart CRM Lite
 * Description: Lightweight lead and job management for service businesses. Syncs with ActiveCampaign for marketing automation. Integrates with Smart Forms, Smart Chat, ServiceM8, Vapi, and Google Calendar.
 * Version: 3.0.0
 * Author: Midland Floor Care
 * Author URI: https://midlandfloors.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: smart-crm-pro
 * Domain Path: /languages
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Requires Plugins: smart-forms-for-contractors
 * Tested up to: 6.7
 * Update URI: false
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'SCRM_PRO_VERSION', '3.0.0' );
define( 'SCRM_PRO_DIR', plugin_dir_path( __FILE__ ) );
define( 'SCRM_PRO_URL', plugin_dir_url( __FILE__ ) );

add_action( 'plugins_loaded', 'smart_crm_pro_init', 25 );

function smart_crm_pro_init() {
    load_plugin_textdomain( 'smart-crm-pro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

    if ( ! defined( 'SFCO_VERSION' ) ) {
        add_action( 'admin_notices', function() {
            echo '<div class="notice notice-error"><p><strong>' . esc_html__( 'Smart CRM PRO requires Smart Forms for Contractors to be installed and active.', 'smart-crm-pro' ) . '</strong></p></div>';
        });
        return;
    }

    require_once SCRM_PRO_DIR . 'includes/class-admin.php';
    require_once SCRM_PRO_DIR . 'includes/class-scrm-pro-activecampaign.php';
    require_once SCRM_PRO_DIR . 'includes/class-scrm-pro-tags.php';
    require_once SCRM_PRO_DIR . 'includes/class-scrm-pro-servicem8.php';
    require_once SCRM_PRO_DIR . 'includes/class-scrm-pro-floor-care-plan.php';
    require_once SCRM_PRO_DIR . 'includes/class-scrm-pro-smart-forms-bridge.php';
    require_once SCRM_PRO_DIR . 'includes/class-scrm-pro-vapi.php';
    require_once SCRM_PRO_DIR . 'includes/class-scrm-pro-visit-draft.php';
    require_once SCRM_PRO_DIR . 'includes/class-scrm-pro-ops-notifications.php';
    require_once SCRM_PRO_DIR . 'includes/class-scrm-chat-forms-bridge.php';
    require_once SCRM_PRO_DIR . 'includes/class-scrm-pro-settings.php';

    // Each module's class file self-instantiates its singleton at load
    // time. Instantiating again here would create duplicate admin_menu
    // hooks and double-render the page. The bootstrap only owns Admin
    // (which has no singleton accessor).
    new SCRM_Pro_Admin();
}

register_deactivation_hook( __FILE__, 'scrm_pro_deactivate' );
function scrm_pro_deactivate() {
    // Clear the ServiceM8 status poller (every-10-min cron).
    wp_clear_scheduled_hook( 'scrm_pro_sm8_poll_jobs' );
    // Clear any per-lead follow-up reminders scheduled by the Smart Forms bridge.
    // wp_unschedule_hook clears all instances regardless of the lead_id arg.
    wp_unschedule_hook( 'scrm_pro_follow_up_reminder' );
}
