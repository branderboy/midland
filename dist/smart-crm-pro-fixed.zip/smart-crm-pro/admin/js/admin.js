jQuery(document).ready(function($) {
    'use strict';

    // Test-connection buttons (Settings hub).
    // The campaign launch/delete actions previously referenced here
    // (scrm_launch_campaign, scrm_delete_campaign) had no PHP handlers
    // and were causing silent 400 errors on every click. Removed.

    // Inline status messages for save/test feedback.
    $(document).on('click', '[data-scrm-test]', function() {
        var $btn         = $(this);
        var integration  = $btn.data('scrm-test');
        var nonce        = $btn.data('nonce');
        var $result      = $btn.closest('.scrm-test-bar').find('.scrm-test-result');
        if (!$result.length) $result = $btn.next('.scrm-test-result');

        $result.text('Testing\u2026').css('color', '#6b7280');
        $btn.prop('disabled', true);

        $.post(scrmProData.ajaxurl, {
            action:      'scrm_test_connection',
            integration: integration,
            _ajax_nonce: nonce
        }).done(function(res) {
            $btn.prop('disabled', false);
            if (res && res.success) {
                $result.text('\u2713 ' + ((res.data && res.data.message) || 'OK')).css('color', '#2F8137');
            } else {
                var msg = (res && res.data && res.data.message) || 'Failed';
                $result.text('\u2717 ' + msg).css('color', '#7a1d1d');
            }
        }).fail(function() {
            $btn.prop('disabled', false);
            $result.text('\u2717 Network error').css('color', '#7a1d1d');
        });
    });
});
