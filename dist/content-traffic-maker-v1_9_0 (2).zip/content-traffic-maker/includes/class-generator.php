<?php
/**
 * Video brief generator — 6 videos: 3 per segment (SEO + Offer + Viral).
 *
 * Changes vs 1.8.0:
 * - Default model: sonar-pro (better real-time results).
 * - max_tokens raised to 7000 to prevent truncation on 6-video briefs.
 * - response_format JSON-schema injected so Perplexity returns valid JSON
 *   even when the response is long; eliminates extract_json() fragility.
 * - search_results / citations from the API response are read and injected
 *   into each video's *_example_url, overriding the LLM-supplied URL when
 *   a real search result is available.
 * - Segment labels / audiences / services come from settings (configurable)
 *   instead of being hard-coded.
 *
 * @package ContentTrafficMaker
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CTM_Generator {

    const ENDPOINT = 'https://api.perplexity.ai/chat/completions';

    /**
     * All JSON keys the brief must contain.
     * Segments use generic seg_a / seg_b prefixes that are mapped to the
     * user's configured labels (com/res) in the prompt and display layer.
     * The key names themselves stay stable so stored briefs never break.
     */
    public static function fields() {
        return array(
            // ── SEGMENT A (default: Commercial) ────────────────────
            'com_seo_keyword',
            'com_seo_search_intent',
            'com_seo_video_title',
            'com_seo_hook',
            'com_seo_cta',
            'com_seo_difficulty',
            'com_seo_priority',
            'com_seo_example_title',
            'com_seo_example_url',

            'com_offer_video_title',
            'com_offer_name',
            'com_offer_audience',
            'com_offer_hook',
            'com_offer_cta',
            'com_offer_priority',
            'com_offer_example_title',
            'com_offer_example_url',

            'com_viral_video_title',
            'com_viral_trending_format',
            'com_viral_concept',
            'com_viral_opening_shot',
            'com_viral_trend_reason',
            'com_viral_cta',
            'com_viral_priority',
            'com_viral_example_title',
            'com_viral_example_url',

            // ── SEGMENT B (default: Residential) ───────────────────
            'res_seo_keyword',
            'res_seo_search_intent',
            'res_seo_video_title',
            'res_seo_hook',
            'res_seo_cta',
            'res_seo_difficulty',
            'res_seo_priority',
            'res_seo_example_title',
            'res_seo_example_url',

            'res_offer_video_title',
            'res_offer_name',
            'res_offer_audience',
            'res_offer_hook',
            'res_offer_cta',
            'res_offer_priority',
            'res_offer_example_title',
            'res_offer_example_url',

            'res_viral_video_title',
            'res_viral_trending_format',
            'res_viral_concept',
            'res_viral_opening_shot',
            'res_viral_trend_reason',
            'res_viral_cta',
            'res_viral_priority',
            'res_viral_example_title',
            'res_viral_example_url',

            'brief_date',
        );
    }

    /**
     * The six *_example_url keys — candidates for search-result injection.
     */
    private static function url_keys() {
        return array(
            'com_seo_example_url',
            'com_offer_example_url',
            'com_viral_example_url',
            'res_seo_example_url',
            'res_offer_example_url',
            'res_viral_example_url',
        );
    }

    /**
     * Generate and return a sanitised brief array, or WP_Error on failure.
     *
     * @param  array $settings Decrypted settings from CTM_DB::get_settings().
     * @return array|WP_Error
     */
    public static function generate( $settings ) {
        $api_key = trim( (string) ( $settings['api_key'] ?? '' ) );
        if ( '' === $api_key ) {
            return new WP_Error( 'ctm_no_key', __( 'Add your Perplexity API key in settings first.', 'content-traffic-maker' ) );
        }

        $model = sanitize_text_field( $settings['model'] ?? 'sonar-pro' ) ?: 'sonar-pro';

        $body = array(
            'model'       => $model,
            'temperature' => 0.4,
            'max_tokens'  => 7000,
            'messages'    => array(
                array( 'role' => 'system', 'content' => self::system_prompt( $settings ) ),
                array( 'role' => 'user',   'content' => self::build_prompt( $settings ) ),
            ),
            // JSON-schema response_format: Perplexity will return valid JSON
            // matching this shape, stopping hallucinated keys and truncated output.
            'response_format' => array(
                'type'        => 'json_schema',
                'json_schema' => array(
                    'name'   => 'video_brief',
                    'strict' => true,
                    'schema' => self::json_schema(),
                ),
            ),
        );

        $response = wp_remote_post( self::ENDPOINT, array(
            'timeout' => 90,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            ),
            'body' => wp_json_encode( $body ),
        ) );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $raw  = (string) wp_remote_retrieve_body( $response );
        $data = json_decode( $raw, true );

        if ( 200 !== $code ) {
            $msg = is_array( $data ) && ! empty( $data['error']['message'] )
                ? $data['error']['message']
                : sprintf( __( 'Perplexity returned HTTP %d.', 'content-traffic-maker' ), $code );
            return new WP_Error( 'ctm_api_error', $msg );
        }

        $content = (string) ( $data['choices'][0]['message']['content'] ?? '' );
        $brief   = self::extract_json( $content );
        if ( ! is_array( $brief ) ) {
            return new WP_Error( 'ctm_bad_json', __( 'Perplexity did not return valid JSON. Try again.', 'content-traffic-maker' ) );
        }

        // ── Inject search_results / citations URLs ─────────────────────────
        // Prefer a real Perplexity search-result URL over whatever the LLM
        // wrote into the *_example_url fields — those are often hallucinated.
        $brief = self::inject_search_urls( $brief, $data );

        return self::sanitize_brief( $brief );
    }

    // ── Search-result URL injection ────────────────────────────────────────────

    /**
     * Walk the Perplexity response for search_results / citations and push
     * those verified URLs into the six *_example_url fields, replacing any
     * LLM-generated URL only when a real result is available.
     *
     * Perplexity may surface results under:
     *   $data['search_results']   — array of {title, url, …} objects
     *   $data['citations']        — array of URL strings
     *
     * We distribute the results sequentially across the six url slots.
     * The LLM-supplied URL is kept as-is when we run out of real results.
     *
     * @param  array $brief Decoded brief array.
     * @param  array $data  Full decoded API response.
     * @return array Brief with URLs potentially overwritten.
     */
    private static function inject_search_urls( array $brief, array $data ) {
        // Collect candidate URLs from both sources.
        $candidates = array();

        if ( ! empty( $data['search_results'] ) && is_array( $data['search_results'] ) ) {
            foreach ( $data['search_results'] as $result ) {
                if ( ! empty( $result['url'] ) && is_string( $result['url'] ) ) {
                    $candidates[] = $result['url'];
                }
            }
        }

        if ( ! empty( $data['citations'] ) && is_array( $data['citations'] ) ) {
            foreach ( $data['citations'] as $citation ) {
                if ( is_string( $citation ) && '' !== trim( $citation ) ) {
                    $candidates[] = $citation;
                }
            }
        }

        // De-duplicate while preserving order.
        $candidates = array_values( array_unique( $candidates ) );

        if ( empty( $candidates ) ) {
            return $brief; // Nothing to inject; keep LLM URLs as-is.
        }

        $url_keys = self::url_keys();
        $idx      = 0;

        foreach ( $url_keys as $key ) {
            if ( ! isset( $candidates[ $idx ] ) ) {
                break; // Ran out of real results — leave remaining LLM URLs intact.
            }
            // Only override if the result looks like a plausible video/content URL.
            $candidate = esc_url_raw( $candidates[ $idx ] );
            if ( '' !== $candidate ) {
                $brief[ $key ] = $candidate;
                $idx++;
            }
        }

        return $brief;
    }

    // ── Prompts ────────────────────────────────────────────────────────────────

    /**
     * System prompt — uses configured segment labels/audiences/services
     * so it adapts to any niche, not just Midland Floors.
     *
     * @param  array $settings
     * @return string
     */
    private static function system_prompt( $settings ) {
        $business  = sanitize_text_field( (string) ( $settings['business_name'] ?? 'Midland Floors' ) );
        $label_a   = sanitize_text_field( (string) ( $settings['segment_a_label'] ?? 'Commercial' ) );
        $aud_a     = sanitize_text_field( (string) ( $settings['segment_a_audience'] ?? '' ) );
        $label_b   = sanitize_text_field( (string) ( $settings['segment_b_label'] ?? 'Residential' ) );
        $aud_b     = sanitize_text_field( (string) ( $settings['segment_b_audience'] ?? '' ) );

        return "You are a social media video strategist for {$business}.

You write for TikTok and YouTube — NOT for blogs or corporate websites.

TWO audiences:
1. {$label_a} — {$aud_a}
2. {$label_b} — {$aud_b}

LANGUAGE RULES (critical):
- Write like a real person talking, not a marketer writing copy.
- NO industry jargon. Use plain everyday words.
- Video titles must sound like real TikTok captions or YouTube titles that get clicks from normal people.
- BAD title: \"VCT Strip and Wax Maintenance for DC Facility Managers\"
- GOOD title: \"This DC Office Floor Hadn't Been Cleaned in 2 Years. Watch What Happened.\"
- BAD hook: \"As a property manager, floor maintenance is critical.\"
- GOOD hook: \"Your tenants notice the floors before anything else.\"
- Offers must feel like real deals, not marketing speak.

EXAMPLES — provide real TikTok or YouTube videos that exist right now. Use your live web search. If you cannot verify a real example, leave the URL empty but still give a realistic title.

Return ONLY valid JSON matching the schema provided. No prose, no markdown, no code fences.";
    }

    /**
     * User prompt — all field definitions and segment context.
     *
     * @param  array $settings
     * @return string
     */
    public static function build_prompt( $settings ) {
        $business  = sanitize_text_field( (string) ( $settings['business_name'] ?? 'Midland Floors' ) );
        $city      = sanitize_text_field( (string) ( $settings['target_city']   ?? 'Washington' ) );
        $state     = sanitize_text_field( (string) ( $settings['target_state']  ?? 'DC' ) );
        $label_a   = sanitize_text_field( (string) ( $settings['segment_a_label']    ?? 'Commercial' ) );
        $aud_a     = sanitize_text_field( (string) ( $settings['segment_a_audience'] ?? 'DC office building managers, property managers' ) );
        $svc_a     = sanitize_text_field( (string) ( $settings['segment_a_services'] ?? 'office floor cleaning, tile cleaning, waxing' ) );
        $label_b   = sanitize_text_field( (string) ( $settings['segment_b_label']    ?? 'Residential' ) );
        $aud_b     = sanitize_text_field( (string) ( $settings['segment_b_audience'] ?? 'DC homeowners, renters, people preparing to sell' ) );
        $svc_b     = sanitize_text_field( (string) ( $settings['segment_b_services'] ?? 'carpet cleaning, carpet installation, home floor cleaning' ) );
        $today     = gmdate( 'F j, Y' );

        return "Today is {$today}. Business: {$business}, {$city} {$state}.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
{$label_a} SEGMENT (com_* keys)
Audience: {$aud_a}
Services: {$svc_a}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[{$label_a} SEO VIDEO]
com_seo_keyword       — exact phrase someone types on YouTube/Google (plain words, not jargon)
com_seo_search_intent — one sentence: who is this person and what problem are they trying to solve
com_seo_video_title   — write like a YouTube title that gets clicks from normal people. Simple. Curious. Real.
com_seo_hook          — first 8 words spoken on camera. Stops the scroll.
com_seo_cta           — one specific action to take (call, DM, book online)
com_seo_difficulty    — Easy / Medium / Hard to rank for
com_seo_priority      — integer 1-10
com_seo_example_title — title of a REAL video on TikTok or YouTube doing this type of content right now
com_seo_example_url   — verified URL, or empty string

[{$label_a} OFFER VIDEO]
com_offer_video_title  — plain social-media-style title
com_offer_name         — the actual offer in plain words
com_offer_audience     — exact person this targets
com_offer_hook         — opening line that creates urgency in plain language
com_offer_cta          — specific CTA
com_offer_priority     — integer 1-10
com_offer_example_title — real example of a service offer video performing well on TikTok/YouTube
com_offer_example_url   — verified URL, or empty string

[{$label_a} VIRAL VIDEO]
com_viral_video_title   — write the caption/title like it would go viral on TikTok. Emotional. Relatable.
com_viral_trending_format — name the real trend this uses — use web search to confirm active RIGHT NOW
com_viral_concept       — what happens in the video in plain words
com_viral_opening_shot  — describe the exact first frame in plain words
com_viral_trend_reason  — why this format is working right now — name real evidence
com_viral_cta           — specific CTA
com_viral_priority      — integer 1-10
com_viral_example_title — real viral video using this format right now
com_viral_example_url   — verified URL, or empty string

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
{$label_b} SEGMENT (res_* keys)
Audience: {$aud_b}
Services: {$svc_b}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[{$label_b} SEO VIDEO]
res_seo_keyword       — exact phrase
res_seo_search_intent — one sentence: who is searching and why
res_seo_video_title   — plain YouTube/TikTok title normal people click
res_seo_hook          — first 8 words on camera
res_seo_cta           — specific CTA
res_seo_difficulty    — Easy / Medium / Hard
res_seo_priority      — integer 1-10
res_seo_example_title — real example video performing on this topic
res_seo_example_url   — verified URL, or empty string

[{$label_b} OFFER VIDEO]
res_offer_video_title  — plain social title for the offer video
res_offer_name         — the actual offer in plain language
res_offer_audience     — exact person
res_offer_hook         — opening line, plain language, urgency or stakes
res_offer_cta          — specific CTA
res_offer_priority     — integer 1-10
res_offer_example_title — real example of a home service offer video
res_offer_example_url   — verified URL, or empty string

[{$label_b} VIRAL VIDEO]
res_viral_video_title   — TikTok-style caption. Relatable. Stops the scroll.
res_viral_trending_format — real trend format active RIGHT NOW
res_viral_concept       — what happens in plain words
res_viral_opening_shot  — describe the exact first frame
res_viral_trend_reason  — real evidence this format is working now
res_viral_cta           — specific CTA
res_viral_priority      — integer 1-10
res_viral_example_title — real viral video using this format
res_viral_example_url   — verified URL, or empty string

brief_date: \"{$today}\"";
    }

    // ── JSON schema for response_format ───────────────────────────────────────

    /**
     * JSON Schema object passed to response_format so Perplexity is
     * constrained to return exactly the fields we need.
     *
     * All string fields are type:string; priority fields are type:integer.
     *
     * @return array
     */
    private static function json_schema() {
        $string_keys = array();
        $int_keys    = array(
            'com_seo_priority', 'com_offer_priority', 'com_viral_priority',
            'res_seo_priority', 'res_offer_priority', 'res_viral_priority',
        );

        foreach ( self::fields() as $key ) {
            if ( in_array( $key, $int_keys, true ) ) {
                continue; // Added as integer below.
            }
            $string_keys[] = $key;
        }

        $properties = array();
        foreach ( $string_keys as $k ) {
            $properties[ $k ] = array( 'type' => 'string' );
        }
        foreach ( $int_keys as $k ) {
            $properties[ $k ] = array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 10 );
        }

        return array(
            'type'                 => 'object',
            'properties'           => $properties,
            'required'             => array_values( self::fields() ),
            'additionalProperties' => false,
        );
    }

    // ── JSON extraction (fallback for models that ignore response_format) ──────

    private static function extract_json( $content ) {
        $content = trim( $content );
        $decoded = json_decode( $content, true );
        if ( is_array( $decoded ) ) {
            return $decoded;
        }
        // Strip code fences if model disobeyed the instruction.
        $content = preg_replace( '/^```(?:json)?|```$/m', '', $content );
        $start   = strpos( $content, '{' );
        $end     = strrpos( $content, '}' );
        if ( false !== $start && false !== $end && $end > $start ) {
            $decoded = json_decode( substr( $content, $start, $end - $start + 1 ), true );
            if ( is_array( $decoded ) ) {
                return $decoded;
            }
        }
        return null;
    }

    // ── Sanitisation ───────────────────────────────────────────────────────────

    private static function sanitize_brief( $brief ) {
        $int_keys = array(
            'com_seo_priority', 'com_offer_priority', 'com_viral_priority',
            'res_seo_priority', 'res_offer_priority', 'res_viral_priority',
        );
        $url_keys = self::url_keys();
        $clean    = array();

        foreach ( self::fields() as $key ) {
            $val = $brief[ $key ] ?? '';
            if ( in_array( $key, $int_keys, true ) ) {
                $clean[ $key ] = max( 1, min( 10, (int) $val ) );
            } elseif ( in_array( $key, $url_keys, true ) ) {
                $clean[ $key ] = esc_url_raw( is_scalar( $val ) ? (string) $val : '' );
            } else {
                $clean[ $key ] = sanitize_textarea_field( is_scalar( $val ) ? (string) $val : wp_json_encode( $val ) );
            }
        }

        return $clean;
    }
}
