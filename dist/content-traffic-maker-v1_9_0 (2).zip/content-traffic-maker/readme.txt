=== Midland Floors Video Brief ===
Contributors: midland
Tags: video marketing, tiktok, youtube, seo, content strategy, perplexity
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.9.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Daily SEO keyword, offer, and viral video ideas — pulled live from Perplexity and delivered to your client via email.

== Description ==

**Midland Floors Video Brief** generates a daily (or weekly) video brief for two configurable audience segments, each containing three videos:

* **SEO Video** — keyword, search intent, title, hook, CTA, difficulty rating.
* **Offer Video** — specific offer, target audience, hook, CTA.
* **Viral Video** — trending format (verified live via Perplexity web search), concept, opening shot, why it works, CTA.

Each video includes a real TikTok or YouTube example URL sourced from Perplexity's live search results — not hallucinated by the model.

**What makes it different:**

* Uses `response_format` JSON-schema to prevent truncation and format drift.
* Injects real URLs from Perplexity's `search_results` / `citations` into each video's example field.
* Both audience segments (labels, audience description, services) are fully configurable — works for any niche, not just floor cleaning.
* API keys stored AES-256 encrypted at rest (base64 fallback with admin warning if OpenSSL unavailable).
* Delivered as both HTML and plain text via Resend (or wp_mail fallback).

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`.
2. Activate **Midland Floors Video Brief** through the *Plugins* menu.
3. Go to **Video Brief → Settings** and enter your Perplexity API key.
4. Configure your audience segments and click **Save Settings**.
5. Hit **⚡ Generate Video Brief** to create your first brief.

== Frequently Asked Questions ==

= Which Perplexity model should I use? =

`sonar-pro` (the default) gives the best real-time web search results and is recommended. `sonar` is faster and cheaper if you don't need cutting-edge results.

= Why are some example URLs empty? =

Perplexity may not always return a verified URL for every video type in a single request. The brief will still contain a realistic example title. Re-generating usually fills more URLs.

= How do I delete all data on uninstall? =

Set `wp option update ctm_purge_on_uninstall 1` via WP-CLI before deleting the plugin. This drops the briefs table and all `ctm_` options.

= Are my API keys safe? =

Yes — keys are encrypted with AES-256-CBC before being written to the database. An admin notice appears if your server lacks OpenSSL, in which case base64 obfuscation is used instead.

== Changelog ==

= 1.9.0 =
* Added `class-crypto.php`: AES-256-CBC at-rest encryption for Perplexity and Resend API keys.
* Generator: `response_format` JSON-schema injected to prevent truncation / format drift.
* Generator: `max_tokens` raised from 3 500 to 7 000.
* Generator: default model changed from `sonar` to `sonar-pro`.
* Generator: `search_results` / `citations` from API response injected into `*_example_url` fields; LLM-supplied URL kept only as fallback.
* Audience segments (label, sub-label, audience, services) now fully configurable in settings — not hard-coded to Midland Floors.
* Admin: encryption status indicator on API key fields; warning banner when AES is unavailable.
* Admin: `render_brief_card` uses configured segment labels for section headers.
* Email: `render_html` and `render_text` use configured business name, city, and segment labels.
* Added `uninstall.php` with opt-in data purge.
* Added `readme.txt`.
* Added `Update URI: false` to prevent wp.org update hijacking.
* Added `Domain Path: /languages` and `.pot` file placeholder.

= 1.8.1 =
* Fixed `activate()` not registering `cron_schedules` filter before `reschedule()` — `weekly` events silently failed to schedule on first activation.
* Fixed `first_run()` double-applying `gmt_offset` — briefs fired immediately instead of at the configured send time for UTC− sites.

= 1.8.0 =
* Initial release.
