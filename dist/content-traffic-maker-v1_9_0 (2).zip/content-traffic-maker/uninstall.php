<?php
/**
 * Uninstall Content Traffic Maker (Midland Floors Video Brief).
 *
 * Runtime state (last-sent date, cron event) is always removed.
 * Settings and stored briefs are preserved by default so a reinstall
 * doesn't lose your API keys or brief history.
 *
 * To do a full hard reset — dropping the briefs table and all ctm_
 * options — set the option `ctm_purge_on_uninstall` to '1' before
 * deleting the plugin, or define the constant CTM_PURGE_ON_UNINSTALL.
 *
 * Example (WP-CLI):
 *   wp option update ctm_purge_on_uninstall 1
 *
 * @package ContentTrafficMaker
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

$purge = get_option( 'ctm_purge_on_uninstall', '0' ) === '1'
    || ( defined( 'CTM_PURGE_ON_UNINSTALL' ) && CTM_PURGE_ON_UNINSTALL );

/* ------------------------------------------------------------------ *
 * Always-clean: cron event and last-sent date tracker.               *
 * ------------------------------------------------------------------ */
if ( function_exists( 'wp_clear_scheduled_hook' ) ) {
    wp_clear_scheduled_hook( 'ctm_send_brief' );
}
delete_option( 'ctm_last_sent_date' );
delete_option( 'ctm_db_version' );

/* ------------------------------------------------------------------ *
 * Opt-in hard reset: all ctm_ options + the briefs table.           *
 * ------------------------------------------------------------------ */
if ( $purge ) {

    $options = $wpdb->get_col(
        "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'ctm\_%'"
    ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.NotPrepared

    foreach ( (array) $options as $option ) {
        delete_option( $option );
    }

    $table = $wpdb->prefix . 'content_traffic_maker_briefs';
    $wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.NotPrepared
}
