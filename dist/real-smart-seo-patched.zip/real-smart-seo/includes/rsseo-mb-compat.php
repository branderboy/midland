<?php
/**
 * Multibyte string compatibility shims.
 *
 * PHP's mbstring extension is not guaranteed on every host. These thin
 * wrappers fall back to the byte-counting equivalents when mbstring is
 * absent. All plugin code that needs mb_strlen / mb_substr must call these
 * helpers so there is exactly one place to maintain the fallback logic.
 *
 * Behaviour difference without mbstring: multi-byte characters (e.g. emoji,
 * accented letters) are measured and sliced by byte count rather than
 * codepoint count. For the plugin's use cases — length-capping truncation
 * and short-string filtering — this is an acceptable degradation; the
 * output is still correct plain text, just possibly one or two characters
 * shorter than intended on non-ASCII inputs.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'rsseo_strlen' ) ) {
    /**
     * Multibyte-safe strlen. Falls back to strlen() when mbstring is absent.
     *
     * @param string $str
     * @return int Character (or byte) count.
     */
    function rsseo_strlen( $str ) {
        return function_exists( 'mb_strlen' ) ? mb_strlen( (string) $str ) : strlen( (string) $str );
    }
}

if ( ! function_exists( 'rsseo_substr' ) ) {
    /**
     * Multibyte-safe substr. Falls back to substr() when mbstring is absent.
     *
     * @param string   $str
     * @param int      $start
     * @param int|null $length
     * @return string
     */
    function rsseo_substr( $str, $start, $length = null ) {
        $str = (string) $str;
        if ( function_exists( 'mb_substr' ) ) {
            return null === $length ? mb_substr( $str, $start ) : mb_substr( $str, $start, $length );
        }
        return null === $length ? substr( $str, $start ) : substr( $str, $start, $length );
    }
}
