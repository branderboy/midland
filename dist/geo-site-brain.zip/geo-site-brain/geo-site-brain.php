<?php
/**
 * Plugin Name: GEO Site Brain
 * Description: Turns your WordPress content into an AI-readable knowledge base using OpenAI embeddings (stored in Neon pgvector, with a local fallback). Scores every page for GEO/AEO/SEO, generates recommendations, and answers questions in an admin chat using retrieval first.
 * Version: 2.4.1
 * Author: Midland Floor Care
 * Author URI: https://midlandfloors.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: geo-site-brain
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Tested up to: 6.7
 * Update URI: false
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'GSB_VERSION', '2.4.1' );
define( 'GSB_PLUGIN_FILE', __FILE__ );
define( 'GSB_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'GSB_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Embedding model + dimensions. text-embedding-3-small returns 1536 dims and is
// cheap; change both together if you switch models.
define( 'GSB_EMBED_MODEL', 'text-embedding-3-small' );
define( 'GSB_EMBED_DIM', 1536 );

// Cron hooks.
define( 'GSB_CRON_REINDEX', 'gsb_weekly_reindex' );
define( 'GSB_CRON_CONTINUE', 'gsb_reindex_continue' );
define( 'GSB_CRON_POST', 'gsb_index_post' );
// The email digest has its own weekly cron so it fires independently of the
// weekly reindex (a user can enable the digest while leaving reindex off).
define( 'GSB_CRON_DIGEST', 'gsb_weekly_digest' );

/**
 * Main plugin bootstrap. Singleton, mirrors the other Midland plugins.
 */
final class GSB_Plugin {

	/** @var GSB_Plugin|null */
	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->load_dependencies();
		$this->init_hooks();
	}

	private function load_dependencies() {
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-database.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-logger.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-settings.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-openai.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-ai-providers.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-vector-store.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-scanner.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-indexer.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-scorer.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-entities.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-knowledge-graph.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-visibility.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-fixes.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-competitors.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-monitor.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-webhooks.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-rest.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-reports.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-agent.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-view-helpers.php';
		require_once GSB_PLUGIN_DIR . 'includes/class-gsb-admin.php';
	}

	private function init_hooks() {
		register_activation_hook( GSB_PLUGIN_FILE, array( $this, 'activate' ) );
		register_deactivation_hook( GSB_PLUGIN_FILE, array( $this, 'deactivate' ) );

		add_action( 'init', array( $this, 'load_textdomain' ) );

		// Self-healing schema check on admin load (cheap option compare).
		add_action( 'admin_init', array( 'GSB_Database', 'maybe_upgrade' ) );

		// One-time: seed the Midland business identity if it was never configured.
		add_action( 'admin_init', array( $this, 'maybe_seed_identity' ) );

		// Admin UI + AJAX.
		GSB_Admin::get_instance();

		// Content lifecycle + cron indexing hooks.
		GSB_Indexer::get_instance()->register_hooks();

		// Weekly email digest cron (independent of the reindex schedule).
		GSB_Monitor::register_hooks();

		// Front-end: output any structured data created from the Fix Queue.
		add_action( 'wp_head', array( 'GSB_Fixes', 'render_head' ), 20 );

		// Read-only REST API for external tools.
		add_action( 'rest_api_init', array( 'GSB_Rest', 'register_routes' ) );
	}

	public function load_textdomain() {
		load_plugin_textdomain( 'geo-site-brain', false, dirname( plugin_basename( GSB_PLUGIN_FILE ) ) . '/languages' );
	}

	public function activate() {
		GSB_Database::install();
		GSB_Settings::set_defaults();

		// Only schedule the weekly reindex if the setting is on (default: 1).
		// Checking after set_defaults() so the option always exists.
		if ( (int) GSB_Settings::get( 'weekly_reindex', 1 ) && ! wp_next_scheduled( GSB_CRON_REINDEX ) ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, 'weekly', GSB_CRON_REINDEX );
		}

		// Schedule the email digest on its own weekly cron when enabled.
		GSB_Monitor::sync_digest_cron( (int) GSB_Settings::get( 'enable_digest', 0 ) );
	}

	/**
	 * One-time: fill the business identity (name, locations, services) with the
	 * Midland Floor Care defaults if it was never set, so GEO/AEO scoring and the
	 * knowledge graph have real data. Guarded so it runs only once.
	 */
	public function maybe_seed_identity() {
		if ( get_option( 'gsb_identity_seeded' ) ) {
			return;
		}
		$defaults = GSB_Settings::defaults();
		foreach ( array( 'business_name', 'business_locations', 'core_services' ) as $key ) {
			if ( '' === trim( (string) GSB_Settings::get( $key, '' ) ) ) {
				GSB_Settings::set( $key, $defaults[ $key ] );
			}
		}
		update_option( 'gsb_identity_seeded', 1 );
	}

	public function deactivate() {
		wp_clear_scheduled_hook( GSB_CRON_REINDEX );
		wp_clear_scheduled_hook( GSB_CRON_CONTINUE );
		// Clear any pending single-post index events queued by on_save_post.
		wp_clear_scheduled_hook( GSB_CRON_POST );
		wp_clear_scheduled_hook( GSB_CRON_DIGEST );
	}
}

/**
 * Register a "weekly" cron schedule if WordPress doesn't already have one.
 */
add_filter( 'cron_schedules', function ( $schedules ) {
	if ( ! isset( $schedules['weekly'] ) ) {
		$schedules['weekly'] = array(
			'interval' => WEEK_IN_SECONDS,
			'display'  => __( 'Once Weekly', 'geo-site-brain' ),
		);
	}
	return $schedules;
} );

add_action( 'plugins_loaded', array( 'GSB_Plugin', 'get_instance' ) );
