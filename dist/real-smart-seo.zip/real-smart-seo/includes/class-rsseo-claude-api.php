<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class RSSEO_Claude_API {

    const API_URL     = 'https://api.anthropic.com/v1/messages';
    const API_VERSION = '2023-06-01';
    const MAX_RETRIES = 3;

    const PRICING = array(
        'claude-sonnet-4-6'            => array( 'input' => 3.00,  'output' => 15.00 ),
        'claude-sonnet-4-20250514'     => array( 'input' => 3.00,  'output' => 15.00 ),
        'claude-opus-4-6'              => array( 'input' => 15.00, 'output' => 75.00 ),
        'claude-opus-4-20250514'       => array( 'input' => 15.00, 'output' => 75.00 ),
        'claude-haiku-4-5-20251001'    => array( 'input' => 0.80,  'output' => 4.00  ),
    );

    /**
     * Send a prompt to Claude and return the response text.
     *
     * @param string   $prompt   The user prompt.
     * @param int|null $scan_id  Scan ID for logging.
     * @return string|WP_Error
     */
    public static function ask( $prompt, $scan_id = null ) {
        $api_key = RSSEO_Settings::get_api_key();
        if ( empty( $api_key ) ) {
            return new WP_Error( 'no_api_key', __( 'Anthropic API key is not configured. Go to Real Smart SEO → Settings to add your key.', 'real-smart-seo' ) );
        }

        $model      = RSSEO_Settings::get_model();
        $max_tokens = RSSEO_Settings::get_max_tokens();

        $body = array(
            'model'      => $model,
            'max_tokens' => $max_tokens,
            'messages'   => array(
                array( 'role' => 'user', 'content' => $prompt ),
            ),
        );

        $retry = 0;
        $response = null;

        while ( $retry <= self::MAX_RETRIES ) {
            $response = wp_remote_post( self::API_URL, array(
                'timeout' => 120,
                'headers' => array(
                    'x-api-key'        => $api_key,
                    'anthropic-version' => self::API_VERSION,
                    'content-type'      => 'application/json',
                ),
                'body' => wp_json_encode( $body ),
            ) );

            if ( is_wp_error( $response ) ) {
                return $response;
            }

            $code = wp_remote_retrieve_response_code( $response );

            if ( 429 === $code && $retry < self::MAX_RETRIES ) {
                $retry++;
                sleep( pow( 2, $retry ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.sleep
                continue;
            }
            if ( 500 === $code && $retry < self::MAX_RETRIES ) {
                $retry++;
                sleep( 3 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.sleep
                continue;
            }
            break;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( 401 === $code ) {
            return new WP_Error( 'invalid_key', __( 'Invalid Anthropic API key.', 'real-smart-seo' ) );
        }
        if ( 429 === $code ) {
            return new WP_Error( 'rate_limited', __( 'Claude API rate limit exceeded. Please try again in a moment.', 'real-smart-seo' ) );
        }
        if ( $code >= 400 ) {
            $msg = isset( $data['error']['message'] ) ? $data['error']['message'] : 'API error (HTTP ' . $code . ')';
            return new WP_Error( 'api_error', $msg );
        }

        $text = '';
        if ( isset( $data['content'] ) && is_array( $data['content'] ) ) {
            foreach ( $data['content'] as $block ) {
                if ( 'text' === $block['type'] ) {
                    $text .= $block['text'];
                }
            }
        }

        // Log usage.
        $input_tokens  = isset( $data['usage']['input_tokens'] )  ? (int) $data['usage']['input_tokens']  : 0;
        $output_tokens = isset( $data['usage']['output_tokens'] ) ? (int) $data['usage']['output_tokens'] : 0;
        $cost          = self::calculate_cost( $model, $input_tokens, $output_tokens );

        RSSEO_Database::log_api_call( $scan_id, $model, $input_tokens, $output_tokens, $cost );

        return array(
            'text'          => $text,
            'input_tokens'  => $input_tokens,
            'output_tokens' => $output_tokens,
            'cost'          => $cost,
            'model'         => $model,
        );
    }

    public static function calculate_cost( $model, $input_tokens, $output_tokens ) {
        $pricing     = isset( self::PRICING[ $model ] ) ? self::PRICING[ $model ] : self::PRICING['claude-sonnet-4-6'];
        $input_cost  = ( $input_tokens / 1000000 ) * $pricing['input'];
        $output_cost = ( $output_tokens / 1000000 ) * $pricing['output'];
        return round( $input_cost + $output_cost, 6 );
    }

    public static function test_connection() {
        $result = self::ask( 'Reply with just the word: connected', null );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return true;
    }
}
