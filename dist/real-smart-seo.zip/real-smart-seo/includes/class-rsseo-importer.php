<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class RSSEO_Importer {

    /**
     * Process a scan form submission.
     * Accepts file uploads and/or pasted text for each data source.
     *
     * @param array $post  $_POST data.
     * @param array $files $_FILES data.
     * @return int|WP_Error Scan ID or error.
     */
    /**
     * Default scan label — "Scan N — May 12, 2026 2:50 PM" in site-local
     * time, where N is the 1-based position of this scan in the rsseo_scans
     * table. Stable and self-describing so users can rename later if they
     * want something more specific.
     */
    public static function auto_label() {
        global $wpdb;
        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}rsseo_scans" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.NotPrepared
        return sprintf( 'Scan %d — %s', $count + 1, wp_date( 'M j, Y g:i A' ) );
    }

    public static function process_submission( $post, $files ) {
        $label = ! empty( $post['rsseo_scan_label'] )
            ? sanitize_text_field( wp_unslash( $post['rsseo_scan_label'] ) )
            : self::auto_label();

        $sf_data    = self::get_source_data( 'screaming_frog', $post, $files );
        $gsc_data   = self::get_source_data( 'gsc', $post, $files );
        $ga_data    = self::get_source_data( 'ga', $post, $files );
        $ps_data    = self::get_source_data( 'pagespeed', $post, $files );

        if ( empty( $sf_data ) && empty( $gsc_data ) && empty( $ga_data ) && empty( $ps_data ) ) {
            return new WP_Error( 'no_data', __( 'Please provide at least one data source to analyze.', 'real-smart-seo' ) );
        }

        return RSSEO_Database::insert_scan( array(
            'label'           => $label,
            'screaming_frog'  => $sf_data  ?: null,
            'gsc_data'        => $gsc_data ?: null,
            'ga_data'         => $ga_data  ?: null,
            'pagespeed_data'  => $ps_data  ?: null,
            'status'          => 'pending',
            'created_at'      => current_time( 'mysql' ),
        ) );
    }

    /**
     * Get data for a single source — prefers file upload, falls back to pasted text.
     */
    private static function get_source_data( $source, $post, $files ) {
        $file_key = 'rsseo_file_' . $source;
        $text_key = 'rsseo_text_' . $source;

        // Try file upload first.
        if ( isset( $files[ $file_key ] ) && ! empty( $files[ $file_key ]['tmp_name'] ) && UPLOAD_ERR_OK === $files[ $file_key ]['error'] ) {
            $tmp  = $files[ $file_key ]['tmp_name'];
            $name = sanitize_file_name( $files[ $file_key ]['name'] );
            $ext  = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );

            if ( ! in_array( $ext, array( 'csv', 'txt', 'tsv' ), true ) ) {
                return '';
            }
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
            $content = file_get_contents( $tmp );
            return $content ? wp_strip_all_tags( $content ) : '';
        }

        // Fall back to pasted text.
        if ( ! empty( $post[ $text_key ] ) ) {
            return sanitize_textarea_field( wp_unslash( $post[ $text_key ] ) );
        }

        return '';
    }
}
