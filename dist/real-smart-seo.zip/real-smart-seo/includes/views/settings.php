<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap rsseo-wrap">
    <h1><?php esc_html_e( 'Real Smart SEO Settings', 'real-smart-seo' ); ?></h1>

    <div id="rsseo-settings-msg" class="rsseo-notice" style="display:none;"></div>

    <form id="rsseo-settings-form">

        <div class="rsseo-settings-section">
            <h2><?php esc_html_e( 'Perplexity API Key', 'real-smart-seo' ); ?></h2>
            <p>
                <?php esc_html_e( 'Get your API key from', 'real-smart-seo' ); ?>
                <a href="https://www.perplexity.ai/settings/api" target="_blank" rel="noopener noreferrer">perplexity.ai/settings/api</a>.
                <?php esc_html_e( 'Your key is stored encrypted in the database. This same key is reused by the Smart Chat plugin\'s AI chat and the AI Rank module so you only paste it once.', 'real-smart-seo' ); ?>
            </p>

            <table class="form-table">
                <tr>
                    <th><?php esc_html_e( 'API Key', 'real-smart-seo' ); ?></th>
                    <td>
                        <input type="password" name="rsseo_api_key" id="rsseo_api_key"
                               placeholder="<?php echo $has_key ? esc_attr( '••••••••••••••••••••' ) : esc_attr( 'pplx-...' ); ?>"
                               class="regular-text" autocomplete="off">
                        <?php if ( $has_key ) : ?>
                            <span class="rsseo-key-set"><?php esc_html_e( '✓ Key is set', 'real-smart-seo' ); ?></span>
                        <?php endif; ?>
                        <button type="button" class="button" id="rsseo-test-api">
                            <?php esc_html_e( 'Test Connection', 'real-smart-seo' ); ?>
                        </button>
                    </td>
                </tr>
            </table>
        </div>

        <div class="rsseo-settings-section">
            <h2><?php esc_html_e( 'Model', 'real-smart-seo' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th><?php esc_html_e( 'Perplexity Sonar Model', 'real-smart-seo' ); ?></th>
                    <td>
                        <select name="rsseo_model">
                            <option value="sonar" <?php selected( $model, 'sonar' ); ?>>
                                Sonar — <?php esc_html_e( 'Recommended (cheapest, built-in web search)', 'real-smart-seo' ); ?>
                            </option>
                            <option value="sonar-pro" <?php selected( $model, 'sonar-pro' ); ?>>
                                Sonar Pro — <?php esc_html_e( 'Better grounding (higher cost)', 'real-smart-seo' ); ?>
                            </option>
                            <option value="sonar-reasoning" <?php selected( $model, 'sonar-reasoning' ); ?>>
                                Sonar Reasoning — <?php esc_html_e( 'Deeper reasoning for complex SEO audits', 'real-smart-seo' ); ?>
                            </option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Max Output Tokens', 'real-smart-seo' ); ?></th>
                    <td>
                        <input type="number" name="rsseo_max_tokens" value="<?php echo esc_attr( $max_tokens ); ?>"
                               min="2000" max="16000" step="1000" class="small-text">
                        <p class="description"><?php esc_html_e( 'Higher = more detailed reports. 8000 recommended.', 'real-smart-seo' ); ?></p>
                    </td>
                </tr>
            </table>
        </div>

        <p class="submit">
            <button type="submit" class="button button-primary"><?php esc_html_e( 'Save Settings', 'real-smart-seo' ); ?></button>
        </p>

    </form>
</div>
