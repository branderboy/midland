<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap rsseo-wrap">
    <h1>
        <?php esc_html_e( 'SEO Reports', 'real-smart-seo' ); ?>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=rsseo-new-scan' ) ); ?>" class="page-title-action">
            <?php esc_html_e( 'New Scan', 'real-smart-seo' ); ?>
        </a>
    </h1>

    <?php if ( empty( $scans ) ) : ?>
        <div class="rsseo-empty">
            <p><?php esc_html_e( 'No reports yet.', 'real-smart-seo' ); ?>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=rsseo-new-scan' ) ); ?>"><?php esc_html_e( 'Run your first scan →', 'real-smart-seo' ); ?></a>
            </p>
        </div>
    <?php else : ?>
    <table class="wp-list-table widefat fixed striped rsseo-table">
        <thead>
            <tr>
                <th><?php esc_html_e( 'Scan', 'real-smart-seo' ); ?></th>
                <th><?php esc_html_e( 'Date', 'real-smart-seo' ); ?></th>
                <th><?php esc_html_e( 'Critical', 'real-smart-seo' ); ?></th>
                <th><?php esc_html_e( 'High', 'real-smart-seo' ); ?></th>
                <th><?php esc_html_e( 'Medium', 'real-smart-seo' ); ?></th>
                <th><?php esc_html_e( 'Low', 'real-smart-seo' ); ?></th>
                <th><?php esc_html_e( 'Fixes', 'real-smart-seo' ); ?></th>
                <th><?php esc_html_e( 'Status', 'real-smart-seo' ); ?></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ( $scans as $scan ) : ?>
            <tr>
                <td><?php echo esc_html( $scan->label ); ?></td>
                <td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $scan->created_at ) ) ); ?></td>
                <td><?php echo $scan->report_id ? esc_html( $scan->issues_critical ) : '—'; ?></td>
                <td><?php echo $scan->report_id ? esc_html( $scan->issues_high )    : '—'; ?></td>
                <td><?php echo $scan->report_id ? esc_html( $scan->issues_medium )  : '—'; ?></td>
                <td><?php echo $scan->report_id ? esc_html( $scan->issues_low )     : '—'; ?></td>
                <td><?php echo $scan->report_id ? esc_html( $scan->fixes_applied ) . '/' . esc_html( $scan->fixes_available ) : '—'; ?></td>
                <td><span class="rsseo-status rsseo-status--<?php echo esc_attr( $scan->status ); ?>"><?php echo esc_html( $scan->status ); ?></span></td>
                <td>
                    <?php if ( $scan->report_id ) : ?>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=rsseo-reports&report_id=' . $scan->report_id ) ); ?>" class="button button-small">
                            <?php esc_html_e( 'View', 'real-smart-seo' ); ?>
                        </a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
