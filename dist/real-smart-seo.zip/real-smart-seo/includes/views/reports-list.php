<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<?php
// Reports = the archive of past analyses. Run-a-new-analysis lives on the
// Analyze tab; the pipeline CTA at the bottom of this tab already says
// "Run an Analysis first →" when empty, so we don't double up here.
$analyze_url = admin_url( 'admin.php?page=real-smart-seo&tab=analyze' );
?>
<div class="wrap rsseo-wrap">
    <h2 style="margin-top:0;"><?php esc_html_e( 'Reports archive', 'real-smart-seo' ); ?></h2>
    <p class="rsseo-muted"><?php esc_html_e( 'Showing all retained analyses (rolling window of the 10 most recent — older runs are auto-pruned).', 'real-smart-seo' ); ?></p>

    <?php if ( empty( $scans ) ) : ?>
        <div class="rsseo-empty">
            <p><?php esc_html_e( 'No archived analyses yet.', 'real-smart-seo' ); ?></p>
        </div>
    <?php else : ?>
    <table class="wp-list-table widefat fixed striped rsseo-table">
        <thead>
            <tr>
                <th><?php esc_html_e( 'Scan', 'real-smart-seo' ); ?></th>
                <th><?php esc_html_e( 'Date', 'real-smart-seo' ); ?></th>
                <th><?php esc_html_e( 'Critical', 'real-smart-seo' ); ?></th>
                <th><?php esc_html_e( 'High', 'real-smart-seo' ); ?></th>
                <th><?php esc_html_e( 'Medium', 'real-smart-seo' ); ?></th>
                <th><?php esc_html_e( 'Low', 'real-smart-seo' ); ?></th>
                <th><?php esc_html_e( 'Fixes', 'real-smart-seo' ); ?></th>
                <th><?php esc_html_e( 'Status', 'real-smart-seo' ); ?></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ( $scans as $scan ) : ?>
            <tr>
                <td><?php echo esc_html( $scan->label ); ?></td>
                <td><?php echo esc_html( wp_date( 'M j, Y g:i A', strtotime( $scan->created_at ) ) ); ?></td>
                <td><?php echo $scan->report_id ? esc_html( $scan->issues_critical ) : '—'; ?></td>
                <td><?php echo $scan->report_id ? esc_html( $scan->issues_high )    : '—'; ?></td>
                <td><?php echo $scan->report_id ? esc_html( $scan->issues_medium )  : '—'; ?></td>
                <td><?php echo $scan->report_id ? esc_html( $scan->issues_low )     : '—'; ?></td>
                <td><?php echo $scan->report_id ? esc_html( $scan->fixes_applied ) . '/' . esc_html( $scan->fixes_available ) : '—'; ?></td>
                <td><span class="rsseo-status rsseo-status--<?php echo esc_attr( $scan->status ); ?>"><?php echo esc_html( $scan->status ); ?></span></td>
                <td>
                    <?php if ( $scan->report_id ) : ?>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=real-smart-seo&tab=repair&report_id=' . $scan->report_id ) ); ?>" class="button button-small">
                            <?php esc_html_e( 'View', 'real-smart-seo' ); ?>
                        </a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
