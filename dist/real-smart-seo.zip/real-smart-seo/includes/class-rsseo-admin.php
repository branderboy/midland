<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class RSSEO_Admin {

    private static $instance = null;

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_menu',           array( $this, 'register_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'wp_ajax_rsseo_run_scan',    array( $this, 'ajax_run_scan' ) );
        add_action( 'wp_ajax_rsseo_apply_fix',   array( $this, 'ajax_apply_fix' ) );
        add_action( 'wp_ajax_rsseo_apply_all',   array( $this, 'ajax_apply_all' ) );
        add_action( 'wp_ajax_rsseo_test_api',    array( $this, 'ajax_test_api' ) );
        add_action( 'wp_ajax_rsseo_save_settings', array( $this, 'ajax_save_settings' ) );
        add_action( 'admin_post_rsseo_new_scan',    array( $this, 'handle_new_scan' ) );
        add_action( 'wp_ajax_rsseo_run_audit',      array( $this, 'ajax_run_audit' ) );
        add_action( 'wp_ajax_rsseo_apply_audit_fix', array( $this, 'ajax_apply_audit_fix' ) );
    }

    public function register_menu() {
        add_menu_page(
            __( 'Real Smart SEO', 'real-smart-seo' ),
            __( 'Real Smart SEO', 'real-smart-seo' ),
            'manage_options',
            'real-smart-seo',
            array( $this, 'page_dashboard' ),
            'dashicons-chart-line',
            81
        );
        add_submenu_page( 'real-smart-seo', __( 'Dashboard', 'real-smart-seo' ),  __( 'Dashboard', 'real-smart-seo' ),  'manage_options', 'real-smart-seo',          array( $this, 'page_dashboard' ) );
        add_submenu_page( 'real-smart-seo', __( 'New Scan', 'real-smart-seo' ),   __( 'New Scan', 'real-smart-seo' ),   'manage_options', 'rsseo-new-scan',          array( $this, 'page_new_scan' ) );
        add_submenu_page( 'real-smart-seo', __( 'Reports', 'real-smart-seo' ),    __( 'Reports', 'real-smart-seo' ),    'manage_options', 'rsseo-reports',           array( $this, 'page_reports' ) );
        add_submenu_page( 'real-smart-seo', __( 'Site Audit', 'real-smart-seo' ),  __( 'Site Audit', 'real-smart-seo' ),  'manage_options', 'rsseo-site-audit',        array( $this, 'page_site_audit' ) );
        add_submenu_page( 'real-smart-seo', __( 'Settings', 'real-smart-seo' ),   __( 'Settings', 'real-smart-seo' ),   'manage_options', 'rsseo-settings',          array( $this, 'page_settings' ) );
    }

    public function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'real-smart-seo' ) === false && strpos( $hook, 'rsseo' ) === false ) {
            return;
        }
        wp_enqueue_style( 'rsseo-admin', RSSEO_URL . 'assets/css/rsseo-admin.css', array(), RSSEO_VERSION );
        wp_enqueue_script( 'rsseo-admin', RSSEO_URL . 'assets/js/rsseo-admin.js', array( 'jquery' ), RSSEO_VERSION, true );
        wp_localize_script( 'rsseo-admin', 'rsseoData', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'rsseo_nonce' ),
            'strings'  => array(
                'applying'   => __( 'Applying fix...', 'real-smart-seo' ),
                'applied'    => __( 'Fixed!', 'real-smart-seo' ),
                'error'      => __( 'Error. Try again.', 'real-smart-seo' ),
                'confirm_fix'=> __( 'Apply this fix to your site?', 'real-smart-seo' ),
                'confirm_all'=> __( 'Apply ALL pending fixes? This will update your site content.', 'real-smart-seo' ),
                'analyzing'  => __( 'Analyzing... this may take 30–60 seconds.', 'real-smart-seo' ),
                'auditing'   => __( 'Running audit...', 'real-smart-seo' ),
            ),
        ) );
    }

    // ── Page: Dashboard ────────────────────────────────────────────────────────

    public function page_dashboard() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'real-smart-seo' ) );
        }
        $scans   = RSSEO_Database::get_scans( 5 );
        $usage   = RSSEO_Database::get_monthly_usage();
        $has_key = RSSEO_Settings::has_api_key();
        $seo_plugin = RSSEO_Settings::detect_seo_plugin();
        require RSSEO_PATH . 'includes/views/dashboard.php';
    }

    // ── Page: New Scan ─────────────────────────────────────────────────────────

    public function page_new_scan() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'real-smart-seo' ) );
        }
        $has_key = RSSEO_Settings::has_api_key();
        require RSSEO_PATH . 'includes/views/new-scan.php';
    }

    // ── Page: Reports ──────────────────────────────────────────────────────────

    public function page_reports() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'real-smart-seo' ) );
        }

        // Single report view.
        if ( isset( $_GET['report_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $report_id = (int) $_GET['report_id']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $report    = RSSEO_Database::get_report( $report_id );
            if ( $report ) {
                $fixes = RSSEO_Database::get_fixes( $report_id );
                require RSSEO_PATH . 'includes/views/report-detail.php';
                return;
            }
        }

        $scans = RSSEO_Database::get_scans( 50 );
        require RSSEO_PATH . 'includes/views/reports-list.php';
    }

    // ── Page: Settings ─────────────────────────────────────────────────────────

    public function page_settings() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'real-smart-seo' ) );
        }
        $has_key    = RSSEO_Settings::has_api_key();
        $model      = RSSEO_Settings::get_model();
        $max_tokens = RSSEO_Settings::get_max_tokens();
        require RSSEO_PATH . 'includes/views/settings.php';
    }

    // ── Form Handler: New Scan ─────────────────────────────────────────────────

    public function handle_new_scan() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'real-smart-seo' ) );
        }
        check_admin_referer( 'rsseo_new_scan' );

        $scan_id = RSSEO_Importer::process_submission( $_POST, $_FILES ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

        if ( is_wp_error( $scan_id ) ) {
            wp_redirect( add_query_arg( array(
                'page'  => 'rsseo-new-scan',
                'error' => urlencode( $scan_id->get_error_message() ),
            ), admin_url( 'admin.php' ) ) );
            exit;
        }

        // Run analysis immediately (synchronous for simplicity — fine for most sites).
        $report_id = RSSEO_Analyzer::analyze( $scan_id );

        if ( is_wp_error( $report_id ) ) {
            wp_redirect( add_query_arg( array(
                'page'  => 'rsseo-new-scan',
                'error' => urlencode( $report_id->get_error_message() ),
            ), admin_url( 'admin.php' ) ) );
            exit;
        }

        wp_redirect( add_query_arg( array(
            'page'      => 'rsseo-reports',
            'report_id' => $report_id,
        ), admin_url( 'admin.php' ) ) );
        exit;
    }

    // ── AJAX: Apply Single Fix ─────────────────────────────────────────────────

    public function ajax_apply_fix() {
        check_ajax_referer( 'rsseo_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( __( 'Insufficient permissions.', 'real-smart-seo' ) );
        }

        $fix_id = isset( $_POST['fix_id'] ) ? (int) $_POST['fix_id'] : 0;
        if ( ! $fix_id ) {
            wp_send_json_error( __( 'Invalid fix ID.', 'real-smart-seo' ) );
        }

        $result = RSSEO_Fixer::apply( $fix_id );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }

        wp_send_json_success( array( 'message' => __( 'Fix applied successfully.', 'real-smart-seo' ) ) );
    }

    // ── AJAX: Apply All Fixes ──────────────────────────────────────────────────

    public function ajax_apply_all() {
        check_ajax_referer( 'rsseo_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( __( 'Insufficient permissions.', 'real-smart-seo' ) );
        }

        $report_id = isset( $_POST['report_id'] ) ? (int) $_POST['report_id'] : 0;
        if ( ! $report_id ) {
            wp_send_json_error( __( 'Invalid report ID.', 'real-smart-seo' ) );
        }

        $result = RSSEO_Fixer::apply_all( $report_id );
        wp_send_json_success( $result );
    }

    // ── AJAX: Test API Key ─────────────────────────────────────────────────────

    public function ajax_test_api() {
        check_ajax_referer( 'rsseo_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( __( 'Insufficient permissions.', 'real-smart-seo' ) );
        }

        $result = RSSEO_Claude_API::test_connection();
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }
        wp_send_json_success( array( 'message' => __( 'Connected successfully!', 'real-smart-seo' ) ) );
    }

    // ── AJAX: Save Settings ────────────────────────────────────────────────────

    public function ajax_save_settings() {
        check_ajax_referer( 'rsseo_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( __( 'Insufficient permissions.', 'real-smart-seo' ) );
        }

        if ( isset( $_POST['rsseo_api_key'] ) ) {
            $key = sanitize_text_field( wp_unslash( $_POST['rsseo_api_key'] ) );
            if ( ! empty( $key ) && 'pplx-' !== substr( $key, 0, 5 ) ) {
                wp_send_json_error( __( 'Perplexity API key should start with pplx-', 'real-smart-seo' ) );
            }
            if ( ! empty( $key ) ) {
                RSSEO_Settings::save_api_key( $key );
            }
        }

        if ( isset( $_POST['rsseo_model'] ) ) {
            update_option( 'rsseo_model', sanitize_text_field( wp_unslash( $_POST['rsseo_model'] ) ) );
        }

        if ( isset( $_POST['rsseo_max_tokens'] ) ) {
            update_option( 'rsseo_max_tokens', min( 16000, max( 2000, (int) $_POST['rsseo_max_tokens'] ) ) );
        }

        wp_send_json_success( array( 'message' => __( 'Settings saved.', 'real-smart-seo' ) ) );
    }

    // ── Page: Site Audit ───────────────────────────────────────────────────────

    public function page_site_audit() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'real-smart-seo' ) );
        }
        $audit  = RSSEO_Database::get_latest_audit();
        $issues = $audit ? RSSEO_Database::get_audit_issues( $audit->id ) : array();
        require RSSEO_PATH . 'includes/views/site-audit.php';
    }

    // ── AJAX: Run Audit ────────────────────────────────────────────────────────

    public function ajax_run_audit() {
        check_ajax_referer( 'rsseo_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( __( 'Insufficient permissions.', 'real-smart-seo' ) );
        }

        $audit_id = RSSEO_Crawler::run();

        if ( is_wp_error( $audit_id ) ) {
            wp_send_json_error( $audit_id->get_error_message() );
        }

        $audit  = RSSEO_Database::get_audit( $audit_id );
        $issues = RSSEO_Database::get_audit_issues( $audit_id );

        wp_send_json_success( array(
            'audit_id'  => $audit_id,
            'audit'     => $audit,
            'issues'    => $issues,
            'message'   => sprintf(
                /* translators: 1: posts checked, 2: total issues */
                __( 'Audit complete — %1$d posts checked, %2$d issues found.', 'real-smart-seo' ),
                (int) $audit->posts_checked,
                (int) $audit->issues_critical + (int) $audit->issues_high + (int) $audit->issues_medium + (int) $audit->issues_low
            ),
        ) );
    }

    // ── AJAX: Apply Audit Fix ──────────────────────────────────────────────────

    public function ajax_apply_audit_fix() {
        check_ajax_referer( 'rsseo_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( __( 'Insufficient permissions.', 'real-smart-seo' ) );
        }

        $issue_id = isset( $_POST['issue_id'] ) ? (int) $_POST['issue_id'] : 0;
        if ( ! $issue_id ) {
            wp_send_json_error( __( 'Invalid issue ID.', 'real-smart-seo' ) );
        }

        $result = RSSEO_Crawler::apply_fix( $issue_id );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }

        wp_send_json_success( array( 'message' => __( 'Fix applied.', 'real-smart-seo' ) ) );
    }
}
