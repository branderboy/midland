<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class RSSEO_Admin {

    private static $instance = null;

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_menu',           array( $this, 'register_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'wp_ajax_rsseo_run_scan',    array( $this, 'ajax_run_scan' ) );
        add_action( 'wp_ajax_rsseo_apply_fix',   array( $this, 'ajax_apply_fix' ) );
        add_action( 'wp_ajax_rsseo_apply_all',   array( $this, 'ajax_apply_all' ) );
        add_action( 'wp_ajax_rsseo_test_api',    array( $this, 'ajax_test_api' ) );
        add_action( 'wp_ajax_rsseo_save_settings', array( $this, 'ajax_save_settings' ) );
        add_action( 'admin_post_rsseo_new_scan',    array( $this, 'handle_new_scan' ) );
        add_action( 'wp_ajax_rsseo_run_audit',      array( $this, 'ajax_run_audit' ) );
        add_action( 'wp_ajax_rsseo_apply_audit_fix', array( $this, 'ajax_apply_audit_fix' ) );
    }

    public function register_menu() {
        // One menu item. The page renders a tab strip and delegates to the
        // appropriate page_* method based on the ?tab= query var, so the user
        // never has to click between 5 lookalike submenus.
        add_menu_page(
            __( 'Real Smart SEO', 'real-smart-seo' ),
            __( 'Real Smart SEO', 'real-smart-seo' ),
            'manage_options',
            'real-smart-seo',
            array( $this, 'render_tabbed_page' ),
            'dashicons-chart-line',
            81
        );

        // Legacy slugs kept hidden (parent=null) so old bookmarks/links still
        // resolve. They forward to the tabbed page.
        $legacy = array(
            'rsseo-new-scan'   => 'scan',
            'rsseo-reports'    => 'reports',
            'rsseo-site-audit' => 'audit',
            'rsseo-settings'   => 'settings',
        );
        foreach ( $legacy as $slug => $tab ) {
            add_submenu_page( null, '', '', 'manage_options', $slug, function () use ( $tab ) {
                wp_safe_redirect( admin_url( 'admin.php?page=real-smart-seo&tab=' . $tab ) );
                exit;
            } );
        }
    }

    private function get_active_tab() {
        $allowed = array( 'workflow', 'scan', 'analyze', 'repair', 'index', 'insights', 'settings' );
        $tab     = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'workflow'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

        // Map legacy slugs onto the new vocabulary so old bookmarks work.
        $alias = array( 'audit' => 'scan', 'reports' => 'repair', 'report' => 'repair' );
        if ( isset( $alias[ $tab ] ) ) {
            $tab = $alias[ $tab ];
        }
        return in_array( $tab, $allowed, true ) ? $tab : 'workflow';
    }

    public function render_tabbed_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'real-smart-seo' ) );
        }
        $active = $this->get_active_tab();

        // Tabs follow the Scan → Analyze → Repair → Insights pipeline.
        // Repair = where the Apply Fixes table lives.
        // Insights = rankings, AI Rank, Geo-Grid (Pro). Free users see a
        //            "what is this" panel pointing at the Pro upgrade.
        $tabs = array(
            'workflow' => __( 'Workflow', 'real-smart-seo' ),
            'scan'     => __( 'Scan',     'real-smart-seo' ),
            'analyze'  => __( 'Analyze',  'real-smart-seo' ),
            'repair'   => __( 'Repair',   'real-smart-seo' ),
            'index'    => __( 'Index',    'real-smart-seo' ),
            'insights' => __( 'Insights', 'real-smart-seo' ),
            'settings' => __( 'Settings', 'real-smart-seo' ),
        );

        echo '<div class="wrap rsseo-wrap">';
        echo '<h1>' . esc_html__( 'Real Smart SEO', 'real-smart-seo' ) . '</h1>';

        echo '<h2 class="nav-tab-wrapper rsseo-tabs">';
        foreach ( $tabs as $slug => $label ) {
            $url   = admin_url( 'admin.php?page=real-smart-seo&tab=' . $slug );
            $class = 'nav-tab' . ( $active === $slug ? ' nav-tab-active' : '' );
            printf( '<a href="%s" class="%s">%s</a>', esc_url( $url ), esc_attr( $class ), esc_html( $label ) );
        }
        echo '</h2>';

        echo '<div class="rsseo-tab-content rsseo-tab-content--' . esc_attr( $active ) . '">';
        switch ( $active ) {
            case 'scan':     $this->page_site_audit(); break;
            case 'analyze':  $this->page_new_scan();   break;
            case 'repair':   $this->page_reports();    break;
            case 'index':    $this->page_index();      break;
            case 'insights': $this->page_insights();   break;
            case 'settings': $this->page_settings();   break;
            case 'workflow':
            default:
                $this->page_workflow();
                break;
        }
        echo '</div></div>';
    }

    /**
     * Index tab — controls for getting (and keeping) pages indexed.
     * Sitemap status, IndexNow ping (Bing + Yandex), and GSC Cleanup links.
     */
    public function page_index() {
        $has_pro     = defined( 'RSSEO_PRO_VERSION' );
        $sitemap_url = home_url( '/sitemap_index.xml' );
        ?>
        <div class="rsseo-index">
            <h2><?php esc_html_e( 'Index', 'real-smart-seo' ); ?></h2>
            <p><?php esc_html_e( 'After Repair, push the updated content into Google, Bing, and Yandex so the fixes get crawled fast — not on whatever schedule the bots feel like.', 'real-smart-seo' ); ?></p>

            <div class="rsseo-insights-grid">
                <div class="rsseo-insights-card">
                    <h3><?php esc_html_e( 'Sitemap', 'real-smart-seo' ); ?></h3>
                    <p><code><?php echo esc_html( $sitemap_url ); ?></code></p>
                    <p><?php esc_html_e( 'Submit this URL in Google Search Console → Sitemaps and Bing Webmaster Tools → Sitemaps once.', 'real-smart-seo' ); ?></p>
                    <a class="button" href="https://search.google.com/search-console" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open Google Search Console', 'real-smart-seo' ); ?></a>
                </div>

                <div class="rsseo-insights-card">
                    <h3><?php esc_html_e( 'IndexNow Ping', 'real-smart-seo' ); ?></h3>
                    <p><?php esc_html_e( 'Tell Bing, Yandex, Seznam, and Naver about new + updated URLs the moment they change. No waiting on a crawl schedule.', 'real-smart-seo' ); ?></p>
                    <?php if ( $has_pro ) : ?>
                        <a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=rsseo-pro-indexnow' ) ); ?>"><?php esc_html_e( 'Configure IndexNow →', 'real-smart-seo' ); ?></a>
                    <?php else : ?>
                        <span class="rsseo-pro-tag"><?php esc_html_e( 'Pro feature', 'real-smart-seo' ); ?></span>
                    <?php endif; ?>
                </div>

                <div class="rsseo-insights-card">
                    <h3><?php esc_html_e( 'GSC Coverage Cleanup', 'real-smart-seo' ); ?></h3>
                    <p><?php esc_html_e( 'Auto-resolve Search Console errors — duplicate canonicals, soft 404s, "discovered but not indexed" pages.', 'real-smart-seo' ); ?></p>
                    <?php if ( $has_pro ) : ?>
                        <a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=rsseo-pro-gsc' ) ); ?>"><?php esc_html_e( 'GSC Cleanup →', 'real-smart-seo' ); ?></a>
                    <?php else : ?>
                        <span class="rsseo-pro-tag"><?php esc_html_e( 'Pro feature', 'real-smart-seo' ); ?></span>
                    <?php endif; ?>
                </div>

                <div class="rsseo-insights-card">
                    <h3><?php esc_html_e( 'Rapid URL Indexer', 'real-smart-seo' ); ?></h3>
                    <p><?php esc_html_e( 'Force-index stubborn URLs via third-party indexing services (paid). Optional — useful for fresh programmatic pages.', 'real-smart-seo' ); ?></p>
                    <?php if ( $has_pro ) : ?>
                        <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=rsseo-pro-indexnow#rapid' ) ); ?>"><?php esc_html_e( 'Setup →', 'real-smart-seo' ); ?></a>
                    <?php else : ?>
                        <span class="rsseo-pro-tag"><?php esc_html_e( 'Pro feature', 'real-smart-seo' ); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Insights tab — rankings, backlinks, AI-recommended optimization
     * strategies. Pro modules (AI Rank, Geo-Grid) hook the action below to
     * inject their dashboards inline; free users see a summary with a
     * "Get AI Recommendation" button that runs an analysis via Perplexity.
     */
    public function page_insights() {
        $has_pro = defined( 'RSSEO_PRO_VERSION' );
        ?>
        <div class="rsseo-insights">
            <h2><?php esc_html_e( 'Insights', 'real-smart-seo' ); ?></h2>
            <p><?php esc_html_e( 'Rankings, backlinks, and AI-generated optimization strategies for your site.', 'real-smart-seo' ); ?></p>

            <div class="rsseo-insights-grid">
                <div class="rsseo-insights-card">
                    <h3><?php esc_html_e( 'Keyword Rankings', 'real-smart-seo' ); ?></h3>
                    <p><?php esc_html_e( 'Track positions for your target keywords across Google, Bing, and AI search engines.', 'real-smart-seo' ); ?></p>
                    <?php if ( $has_pro ) : ?>
                        <a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=rsseo-pro-ai-rank' ) ); ?>"><?php esc_html_e( 'Open AI Rank', 'real-smart-seo' ); ?></a>
                    <?php else : ?>
                        <span class="rsseo-pro-tag"><?php esc_html_e( 'Pro feature', 'real-smart-seo' ); ?></span>
                    <?php endif; ?>
                </div>

                <div class="rsseo-insights-card">
                    <h3><?php esc_html_e( 'Local Rank Grid (Local Falcon-style)', 'real-smart-seo' ); ?></h3>
                    <p><?php esc_html_e( 'Map-pack rank measured at a grid of geographic points around your business — same idea as Local Falcon. See heat-map style coverage of where you rank #1 vs. where you fall off.', 'real-smart-seo' ); ?></p>
                    <?php if ( $has_pro ) : ?>
                        <a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=rsseo-pro-geogrid' ) ); ?>"><?php esc_html_e( 'Open Geo-Grid →', 'real-smart-seo' ); ?></a>
                    <?php else : ?>
                        <span class="rsseo-pro-tag"><?php esc_html_e( 'Pro feature', 'real-smart-seo' ); ?></span>
                    <?php endif; ?>
                </div>

                <div class="rsseo-insights-card">
                    <h3><?php esc_html_e( 'Backlinks', 'real-smart-seo' ); ?></h3>
                    <p><?php esc_html_e( 'Inbound link profile, lost / gained links, and toxic-link warnings. Pulls from DataForSEO when connected.', 'real-smart-seo' ); ?></p>
                    <span class="rsseo-pro-tag"><?php esc_html_e( 'Coming soon', 'real-smart-seo' ); ?></span>
                </div>

                <div class="rsseo-insights-card">
                    <h3><?php esc_html_e( 'Indexing', 'real-smart-seo' ); ?></h3>
                    <p><?php esc_html_e( 'Google Search Console coverage — indexed / not indexed / errors. Ping new and updated URLs to Bing & Yandex via IndexNow.', 'real-smart-seo' ); ?></p>
                    <?php if ( $has_pro ) : ?>
                        <a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=rsseo-pro-gsc' ) ); ?>"><?php esc_html_e( 'GSC Cleanup', 'real-smart-seo' ); ?></a>
                        <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=rsseo-pro-indexnow' ) ); ?>"><?php esc_html_e( 'IndexNow', 'real-smart-seo' ); ?></a>
                    <?php else : ?>
                        <span class="rsseo-pro-tag"><?php esc_html_e( 'Pro feature', 'real-smart-seo' ); ?></span>
                    <?php endif; ?>
                </div>

                <div class="rsseo-insights-card">
                    <h3><?php esc_html_e( 'AI Optimization Strategies', 'real-smart-seo' ); ?></h3>
                    <p><?php esc_html_e( 'Ask Perplexity Sonar what to do next based on your latest scan + ranking data. Get a prioritized 30-day plan.', 'real-smart-seo' ); ?></p>
                    <button type="button" class="button button-primary" id="rsseo-get-strategy" disabled title="<?php esc_attr_e( 'Run a scan first so the AI has data to recommend on.', 'real-smart-seo' ); ?>">
                        <?php esc_html_e( 'Get AI Recommendation', 'real-smart-seo' ); ?>
                    </button>
                </div>
            </div>

            <?php
            // Pro modules can hook this action to render a richer inline dashboard.
            if ( $has_pro ) {
                do_action( 'rsseo_render_insights_panel' );
            }
            ?>
        </div>
        <?php
    }

    /**
     * Workflow tab — numbered step-by-step the user can follow start to finish
     * without guessing which submenu to click next.
     */
    public function page_workflow() {
        $has_key       = RSSEO_Settings::has_api_key();
        $scans         = RSSEO_Database::get_scans( 1 );
        $latest_scan   = ! empty( $scans ) ? $scans[0] : null;
        $latest_report = $latest_scan ? RSSEO_Database::get_report( (int) $latest_scan->id ) : null;
        $pending_fixes = 0;
        if ( $latest_report ) {
            $pending_fixes = max( 0, (int) $latest_report->fixes_available - (int) $latest_report->fixes_applied );
        }
        $has_pro = defined( 'RSSEO_PRO_VERSION' );

        $url_scan     = admin_url( 'admin.php?page=real-smart-seo&tab=scan' );
        $url_analyze  = admin_url( 'admin.php?page=real-smart-seo&tab=analyze' );
        $url_repair   = admin_url( 'admin.php?page=real-smart-seo&tab=repair' );
        $url_index    = admin_url( 'admin.php?page=real-smart-seo&tab=index' );
        $url_insights = admin_url( 'admin.php?page=real-smart-seo&tab=insights' );
        $url_settings = admin_url( 'admin.php?page=real-smart-seo&tab=settings' );
        $url_report   = $latest_scan ? admin_url( 'admin.php?page=real-smart-seo&tab=repair&report_id=' . (int) $latest_scan->id ) : $url_repair;

        require RSSEO_PATH . 'includes/views/workflow.php';
    }

    public function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'real-smart-seo' ) === false && strpos( $hook, 'rsseo' ) === false ) {
            return;
        }
        wp_enqueue_style( 'rsseo-admin', RSSEO_URL . 'assets/css/rsseo-admin.css', array(), RSSEO_VERSION );
        wp_enqueue_script( 'rsseo-admin', RSSEO_URL . 'assets/js/rsseo-admin.js', array( 'jquery' ), RSSEO_VERSION, true );
        wp_localize_script( 'rsseo-admin', 'rsseoData', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'rsseo_nonce' ),
            'strings'  => array(
                'applying'   => __( 'Applying fix...', 'real-smart-seo' ),
                'applied'    => __( 'Fixed!', 'real-smart-seo' ),
                'error'      => __( 'Error. Try again.', 'real-smart-seo' ),
                'confirm_fix'=> __( 'Apply this fix to your site?', 'real-smart-seo' ),
                'confirm_all'=> __( 'Apply ALL pending fixes? This will update your site content.', 'real-smart-seo' ),
                'analyzing'  => __( 'Analyzing... this may take 30–60 seconds.', 'real-smart-seo' ),
                'auditing'   => __( 'Running audit...', 'real-smart-seo' ),
            ),
        ) );
    }

    // ── Page: Dashboard ────────────────────────────────────────────────────────

    public function page_dashboard() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'real-smart-seo' ) );
        }
        $scans   = RSSEO_Database::get_scans( 5 );
        $usage   = RSSEO_Database::get_monthly_usage();
        $has_key = RSSEO_Settings::has_api_key();
        $seo_plugin = RSSEO_Settings::detect_seo_plugin();
        require RSSEO_PATH . 'includes/views/dashboard.php';
    }

    // ── Page: New Scan ─────────────────────────────────────────────────────────

    public function page_new_scan() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'real-smart-seo' ) );
        }
        $has_key = RSSEO_Settings::has_api_key();
        require RSSEO_PATH . 'includes/views/new-scan.php';
    }

    // ── Page: Reports ──────────────────────────────────────────────────────────

    public function page_reports() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'real-smart-seo' ) );
        }

        // Single report view.
        if ( isset( $_GET['report_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $report_id = (int) $_GET['report_id']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $report    = RSSEO_Database::get_report( $report_id );
            if ( $report ) {
                $fixes = RSSEO_Database::get_fixes( $report_id );
                require RSSEO_PATH . 'includes/views/report-detail.php';
                return;
            }
        }

        $scans = RSSEO_Database::get_scans( 50 );
        require RSSEO_PATH . 'includes/views/reports-list.php';
    }

    // ── Page: Settings ─────────────────────────────────────────────────────────

    public function page_settings() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'real-smart-seo' ) );
        }
        $has_pro = defined( 'RSSEO_PRO_VERSION' );

        // Basic | Pro sub-tabs inside the Settings tab. Pro renders inline via
        // an action hook so users don't have to chase a separate "Pro Settings"
        // menu item — there isn't one anymore.
        $sub = isset( $_GET['sub'] ) ? sanitize_key( wp_unslash( $_GET['sub'] ) ) : 'basic'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ( ! in_array( $sub, array( 'basic', 'pro' ), true ) ) {
            $sub = 'basic';
        }
        if ( 'pro' === $sub && ! $has_pro ) {
            $sub = 'basic';
        }

        if ( $has_pro ) {
            $basic_url = admin_url( 'admin.php?page=real-smart-seo&tab=settings&sub=basic' );
            $pro_url   = admin_url( 'admin.php?page=real-smart-seo&tab=settings&sub=pro' );
            echo '<div class="rsseo-subtabs">';
            printf(
                '<a href="%s" class="rsseo-subtab%s">%s</a>',
                esc_url( $basic_url ),
                'basic' === $sub ? ' is-active' : '',
                esc_html__( 'Basic', 'real-smart-seo' )
            );
            printf(
                '<a href="%s" class="rsseo-subtab%s">%s</a>',
                esc_url( $pro_url ),
                'pro' === $sub ? ' is-active' : '',
                esc_html__( 'Pro', 'real-smart-seo' )
            );
            echo '</div>';
        }

        if ( 'pro' === $sub ) {
            if ( has_action( 'rsseo_render_pro_settings_panel' ) ) {
                do_action( 'rsseo_render_pro_settings_panel' );
            } else {
                echo '<p>' . esc_html__( 'Pro plugin not active.', 'real-smart-seo' ) . '</p>';
            }
            return;
        }

        $has_key    = RSSEO_Settings::has_api_key();
        $model      = RSSEO_Settings::get_model();
        $max_tokens = RSSEO_Settings::get_max_tokens();
        require RSSEO_PATH . 'includes/views/settings.php';
    }

    // ── Form Handler: New Scan ─────────────────────────────────────────────────

    public function handle_new_scan() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'real-smart-seo' ) );
        }
        check_admin_referer( 'rsseo_new_scan' );

        $scan_id = RSSEO_Importer::process_submission( $_POST, $_FILES ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

        if ( is_wp_error( $scan_id ) ) {
            wp_redirect( add_query_arg( array(
                'page'  => 'rsseo-new-scan',
                'error' => urlencode( $scan_id->get_error_message() ),
            ), admin_url( 'admin.php' ) ) );
            exit;
        }

        // Run analysis immediately (synchronous for simplicity — fine for most sites).
        $report_id = RSSEO_Analyzer::analyze( $scan_id );

        if ( is_wp_error( $report_id ) ) {
            wp_redirect( add_query_arg( array(
                'page'  => 'rsseo-new-scan',
                'error' => urlencode( $report_id->get_error_message() ),
            ), admin_url( 'admin.php' ) ) );
            exit;
        }

        wp_redirect( add_query_arg( array(
            'page'      => 'rsseo-reports',
            'report_id' => $report_id,
        ), admin_url( 'admin.php' ) ) );
        exit;
    }

    // ── AJAX: Apply Single Fix ─────────────────────────────────────────────────

    public function ajax_apply_fix() {
        check_ajax_referer( 'rsseo_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( __( 'Insufficient permissions.', 'real-smart-seo' ) );
        }

        $fix_id = isset( $_POST['fix_id'] ) ? (int) $_POST['fix_id'] : 0;
        if ( ! $fix_id ) {
            wp_send_json_error( __( 'Invalid fix ID.', 'real-smart-seo' ) );
        }

        $result = RSSEO_Fixer::apply( $fix_id );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }

        wp_send_json_success( array( 'message' => __( 'Fix applied successfully.', 'real-smart-seo' ) ) );
    }

    // ── AJAX: Apply All Fixes ──────────────────────────────────────────────────

    public function ajax_apply_all() {
        check_ajax_referer( 'rsseo_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( __( 'Insufficient permissions.', 'real-smart-seo' ) );
        }

        $report_id = isset( $_POST['report_id'] ) ? (int) $_POST['report_id'] : 0;
        if ( ! $report_id ) {
            wp_send_json_error( __( 'Invalid report ID.', 'real-smart-seo' ) );
        }

        $result = RSSEO_Fixer::apply_all( $report_id );
        wp_send_json_success( $result );
    }

    // ── AJAX: Test API Key ─────────────────────────────────────────────────────

    public function ajax_test_api() {
        check_ajax_referer( 'rsseo_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( __( 'Insufficient permissions.', 'real-smart-seo' ) );
        }

        $result = RSSEO_Claude_API::test_connection();
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }
        wp_send_json_success( array( 'message' => __( 'Connected successfully!', 'real-smart-seo' ) ) );
    }

    // ── AJAX: Save Settings ────────────────────────────────────────────────────

    public function ajax_save_settings() {
        check_ajax_referer( 'rsseo_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( __( 'Insufficient permissions.', 'real-smart-seo' ) );
        }

        if ( isset( $_POST['rsseo_api_key'] ) ) {
            $key = sanitize_text_field( wp_unslash( $_POST['rsseo_api_key'] ) );
            if ( ! empty( $key ) && 'pplx-' !== substr( $key, 0, 5 ) ) {
                wp_send_json_error( __( 'Perplexity API key should start with pplx-', 'real-smart-seo' ) );
            }
            if ( ! empty( $key ) ) {
                RSSEO_Settings::save_api_key( $key );
            }
        }

        if ( isset( $_POST['rsseo_model'] ) ) {
            update_option( 'rsseo_model', sanitize_text_field( wp_unslash( $_POST['rsseo_model'] ) ) );
        }

        if ( isset( $_POST['rsseo_max_tokens'] ) ) {
            update_option( 'rsseo_max_tokens', min( 16000, max( 2000, (int) $_POST['rsseo_max_tokens'] ) ) );
        }

        if ( isset( $_POST['rsseo_business_profile'] ) && is_array( $_POST['rsseo_business_profile'] ) ) {
            $raw     = wp_unslash( $_POST['rsseo_business_profile'] );
            $profile = array(
                'name'          => isset( $raw['name'] )          ? sanitize_text_field( $raw['name'] )          : '',
                'category'      => isset( $raw['category'] )      ? sanitize_text_field( $raw['category'] )      : '',
                'gmb_url'       => isset( $raw['gmb_url'] )       ? esc_url_raw( $raw['gmb_url'] )                : '',
                'service_areas' => isset( $raw['service_areas'] ) ? sanitize_textarea_field( $raw['service_areas'] ) : '',
                'competitors'   => isset( $raw['competitors'] )   ? sanitize_textarea_field( $raw['competitors'] )   : '',
            );
            update_option( 'rsseo_business_profile', $profile );
        }

        wp_send_json_success( array( 'message' => __( 'Settings saved.', 'real-smart-seo' ) ) );
    }

    // ── Page: Site Audit ───────────────────────────────────────────────────────

    public function page_site_audit() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'real-smart-seo' ) );
        }
        $audit  = RSSEO_Database::get_latest_audit();
        $issues = $audit ? RSSEO_Database::get_audit_issues( $audit->id ) : array();
        require RSSEO_PATH . 'includes/views/site-audit.php';
    }

    // ── AJAX: Run Audit ────────────────────────────────────────────────────────

    public function ajax_run_audit() {
        check_ajax_referer( 'rsseo_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( __( 'Insufficient permissions.', 'real-smart-seo' ) );
        }

        $audit_id = RSSEO_Crawler::run();

        if ( is_wp_error( $audit_id ) ) {
            wp_send_json_error( $audit_id->get_error_message() );
        }

        $audit  = RSSEO_Database::get_audit( $audit_id );
        $issues = RSSEO_Database::get_audit_issues( $audit_id );

        wp_send_json_success( array(
            'audit_id'  => $audit_id,
            'audit'     => $audit,
            'issues'    => $issues,
            'message'   => sprintf(
                /* translators: 1: posts checked, 2: total issues */
                __( 'Audit complete — %1$d posts checked, %2$d issues found.', 'real-smart-seo' ),
                (int) $audit->posts_checked,
                (int) $audit->issues_critical + (int) $audit->issues_high + (int) $audit->issues_medium + (int) $audit->issues_low
            ),
        ) );
    }

    // ── AJAX: Apply Audit Fix ──────────────────────────────────────────────────

    public function ajax_apply_audit_fix() {
        check_ajax_referer( 'rsseo_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( __( 'Insufficient permissions.', 'real-smart-seo' ) );
        }

        $issue_id = isset( $_POST['issue_id'] ) ? (int) $_POST['issue_id'] : 0;
        if ( ! $issue_id ) {
            wp_send_json_error( __( 'Invalid issue ID.', 'real-smart-seo' ) );
        }

        $result = RSSEO_Crawler::apply_fix( $issue_id );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }

        wp_send_json_success( array( 'message' => __( 'Fix applied.', 'real-smart-seo' ) ) );
    }
}
