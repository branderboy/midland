<?php
/**
 * Plugin Name: Midland Smart Forms Basic
 * Description: Lead capture forms for Midland Floor Care — customer info, project details, photo uploads, ballpark estimates, and lead management from the WordPress dashboard.
 * Version: 1.3.0
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: smart-forms-for-midland
 * Domain Path: /languages
 * Requires at least: 5.5
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Plugin constants
define( 'SFCO_VERSION', '1.2.0' );
define( 'SFCO_PLUGIN_FILE', __FILE__ );
define( 'SFCO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SFCO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Main plugin class
 */
class SFCO_Plugin {
    
    private static $instance = null;
    
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }
    
    private function load_dependencies() {
        require_once SFCO_PLUGIN_DIR . 'includes/class-database.php';
        require_once SFCO_PLUGIN_DIR . 'includes/class-form-handler.php';
        require_once SFCO_PLUGIN_DIR . 'includes/class-admin.php';
        require_once SFCO_PLUGIN_DIR . 'includes/class-shortcode.php';
    }
    
    private function init_hooks() {
        register_activation_hook( __FILE__, array( 'SFCO_Database', 'create_tables' ) );
        register_uninstall_hook( __FILE__, array( 'SFCO_Plugin', 'uninstall' ) );
        
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_assets' ) );
    }
    
    public function enqueue_frontend_assets() {
        wp_enqueue_style( 'sfco-frontend', SFCO_PLUGIN_URL . 'assets/css/frontend.css', array(), SFCO_VERSION );
        wp_enqueue_script( 'sfco-frontend', SFCO_PLUGIN_URL . 'assets/js/frontend.js', array( 'jquery' ), SFCO_VERSION, true );
        
        wp_localize_script( 'sfco-frontend', 'sfcoData', array(
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
            'nonce' => wp_create_nonce( 'sfco_submit' ),
        ) );
    }
    
    public static function uninstall() {
        if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
            return;
        }
        
        global $wpdb;
        
        $table = $wpdb->prefix . 'sfco_leads';
        
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Plugin-owned table name built from $wpdb->prefix.
        $wpdb->query( "DROP TABLE IF EXISTS {$table}" );
        
        delete_option( 'sfco_version' );
        delete_option( 'sfco_settings' );
    }
}

// Initialize plugin
SFCO_Plugin::get_instance();
