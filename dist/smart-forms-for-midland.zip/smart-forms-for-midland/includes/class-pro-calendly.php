<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SFCO_Pro_Calendly {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_menu' ), 32 );
        add_action( 'admin_init', array( $this, 'handle_save' ) );
        add_action( 'admin_init', array( $this, 'handle_register_webhook' ) );
        add_action( 'rest_api_init', array( $this, 'register_webhook' ) );
    }

    public function add_menu() {
        add_submenu_page(
            null,
            esc_html__( 'Calendar', 'smart-forms-pro' ),
            esc_html__( 'Calendar', 'smart-forms-pro' ),
            'manage_options',
            'sfco-calendar',
            array( $this, 'render_page' )
        );
    }

    public function handle_save() {
        if ( ! isset( $_POST['sfco_save_calendly'] ) || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $nonce = isset( $_POST['_sfco_cal_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_sfco_cal_nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'sfco_save_calendly' ) ) {
            wp_die( esc_html__( 'Security check failed.', 'smart-forms-pro' ) );
        }

        $api_key      = isset( $_POST['calendly_api_key'] ) ? sanitize_text_field( wp_unslash( $_POST['calendly_api_key'] ) ) : '';
        $signing_key  = isset( $_POST['calendly_signing_key'] ) ? sanitize_text_field( wp_unslash( $_POST['calendly_signing_key'] ) ) : '';
        $booking_url  = isset( $_POST['calendly_url'] ) ? esc_url_raw( wp_unslash( $_POST['calendly_url'] ) ) : '';
        $show_after   = isset( $_POST['calendly_show_after'] ) ? sanitize_key( $_POST['calendly_show_after'] ) : 'submission';
        $enabled      = isset( $_POST['calendly_enabled'] ) ? 1 : 0;

        update_option( 'sfco_pro_calendly_api_key', $api_key );
        update_option( 'sfco_pro_calendly_signing_key', $signing_key );
        update_option( 'sfco_pro_calendly_url', $booking_url );
        update_option( 'sfco_pro_calendly_show_after', $show_after );
        update_option( 'sfco_pro_calendly_enabled', $enabled );

        wp_safe_redirect( admin_url( 'admin.php?page=sfco-calendar&saved=1' ) );
        exit;
    }

    /**
     * Auto-register the webhook subscription with Calendly via the v2 API.
     * Uses the saved personal access token to look up the org, creates a
     * subscription for invitee.created + invitee.canceled pointing at our
     * REST endpoint, and stores the returned signing key. No more pasting
     * URLs or keys by hand.
     */
    public function handle_register_webhook() {
        if ( ! isset( $_POST['sfco_register_calendly'] ) || ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $nonce = isset( $_POST['_sfco_cal_reg_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_sfco_cal_reg_nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'sfco_register_calendly' ) ) {
            wp_die( esc_html__( 'Security check failed.', 'smart-forms-pro' ) );
        }

        // Save any token pasted on this submit before using it.
        if ( isset( $_POST['calendly_api_key'] ) ) {
            update_option( 'sfco_pro_calendly_api_key', sanitize_text_field( wp_unslash( $_POST['calendly_api_key'] ) ) );
        }

        $token = trim( (string) get_option( 'sfco_pro_calendly_api_key', '' ) );
        if ( '' === $token ) {
            wp_safe_redirect( admin_url( 'admin.php?page=sfco-calendar&reg_error=notoken' ) );
            exit;
        }

        // 1. Who am I — get the user + organization URIs.
        $me = wp_remote_get( 'https://api.calendly.com/users/me', array(
            'timeout' => 20,
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ),
        ) );
        if ( is_wp_error( $me ) ) {
            wp_safe_redirect( admin_url( 'admin.php?page=sfco-calendar&reg_error=transport' ) );
            exit;
        }
        $me_code = (int) wp_remote_retrieve_response_code( $me );
        $me_body = json_decode( wp_remote_retrieve_body( $me ), true );
        if ( $me_code < 200 || $me_code >= 300 || empty( $me_body['resource'] ) ) {
            wp_safe_redirect( admin_url( 'admin.php?page=sfco-calendar&reg_error=auth' ) );
            exit;
        }
        $user_uri = (string) ( $me_body['resource']['uri'] ?? '' );
        $org_uri  = (string) ( $me_body['resource']['current_organization'] ?? '' );
        if ( '' === $org_uri ) {
            wp_safe_redirect( admin_url( 'admin.php?page=sfco-calendar&reg_error=noorg' ) );
            exit;
        }

        // 2. Create the subscription pointing at our endpoint.
        $create = wp_remote_post( 'https://api.calendly.com/webhook_subscriptions', array(
            'timeout' => 20,
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ),
            'body' => wp_json_encode( array(
                'url'          => rest_url( 'sfco-pro/v1/calendly/webhook' ),
                'events'       => array( 'invitee.created', 'invitee.canceled' ),
                'organization' => $org_uri,
                'user'         => $user_uri,
                'scope'        => 'user',
            ) ),
        ) );
        if ( is_wp_error( $create ) ) {
            wp_safe_redirect( admin_url( 'admin.php?page=sfco-calendar&reg_error=transport' ) );
            exit;
        }
        $c_code = (int) wp_remote_retrieve_response_code( $create );
        $c_body = json_decode( wp_remote_retrieve_body( $create ), true );

        // 201 created. Calendly returns the signing key once, here — store it.
        if ( 201 === $c_code || ( $c_code >= 200 && $c_code < 300 ) ) {
            $signing_key = (string) ( $c_body['resource']['signing_key'] ?? '' );
            if ( '' !== $signing_key ) {
                update_option( 'sfco_pro_calendly_signing_key', $signing_key );
            }
            update_option( 'sfco_pro_calendly_enabled', 1 );
            wp_safe_redirect( admin_url( 'admin.php?page=sfco-calendar&registered=1' ) );
            exit;
        }

        // 409 = already subscribed for this URL. Treat as success but flag it.
        if ( 409 === $c_code ) {
            wp_safe_redirect( admin_url( 'admin.php?page=sfco-calendar&reg_error=exists' ) );
            exit;
        }

        wp_safe_redirect( admin_url( 'admin.php?page=sfco-calendar&reg_error=create' ) );
        exit;
    }

    /**
     * Register REST endpoint for Calendly webhooks.
     */
    public function register_webhook() {
        register_rest_route( 'sfco-pro/v1', '/calendly/webhook', array(
            'methods'             => 'POST',
            'callback'            => array( $this, 'handle_webhook' ),
            'permission_callback' => array( $this, 'verify_webhook_signature' ),
        ) );
    }

    /**
     * Verify Calendly's HMAC-SHA256 signature header.
     * Header format: Calendly-Webhook-Signature: t=<timestamp>,v1=<hmac>
     * Signature payload: "{timestamp}.{raw body}"
     * Tolerance: 5 minutes against replay.
     */
    public function verify_webhook_signature( $request ) {
        $signing_key = (string) get_option( 'sfco_pro_calendly_signing_key', '' );

        // No key configured: refuse the request so attackers can't forge events.
        if ( '' === $signing_key ) {
            return new WP_Error( 'sfco_calendly_no_key', __( 'Calendly signing key is not configured.', 'smart-forms-pro' ), array( 'status' => 401 ) );
        }

        $header = (string) $request->get_header( 'calendly_webhook_signature' );
        if ( '' === $header ) {
            return new WP_Error( 'sfco_calendly_missing_sig', __( 'Missing Calendly signature header.', 'smart-forms-pro' ), array( 'status' => 401 ) );
        }

        $parts = array();
        foreach ( explode( ',', $header ) as $piece ) {
            $kv = explode( '=', trim( $piece ), 2 );
            if ( 2 === count( $kv ) ) {
                $parts[ $kv[0] ] = $kv[1];
            }
        }

        $timestamp = isset( $parts['t'] ) ? (int) $parts['t'] : 0;
        $signature = $parts['v1'] ?? '';

        if ( ! $timestamp || ! $signature ) {
            return new WP_Error( 'sfco_calendly_bad_sig', __( 'Malformed Calendly signature.', 'smart-forms-pro' ), array( 'status' => 401 ) );
        }

        // Reject anything older than 5 minutes (replay protection).
        if ( abs( time() - $timestamp ) > 300 ) {
            return new WP_Error( 'sfco_calendly_stale', __( 'Calendly webhook timestamp out of tolerance.', 'smart-forms-pro' ), array( 'status' => 401 ) );
        }

        $payload = $request->get_body();
        $expected = hash_hmac( 'sha256', $timestamp . '.' . $payload, $signing_key );

        if ( ! hash_equals( $expected, $signature ) ) {
            return new WP_Error( 'sfco_calendly_invalid_sig', __( 'Calendly signature mismatch.', 'smart-forms-pro' ), array( 'status' => 401 ) );
        }

        return true;
    }

    public function handle_webhook( $request ) {
        $body  = $request->get_json_params();
        $event = $body['event'] ?? '';

        if ( 'invitee.created' === $event ) {
            return $this->handle_invitee_created( $body );
        }

        if ( 'invitee.canceled' === $event ) {
            return $this->handle_invitee_canceled( $body );
        }

        return new WP_REST_Response( array( 'received' => true, 'action' => 'ignored' ), 200 );
    }

    /**
     * A new appointment was scheduled. On a reschedule Calendly fires
     * invitee.canceled AND invitee.created together; the created event carries
     * the NEW time, so this path also handles the "after" side of a reschedule.
     */
    private function handle_invitee_created( $body ) {
        $payload = $body['payload'] ?? array();
        $email   = sanitize_email( (string) ( $payload['email'] ?? '' ) );
        $name    = sanitize_text_field( (string) ( $payload['name'] ?? '' ) );
        $time    = (string) ( $payload['scheduled_event']['start_time'] ?? '' );
        // Calendly marks the created half of a reschedule with this flag.
        $is_reschedule = ! empty( $payload['rescheduled'] );

        if ( ! is_email( $email ) ) {
            return new WP_REST_Response( array( 'received' => true, 'action' => 'no_email' ), 200 );
        }

        global $wpdb;
        $lead = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}sfco_leads WHERE customer_email = %s ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $email
        ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

        if ( ! $lead ) {
            return new WP_REST_Response( array( 'received' => true, 'action' => 'no_match' ), 200 );
        }

        $old_status = isset( $lead->status ) ? $lead->status : '';
        $wpdb->update(
            $wpdb->prefix . 'sfco_leads',
            array( 'status' => 'booked' ),
            array( 'id' => $lead->id ),
            array( '%s' ),
            array( '%d' )
        ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

        $lead = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}sfco_leads WHERE id = %d", $lead->id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        /**
         * Confirmed appointment from Calendly. Smart CRM Pro advances the AC
         * deal to booked and pushes the visit time into ServiceM8.
         */
        do_action( 'scrm_pro_appointment_booked', $lead, $time );
        do_action( 'sfco_lead_status_changed', $lead, $old_status, 'booked' );

        $subject = $is_reschedule
            ? sprintf( __( 'Rescheduled: %s moved their Calendly appointment', 'smart-forms-pro' ), $name )
            : sprintf( __( 'Booking: %s scheduled via Calendly', 'smart-forms-pro' ), $name );
        $line = $is_reschedule
            ? sprintf( __( "%s rescheduled their appointment.\n\nNew time: %s\nEmail: %s", 'smart-forms-pro' ), $name, $time, $email )
            : sprintf( __( "%s booked an appointment.\n\nTime: %s\nEmail: %s\n\nLead has been marked as Booked.", 'smart-forms-pro' ), $name, $time, $email );
        wp_mail( get_option( 'admin_email' ), $subject, $line );

        return new WP_REST_Response( array(
            'received' => true,
            'action'   => $is_reschedule ? 'rescheduled' : 'booked',
            'lead_id'  => (int) $lead->id,
        ), 200 );
    }

    /**
     * An appointment was canceled. On a reschedule Calendly fires this with a
     * rescheduled flag set — in that case we do NOT revert the lead, because the
     * paired invitee.created already set the new booking. A true cancel reverts
     * the lead to "canceled" and fires an event so AC/ops can react.
     */
    private function handle_invitee_canceled( $body ) {
        $payload = $body['payload'] ?? array();
        $email   = sanitize_email( (string) ( $payload['email'] ?? '' ) );
        $name    = sanitize_text_field( (string) ( $payload['name'] ?? '' ) );
        $is_reschedule = ! empty( $payload['rescheduled'] );

        // Reschedule cancel half: ignore, the created half handles the new time.
        if ( $is_reschedule ) {
            return new WP_REST_Response( array( 'received' => true, 'action' => 'reschedule_cancel_ignored' ), 200 );
        }

        if ( ! is_email( $email ) ) {
            return new WP_REST_Response( array( 'received' => true, 'action' => 'no_email' ), 200 );
        }

        global $wpdb;
        $lead = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}sfco_leads WHERE customer_email = %s ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $email
        ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

        if ( ! $lead ) {
            return new WP_REST_Response( array( 'received' => true, 'action' => 'no_match' ), 200 );
        }

        $old_status = isset( $lead->status ) ? $lead->status : '';
        $wpdb->update(
            $wpdb->prefix . 'sfco_leads',
            array( 'status' => 'canceled' ),
            array( 'id' => $lead->id ),
            array( '%s' ),
            array( '%d' )
        ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

        $lead = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}sfco_leads WHERE id = %d", $lead->id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        /**
         * Appointment canceled. Listeners can move the AC deal back / tag the
         * contact as a cancellation for win-back follow-up.
         */
        do_action( 'scrm_pro_appointment_canceled', $lead );
        do_action( 'sfco_lead_status_changed', $lead, $old_status, 'canceled' );

        wp_mail(
            get_option( 'admin_email' ),
            sprintf( __( 'Canceled: %s canceled their Calendly appointment', 'smart-forms-pro' ), $name ),
            sprintf( __( "%s canceled their appointment.\n\nEmail: %s\n\nLead has been marked as Canceled.", 'smart-forms-pro' ), $name, $email )
        );

        return new WP_REST_Response( array(
            'received' => true,
            'action'   => 'canceled',
            'lead_id'  => (int) $lead->id,
        ), 200 );
    }

    /**
     * Get the Calendly booking URL to show after form submission.
     */
    public static function get_booking_url() {
        $enabled = get_option( 'sfco_pro_calendly_enabled', 0 );
        if ( ! $enabled ) {
            return '';
        }
        return get_option( 'sfco_pro_calendly_url', '' );
    }

    public function render_page() {
        $api_key     = get_option( 'sfco_pro_calendly_api_key', '' );
        $signing_key = get_option( 'sfco_pro_calendly_signing_key', '' );
        $booking_url = get_option( 'sfco_pro_calendly_url', '' );
        $show_after  = get_option( 'sfco_pro_calendly_show_after', 'submission' );
        $enabled     = get_option( 'sfco_pro_calendly_enabled', 0 );
        $webhook_url = rest_url( 'sfco-pro/v1/calendly/webhook' );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Calendar / Calendly Integration', 'smart-forms-pro' ); ?></h1>

            <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
            <?php if ( isset( $_GET['saved'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Calendar settings saved.', 'smart-forms-pro' ); ?></p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['registered'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Webhook registered with Calendly and signing key saved. Bookings, cancellations, and reschedules will now flow in automatically.', 'smart-forms-pro' ); ?></p></div>
            <?php endif; ?>
            <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $reg_err = isset( $_GET['reg_error'] ) ? sanitize_key( $_GET['reg_error'] ) : '';
            if ( $reg_err ) :
                $msg = __( 'Could not register the webhook with Calendly.', 'smart-forms-pro' );
                if ( 'notoken' === $reg_err ) { $msg = __( 'Paste your Calendly API token first, then click Register.', 'smart-forms-pro' ); }
                elseif ( 'auth' === $reg_err ) { $msg = __( 'Calendly rejected the token. Check that it is a valid personal access token.', 'smart-forms-pro' ); }
                elseif ( 'noorg' === $reg_err ) { $msg = __( 'Could not read your Calendly organization from the token.', 'smart-forms-pro' ); }
                elseif ( 'exists' === $reg_err ) { $msg = __( 'A webhook for this URL already exists in Calendly. You are good to go.', 'smart-forms-pro' ); }
                elseif ( 'transport' === $reg_err ) { $msg = __( 'Could not reach Calendly. Try again in a moment.', 'smart-forms-pro' ); }
                $cls = ( 'exists' === $reg_err ) ? 'notice-warning' : 'notice-error';
                ?>
                <div class="notice <?php echo esc_attr( $cls ); ?> is-dismissible"><p><?php echo esc_html( $msg ); ?></p></div>
            <?php endif; ?>

            <form method="post">
                <?php wp_nonce_field( 'sfco_save_calendly', '_sfco_cal_nonce' ); ?>

                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e( 'Enable', 'smart-forms-pro' ); ?></th>
                        <td><label><input type="checkbox" name="calendly_enabled" value="1" <?php checked( $enabled ); ?>> <?php esc_html_e( 'Enable Calendly booking after form submission', 'smart-forms-pro' ); ?></label></td>
                    </tr>
                    <tr>
                        <th><label for="calendly_url"><?php esc_html_e( 'Calendly URL', 'smart-forms-pro' ); ?></label></th>
                        <td>
                            <input type="url" name="calendly_url" id="calendly_url" class="regular-text" value="<?php echo esc_attr( $booking_url ); ?>" placeholder="https://calendly.com/your-company/30min">
                            <p class="description"><?php esc_html_e( 'Your Calendly scheduling page URL.', 'smart-forms-pro' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="calendly_api_key"><?php esc_html_e( 'API Token', 'smart-forms-pro' ); ?></label></th>
                        <td>
                            <input type="password" name="calendly_api_key" id="calendly_api_key" class="regular-text" value="<?php echo esc_attr( $api_key ); ?>">
                            <p class="description"><?php esc_html_e( 'Your Calendly personal access token. Get it at calendly.com under Integrations, API and webhooks. Paste it, save, then click Register Webhook below to wire everything automatically.', 'smart-forms-pro' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="calendly_show_after"><?php esc_html_e( 'Show Booking', 'smart-forms-pro' ); ?></label></th>
                        <td>
                            <select name="calendly_show_after" id="calendly_show_after">
                                <option value="submission" <?php selected( $show_after, 'submission' ); ?>><?php esc_html_e( 'After form submission (in success message)', 'smart-forms-pro' ); ?></option>
                                <option value="email" <?php selected( $show_after, 'email' ); ?>><?php esc_html_e( 'In follow-up email only', 'smart-forms-pro' ); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Webhook URL', 'smart-forms-pro' ); ?></th>
                        <td>
                            <code><?php echo esc_html( $webhook_url ); ?></code>
                            <p class="description"><?php esc_html_e( 'Add this URL in your Calendly webhook settings to auto-update lead status when appointments are booked.', 'smart-forms-pro' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="calendly_signing_key"><?php esc_html_e( 'Webhook Signing Key', 'smart-forms-pro' ); ?></label></th>
                        <td>
                            <input type="password" name="calendly_signing_key" id="calendly_signing_key" class="regular-text" value="<?php echo esc_attr( $signing_key ); ?>">
                            <p class="description"><?php esc_html_e( 'Required. Calendly returns this when you create the webhook subscription. Without it, the webhook endpoint rejects every request.', 'smart-forms-pro' ); ?></p>
                        </td>
                    </tr>
                </table>

                <p class="submit">
                    <button type="submit" name="sfco_save_calendly" value="1" class="button button-primary"><?php esc_html_e( 'Save Calendar Settings', 'smart-forms-pro' ); ?></button>
                </p>
            </form>

            <hr>
            <h2><?php esc_html_e( 'Auto-Register Webhook', 'smart-forms-pro' ); ?></h2>
            <p class="description" style="max-width:640px;">
                <?php esc_html_e( 'One click sets up the Calendly webhook for you: it subscribes to bookings, cancellations, and reschedules pointing at this site, and saves the signing key automatically. Save your API token above first. This replaces the manual Zapier connection.', 'smart-forms-pro' ); ?>
            </p>
            <form method="post">
                <?php wp_nonce_field( 'sfco_register_calendly', '_sfco_cal_reg_nonce' ); ?>
                <input type="hidden" name="calendly_api_key" value="<?php echo esc_attr( $api_key ); ?>">
                <p class="submit">
                    <button type="submit" name="sfco_register_calendly" value="1" class="button button-secondary"><?php esc_html_e( 'Register Webhook with Calendly', 'smart-forms-pro' ); ?></button>
                </p>
            </form>
        </div>
        <?php
    }
}

new SFCO_Pro_Calendly();
