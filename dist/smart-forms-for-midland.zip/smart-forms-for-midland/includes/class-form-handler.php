<?php
/**
 * Form submission handler
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Smart_Forms_Handler {
    
    public function __construct() {
        add_action( 'wp_ajax_sfco_submit', array( $this, 'handle_submission' ) );
        add_action( 'wp_ajax_nopriv_sfco_submit', array( $this, 'handle_submission' ) );
    }
    
    public function handle_submission() {
        try {
        // CRITICAL FIX: Sanitize nonce BEFORE verification
        $nonce = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';

        if ( ! wp_verify_nonce( $nonce, 'sfco_submit' ) ) {
            wp_send_json_error( array( 'message' => esc_html__( 'Security check failed', 'smart-forms-for-midland' ) ) );
        }

        // Honeypot — every form's shortcode renders a hidden field named
        // sfco_hp_token. Real users never fill it; bots fill every
        // visible input. If the field has any value, silently treat the
        // submission as accepted (return success) so the bot doesn't
        // retry with a different strategy, but skip every side effect.
        if ( ! empty( $_POST['sfco_hp_token'] ) ) {
            wp_send_json_success( array( 'message' => 'OK' ) );
        }
        
        // Identify the form so we validate against ITS fields and connect the
        // lead to the right form. The chat embeds a DB-built form (its own
        // fields), so the old hardcoded customer_name/project_type required list
        // broke capture for anything other than the legacy [sfco_quote] form.
        $form_id = isset( $_POST['form_id'] ) ? absint( $_POST['form_id'] ) : 0;
        $form    = $form_id ? SFCO_Database::get_form( $form_id ) : null;

        $db_fields = array();
        if ( $form && ! empty( $form->fields_json ) ) {
            $decoded = json_decode( $form->fields_json, true );
            if ( is_array( $decoded ) ) {
                $db_fields = $decoded;
            }
        }

        // reCAPTCHA v3 (only enforced when the form has both site + secret keys).
        if ( ! $this->verify_recaptcha( $form ) ) {
            wp_send_json_error( array( 'message' => esc_html__( 'Spam verification failed. Please reload the page and try again.', 'smart-forms-for-midland' ) ) );
        }

        if ( ! empty( $db_fields ) ) {
            // DB-built form: required = whatever the field builder marked required.
            foreach ( $db_fields as $f ) {
                $key = $f['key'] ?? '';
                if ( $key && ! empty( $f['required'] ) && empty( $_POST[ $key ] ) ) {
                    wp_send_json_error( array(
                        /* translators: %s: field label */
                        'message' => sprintf( esc_html__( '%s is required', 'smart-forms-for-midland' ), esc_html( $f['label'] ?? $key ) ),
                    ) );
                }
            }
        } else {
            // Legacy [sfco_quote] form — only the identity fields are required.
            // project_type is intentionally NOT in this list: the frontend hides
            // the service dropdown and removes its `required` attribute for
            // residential leads (who choose a call-back instead of specifying
            // a service). Keeping project_type required here caused valid
            // residential submissions to fail with a server-side error even
            // though the form looked complete to the visitor.
            foreach ( array( 'customer_name', 'customer_email', 'customer_phone' ) as $field ) {
                if ( empty( $_POST[ $field ] ) ) {
                    wp_send_json_error( array(
                        /* translators: %s: field name */
                        'message' => sprintf( esc_html__( '%s is required', 'smart-forms-for-midland' ), esc_html( $field ) ),
                    ) );
                }
            }
        }

        // Flexible identity mapping so custom field keys still produce a usable
        // lead (name / first_name+last_name, email, phone/tel).
        $name = $this->first_nonempty( array( 'customer_name', 'name', 'full_name' ) );
        if ( '' === $name ) {
            $name = trim( $this->first_nonempty( array( 'first_name', 'fname' ) ) . ' ' . $this->first_nonempty( array( 'last_name', 'lname' ) ) );
        }
        $email = sanitize_email( $this->first_nonempty( array( 'customer_email', 'email' ) ) );
        $phone = $this->first_nonempty( array( 'customer_phone', 'phone', 'tel' ) );

        if ( '' !== $email && ! is_email( $email ) ) {
            wp_send_json_error( array( 'message' => esc_html__( 'Invalid email address', 'smart-forms-for-midland' ) ) );
        }
        
        // Handle file uploads — process every key in $_FILES, not just 'photos'.
        // The field builder can produce file inputs with any key (resume, attachment,
        // photos, etc.). Previously only $_FILES['photos'] was processed, so any
        // custom file field silently dropped its upload.
        //
        // The legacy [sfco_quote] shortcode and the apply form both use 'photos[]'.
        // DB-built forms use whatever key the operator set. All are processed here;
        // the result is a flat array of URLs merged from every file field.
        $photo_urls = array();

        if ( ! empty( $_FILES ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- nonce verified above; files validated in handle_file_field()
            if ( ! function_exists( 'wp_handle_upload' ) ) {
                require_once ABSPATH . 'wp-admin/includes/file.php';
            }
            foreach ( $_FILES as $field_key => $file_data ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
                $result = $this->handle_file_field( $file_data );
                if ( is_wp_error( $result ) ) {
                    wp_send_json_error( array( 'message' => esc_html( $result->get_error_message() ) ) );
                }
                $photo_urls = array_merge( $photo_urls, $result );
            }
        }
        
        // Calculate estimate
        $square_footage = isset( $_POST['square_footage'] ) ? absint( $_POST['square_footage'] ) : 0;
        $project_type = isset( $_POST['project_type'] ) ? sanitize_text_field( wp_unslash( $_POST['project_type'] ) ) : '';
        $estimate = $this->calculate_estimate( $square_footage, $project_type );
        
        // Collect any other submitted fields (custom DB-form fields) so nothing
        // is lost — stored on the lead as extra_fields_json.
        $reserved = array(
            'action', '_wpnonce', '_wp_http_referer', 'sfco_hp_token', 'form_id',
            'customer_name', 'name', 'full_name', 'first_name', 'fname', 'last_name', 'lname',
            'customer_email', 'email', 'customer_phone', 'phone', 'tel',
            'project_type', 'square_footage', 'material_type', 'finish_level',
            'timeline', 'zip_code', 'additional_notes',
        );
        $extra_fields = array();
        foreach ( wp_unslash( $_POST ) as $k => $v ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- nonce verified above; values sanitized below
            if ( in_array( $k, $reserved, true ) ) {
                continue;
            }
            $extra_fields[ sanitize_key( $k ) ] = is_array( $v ) ? array_map( 'sanitize_text_field', $v ) : sanitize_text_field( $v );
        }

        // Prepare lead data
        $lead_data = array(
            'form_id' => $form_id ?: 1,
            'customer_name' => sanitize_text_field( $name ),
            'customer_email' => $email,
            'customer_phone' => sanitize_text_field( $phone ),
            'project_type' => $project_type,
            'square_footage' => $square_footage,
            'material_type' => isset( $_POST['material_type'] ) ? sanitize_text_field( wp_unslash( $_POST['material_type'] ) ) : '',
            'finish_level' => isset( $_POST['finish_level'] ) ? sanitize_text_field( wp_unslash( $_POST['finish_level'] ) ) : '',
            'timeline' => isset( $_POST['timeline'] ) ? sanitize_text_field( wp_unslash( $_POST['timeline'] ) ) : '',
            'zip_code' => isset( $_POST['zip_code'] ) ? sanitize_text_field( wp_unslash( $_POST['zip_code'] ) ) : '',
            'additional_notes' => isset( $_POST['additional_notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['additional_notes'] ) ) : '',
            'photo_urls' => $photo_urls,
            'extra_fields' => $extra_fields,
            'estimated_cost_min' => $estimate['min'],
            'estimated_cost_max' => $estimate['max'],
        );
        
        // Save to database
        $lead_id = SFCO_Database::create_lead( $lead_data );
        
        if ( ! $lead_id ) {
            wp_send_json_error( array( 'message' => esc_html__( 'Failed to save lead', 'smart-forms-for-midland' ) ) );
        }
        
        // Send notification email. This is the legacy fallback notifier — when
        // the Pro Notifications module is active and its admin notification is
        // enabled, it sends a (richer) admin email off sfco_lead_submitted, so
        // skip this one to avoid the operator getting two emails per lead.
        $pro_notifs = class_exists( 'SFCO_Pro_Notifications' )
            ? SFCO_Pro_Notifications::get_settings()
            : array();
        if ( empty( $pro_notifs['admin_enabled'] ) ) {
            $this->send_notification_email( $lead_id, $lead_data );
        }

        // Where to send the visitor after submit (e.g. Calendly). Uses the
        // form's redirect URL if confirmation is set to "redirect", otherwise
        // the per-form Booking link. The chat widget ignores this (it shows its
        // own "Pick a time" button instead of navigating away).
        $redirect = '';
        $fs = ( $form && ! empty( $form->settings_json ) ) ? json_decode( $form->settings_json, true ) : array();
        if ( is_array( $fs ) ) {
            if ( 'redirect' === ( $fs['confirmation_type'] ?? '' ) && ! empty( $fs['redirect_url'] ) ) {
                $redirect = $fs['redirect_url'];
            } elseif ( ! empty( $fs['booking_url'] ) ) {
                $redirect = $fs['booking_url'];
            }
        }
        // Fall back to the global Calendly URL when the form has no per-form link.
        if ( '' === $redirect && class_exists( 'SFCO_Pro_Calendly' ) ) {
            $redirect = SFCO_Pro_Calendly::get_booking_url();
        }

        // Stamp the lead id + identity onto a Calendly booking link so the
        // Calendly webhook can map the resulting booking back to THIS lead
        // (utm_content=LEAD_<id>) and prefill the customer's details. No-op for
        // non-Calendly redirect targets.
        if ( '' !== $redirect && class_exists( 'SFCO_Pro_Calendly' ) ) {
            $redirect = SFCO_Pro_Calendly::decorate_booking_url( $redirect, (int) $lead_id, sanitize_text_field( $name ), $email );
        }

        // Success response
        wp_send_json_success( array(
            'message' => esc_html__( 'Thank you! We\'ll contact you soon.', 'smart-forms-for-midland' ),
            'lead_id' => absint( $lead_id ),
            'redirect' => esc_url_raw( $redirect ),
            'estimate' => array(
                'min' => floatval( $estimate['min'] ),
                'max' => floatval( $estimate['max'] ),
            ),
        ) );
        } catch ( \Throwable $e ) {
            // Log the real fatal server-side for debugging, but never leak file
            // paths, line numbers, or DB internals to the (unauthenticated)
            // visitor — this handler also serves wp_ajax_nopriv.
            error_log( sprintf(
                'Smart Forms submission error: %s @ %s:%d',
                $e->getMessage(),
                $e->getFile(),
                $e->getLine()
            ) );
            wp_send_json_error( array(
                'message' => esc_html__( 'Something went wrong submitting the form. Please try again.', 'smart-forms-for-midland' ),
            ) );
        }
    }

    /**
     * Return the first non-empty value among a list of $_POST keys. Lets the
     * handler accept several common field-key spellings (customer_name / name,
     * customer_phone / phone, etc.) so DB-built forms map cleanly to a lead.
     * Nonce is verified at the top of handle_submission().
     */
    private function first_nonempty( array $keys ) {
        foreach ( $keys as $k ) {
            if ( isset( $_POST[ $k ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
                $val = trim( (string) wp_unslash( $_POST[ $k ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
                if ( '' !== $val ) {
                    return $val;
                }
            }
        }
        return '';
    }

    /**
     * Verify a Google reCAPTCHA v3 token for the submitted form.
     *
     * Enforcement is opt-in per form and only kicks in when BOTH the site key
     * and the secret are configured — a secret without a site key would block
     * every submission because the frontend can't mint a token. Transport
     * errors (Google outage) fail open so legitimate leads aren't dropped; a
     * present-but-invalid token, or a score below the (filterable) 0.5
     * threshold, fails closed.
     *
     * The form nonce is verified at the top of handle_submission().
     *
     * @param object|null $form Form row (settings_json holds the keys).
     * @return bool True to allow the submission, false to reject it.
     */
    private function verify_recaptcha( $form ) {
        if ( ! $form || empty( $form->settings_json ) ) {
            return true;
        }
        $settings = json_decode( $form->settings_json, true );
        if ( ! is_array( $settings ) ) {
            return true;
        }
        $site   = isset( $settings['recaptcha_site'] ) ? trim( (string) $settings['recaptcha_site'] ) : '';
        $secret = isset( $settings['recaptcha_secret'] ) ? trim( (string) $settings['recaptcha_secret'] ) : '';
        if ( '' === $site || '' === $secret ) {
            return true;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in handle_submission()
        $token = isset( $_POST['g-recaptcha-response'] ) ? sanitize_text_field( wp_unslash( $_POST['g-recaptcha-response'] ) ) : '';
        if ( '' === $token ) {
            return false;
        }

        $resp = wp_remote_post( 'https://www.google.com/recaptcha/api/siteverify', array(
            'timeout' => 10,
            'body'    => array(
                'secret'   => $secret,
                'response' => $token,
                'remoteip' => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
            ),
        ) );
        if ( is_wp_error( $resp ) ) {
            // Fail open — don't let a Google outage drop real leads.
            return true;
        }

        $body = json_decode( (string) wp_remote_retrieve_body( $resp ), true );
        if ( ! is_array( $body ) || empty( $body['success'] ) ) {
            return false;
        }
        // v3 returns a 0.0–1.0 score; treat below the threshold as a bot.
        $score     = isset( $body['score'] ) ? (float) $body['score'] : 1.0;
        $threshold = (float) apply_filters( 'sfco_recaptcha_threshold', 0.5, $form );
        return $score >= $threshold;
    }

    /**
     * Process one entry from $_FILES. Works for both multi-file inputs
     * (name="photos[]" → arrays of name/tmp_name/etc.) and single-file
     * inputs from the field builder (name="resume" → scalar strings).
     *
     * Called once per $_FILES key so every custom file field — regardless
     * of what the operator named it — is uploaded and its URL collected.
     *
     * @param  array      $file_data  One element from $_FILES.
     * @return string[]|WP_Error     Array of uploaded URLs, or WP_Error.
     */
    private function handle_file_field( $file_data ) {
        $uploaded_files = array();

        if ( ! is_array( $file_data ) || ! isset( $file_data['name'] ) ) {
            return $uploaded_files;
        }

        // Normalize both shapes to an array-of-files so the loop below is uniform:
        //   Multi-file  (photos[]):  $file_data['name'] is already an array.
        //   Single-file (resume):   $file_data['name'] is a scalar string.
        if ( ! is_array( $file_data['name'] ) ) {
            $file_data = array(
                'name'     => array( $file_data['name'] ),
                'tmp_name' => array( $file_data['tmp_name'] ),
                'error'    => array( $file_data['error'] ),
                'size'     => array( $file_data['size'] ),
            );
        }

        $max_files = 5;
        $max_size  = 5 * 1024 * 1024; // 5 MB

        $file_count = count( $file_data['name'] );
        if ( $file_count > $max_files ) {
            return new WP_Error(
                'too_many_files',
                sprintf(
                    /* translators: %d: maximum number of files */
                    esc_html__( 'Maximum %d files allowed per field', 'smart-forms-for-midland' ),
                    $max_files
                )
            );
        }

        for ( $i = 0; $i < $file_count; $i++ ) {
            // Skip slots that were never filled (empty multi-file input).
            if ( empty( $file_data['tmp_name'][ $i ] ) ) {
                continue;
            }
            if ( ! isset( $file_data['error'][ $i ] ) || UPLOAD_ERR_OK !== $file_data['error'][ $i ] ) {
                continue;
            }
            if ( ( $file_data['size'][ $i ] ?? 0 ) > $max_size ) {
                return new WP_Error( 'file_too_large', esc_html__( 'File size exceeds 5 MB limit', 'smart-forms-for-midland' ) );
            }

            $file = array(
                'name'     => sanitize_file_name( $file_data['name'][ $i ] ),
                'tmp_name' => $file_data['tmp_name'][ $i ],
                'error'    => $file_data['error'][ $i ],
                'size'     => $file_data['size'][ $i ],
            );

            $filetype = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'] );
            if ( ! $filetype['ext'] || ! $filetype['type'] ) {
                return new WP_Error( 'invalid_file_type', esc_html__( 'Invalid file type', 'smart-forms-for-midland' ) );
            }

            $allowed_types = array( 'jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf', 'doc', 'docx' );
            if ( ! in_array( $filetype['ext'], $allowed_types, true ) ) {
                return new WP_Error(
                    'invalid_file',
                    esc_html__( 'Only JPG, PNG, GIF, WebP images and PDF/DOC/DOCX documents are allowed', 'smart-forms-for-midland' )
                );
            }

            $file['type'] = $filetype['type'];
            $upload       = wp_handle_upload( $file, array( 'test_form' => false ) );

            if ( isset( $upload['error'] ) ) {
                return new WP_Error( 'upload_failed', esc_html( $upload['error'] ) );
            }

            $uploaded_files[] = esc_url_raw( $upload['url'] );
        }

        return $uploaded_files;
    }
    
    private function calculate_estimate( $square_footage, $project_type ) {
        // Per-sqft rate ranges for Midland Floor Care services.
        // Keys are lowercase for case-insensitive substring matching below.
        // Rates are conservative field estimates; actual quotes are provided
        // by the team after the visit. Min = residential/light, Max = commercial/heavy.
        $rates = array(
            'carpet cleaning'          => array( 'min' => 0.20, 'max' => 0.45 ),
            'carpet installation'      => array( 'min' => 3.50, 'max' => 7.00 ),
            'tile'                     => array( 'min' => 0.55, 'max' => 1.20 ),
            'grout'                    => array( 'min' => 0.55, 'max' => 1.20 ),
            'floor stripping'          => array( 'min' => 0.35, 'max' => 0.75 ),
            'strip'                    => array( 'min' => 0.35, 'max' => 0.75 ),
            'wax'                      => array( 'min' => 0.35, 'max' => 0.75 ),
            'hardwood'                 => array( 'min' => 1.00, 'max' => 3.50 ),
            'concrete'                 => array( 'min' => 1.50, 'max' => 4.00 ),
            'polish'                   => array( 'min' => 1.50, 'max' => 4.00 ),
            'upholstery'               => array( 'min' => 0.30, 'max' => 0.60 ),
            'water damage'             => array( 'min' => 3.00, 'max' => 8.00 ),
            'water'                    => array( 'min' => 3.00, 'max' => 8.00 ),
            'restoration'              => array( 'min' => 3.00, 'max' => 8.00 ),
        );

        // Case-insensitive partial match: find the first rate key that appears
        // as a substring of the submitted project_type. This handles variant
        // spellings ('Carpet Cleaning', 'carpet cleaning', 'Commercial Carpet
        // Cleaning', 'Tile & Grout Cleaning') without requiring exact key match.
        // Longer keys are checked first so 'carpet installation' wins over 'carpet'.
        $needle = strtolower( trim( (string) $project_type ) );
        $rate   = null;

        if ( '' !== $needle ) {
            // Sort by key length descending so more-specific keys win.
            $sorted_rates = $rates;
            uksort( $sorted_rates, function( $a, $b ) {
                return strlen( $b ) - strlen( $a );
            } );

            foreach ( $sorted_rates as $key => $r ) {
                if ( false !== strpos( $needle, $key ) ) {
                    $rate = $r;
                    break;
                }
            }
        }

        // Fall back to a generic floor care baseline when no service matches.
        if ( null === $rate ) {
            $rate = array( 'min' => 0.25, 'max' => 0.65 );
        }

        return array(
            'min' => $square_footage * $rate['min'],
            'max' => $square_footage * $rate['max'],
        );
    }
    
    private function send_notification_email( $lead_id, $lead_data ) {
        $admin_email = get_option( 'admin_email' );
        $subject = sprintf( 
            /* translators: %s: customer name */
            esc_html__( 'New Lead from %s', 'smart-forms-for-midland' ), 
            $lead_data['customer_name'] 
        );
        
        $message = sprintf(
            "New lead #%d\n\nCustomer: %s\nEmail: %s\nPhone: %s\nProject: %s\nSquare Footage: %d\nTimeline: %s\n\nView in dashboard: %s",
            absint( $lead_id ),
            sanitize_text_field( $lead_data['customer_name'] ),
            sanitize_email( $lead_data['customer_email'] ),
            sanitize_text_field( $lead_data['customer_phone'] ),
            sanitize_text_field( $lead_data['project_type'] ),
            absint( $lead_data['square_footage'] ),
            sanitize_text_field( $lead_data['timeline'] ),
            esc_url( admin_url( 'admin.php?page=smart-forms-leads&lead_id=' . $lead_id ) )
        );
        
        wp_mail( $admin_email, $subject, $message );
    }
}

new Smart_Forms_Handler();
