<?php
/**
 * Admin dashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SFCO_Admin {
    
    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_menu_pages' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
    }
    
    public function add_menu_pages() {
        add_menu_page(
            esc_html__( 'Smart Forms', 'smart-forms-for-midland' ),
            esc_html__( 'Smart Forms', 'smart-forms-for-midland' ),
            'manage_options',
            'smart-forms-leads',
            array( $this, 'render_leads_page' ),
            'dashicons-forms',
            30
        );
        add_submenu_page(
            'smart-forms-leads',
            esc_html__( 'Leads', 'smart-forms-for-midland' ),
            esc_html__( 'Leads', 'smart-forms-for-midland' ),
            'manage_options',
            'smart-forms-leads',
            array( $this, 'render_leads_page' )
        );
        add_submenu_page(
            'smart-forms-leads',
            esc_html__( 'Shortcodes', 'smart-forms-for-midland' ),
            esc_html__( 'Shortcodes', 'smart-forms-for-midland' ),
            'manage_options',
            'smart-forms-shortcodes',
            array( $this, 'render_shortcodes_page' )
        );
    }

    public function render_shortcodes_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Smart Forms Shortcodes', 'smart-forms-for-midland' ); ?></h1>
            <p><?php esc_html_e( 'Drop one of these into any page, post, or Elementor Shortcode widget to render the quote form.', 'smart-forms-for-midland' ); ?></p>

            <style>
                .sfco-sc-row { background:#fff;border:1px solid #ccd0d4;border-radius:4px;padding:18px 20px;margin-bottom:14px; }
                .sfco-sc-code { background:#f6f7f7;border:1px solid #dcdcde;padding:8px 14px;font-family:Consolas,Monaco,monospace;font-size:14px;border-radius:3px;display:inline-block;margin:0 8px 0 0; }
                .sfco-sc-copy { background:#2271b1;color:#fff;border:0;padding:6px 14px;border-radius:3px;cursor:pointer;font-size:12px;vertical-align:middle; }
                .sfco-sc-copy:hover { background:#135e96; }
                .sfco-sc-desc { color:#555;font-size:13px;margin:8px 0 0; }
            </style>

            <h2><?php esc_html_e( 'Main shortcode', 'smart-forms-for-midland' ); ?></h2>
            <div class="sfco-sc-row">
                <code class="sfco-sc-code" id="sc1">[sfco_quote]</code>
                <button class="sfco-sc-copy" data-target="sc1"><?php esc_html_e( 'Copy', 'smart-forms-for-midland' ); ?></button>
                <p class="sfco-sc-desc"><?php esc_html_e( 'Renders the full lead-capture form: name, email, phone, service type, square footage, timeline, photo upload, and submit.', 'smart-forms-for-midland' ); ?></p>
            </div>

            <h2><?php esc_html_e( 'How to use', 'smart-forms-for-midland' ); ?></h2>
            <ol>
                <li><?php esc_html_e( 'Edit any page or post.', 'smart-forms-for-midland' ); ?></li>
                <li><?php esc_html_e( 'In Elementor: drag a Shortcode widget; in Gutenberg: add a Shortcode block.', 'smart-forms-for-midland' ); ?></li>
                <li><?php esc_html_e( 'Paste [sfco_quote] and update.', 'smart-forms-for-midland' ); ?></li>
            </ol>

            <h2><?php esc_html_e( 'Live preview', 'smart-forms-for-midland' ); ?></h2>
            <div style="border:2px dashed #ccc;padding:20px;background:#fafafa;max-width:800px;">
                <?php echo do_shortcode( '[sfco_quote]' ); ?>
            </div>

            <script>
            document.addEventListener('click', function(e) {
                if (e.target.classList.contains('sfco-sc-copy')) {
                    var el = document.getElementById(e.target.dataset.target);
                    if (el && navigator.clipboard) {
                        navigator.clipboard.writeText(el.textContent).then(function() {
                            var orig = e.target.textContent;
                            e.target.textContent = '<?php echo esc_js( __( 'Copied!', 'smart-forms-for-midland' ) ); ?>';
                            setTimeout(function() { e.target.textContent = orig; }, 1500);
                        });
                    }
                }
            });
            </script>
        </div>
        <?php
    }
    
    public function enqueue_admin_assets( $hook ) {
        if ( strpos( $hook, 'smart-forms' ) === false ) {
            return;
        }
        
        wp_enqueue_style( 'sfco-admin', SFCO_PLUGIN_URL . 'assets/css/admin.css', array(), SFCO_VERSION );
        wp_enqueue_script( 'sfco-admin', SFCO_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery' ), SFCO_VERSION, true );
    }
    
    public function render_leads_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;

        // Defensive: if SFCO_Database isn't loaded for any reason, fail loud
        // instead of blank-screen.
        if ( ! class_exists( 'SFCO_Database' ) ) {
            echo '<div class="wrap"><h1>Midland Smart Forms</h1><div class="notice notice-error"><p>SFCO_Database class is missing. Reinstall the plugin.</p></div></div>';
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $filter_status   = isset( $_GET['status'] )   ? sanitize_text_field( wp_unslash( $_GET['status'] ) )   : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $filter_timeline = isset( $_GET['timeline'] ) ? sanitize_text_field( wp_unslash( $_GET['timeline'] ) ) : '';

        $leads = SFCO_Database::get_leads( array(
            'status'   => $filter_status,
            'timeline' => $filter_timeline,
            'limit'    => 50,
        ) );
        $leads = is_array( $leads ) ? $leads : array();

        $shortcode_url = admin_url( 'admin.php?page=smart-forms-shortcodes' );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Midland Smart Forms — Leads', 'smart-forms-for-midland' ); ?></h1>

            <?php if ( empty( $leads ) ) : ?>
                <div style="background:#fff;border:1px dashed #c3c4c7;border-radius:6px;padding:32px 28px;max-width:760px;margin:24px 0;">
                    <h2 style="margin-top:0;"><?php esc_html_e( '📭 No leads yet.', 'smart-forms-for-midland' ); ?></h2>
                    <p style="font-size:14px;line-height:1.6;"><?php esc_html_e( 'Add the quote form to your site so visitors can submit project details. Drop this shortcode into any page or post:', 'smart-forms-for-midland' ); ?></p>
                    <p>
                        <code style="background:#f6f7f7;border:1px solid #dcdcde;padding:8px 14px;font-size:14px;border-radius:3px;display:inline-block;">[sfco_quote]</code>
                    </p>
                    <p style="font-size:14px;line-height:1.6;">
                        <?php esc_html_e( 'In Elementor: drag a Shortcode widget. In Gutenberg: add a Shortcode block. Paste, update, done.', 'smart-forms-for-midland' ); ?>
                    </p>
                    <p>
                        <a class="button button-primary" href="<?php echo esc_url( $shortcode_url ); ?>"><?php esc_html_e( 'View shortcode reference + live preview →', 'smart-forms-for-midland' ); ?></a>
                    </p>
                </div>
                <?php return; ?>
            <?php endif; ?>

            <div class="smart-forms-filters" style="margin:10px 0 14px;">
                <select name="status" onchange="location = this.value;">
                    <option value="<?php echo esc_url( admin_url( 'admin.php?page=smart-forms-leads' ) ); ?>"><?php esc_html_e( 'All Statuses', 'smart-forms-for-midland' ); ?></option>
                    <option value="<?php echo esc_url( add_query_arg( 'status', 'new' ) ); ?>" <?php selected( $filter_status, 'new' ); ?>><?php esc_html_e( 'New', 'smart-forms-for-midland' ); ?></option>
                    <option value="<?php echo esc_url( add_query_arg( 'status', 'contacted' ) ); ?>" <?php selected( $filter_status, 'contacted' ); ?>><?php esc_html_e( 'Contacted', 'smart-forms-for-midland' ); ?></option>
                    <option value="<?php echo esc_url( add_query_arg( 'status', 'quoted' ) ); ?>" <?php selected( $filter_status, 'quoted' ); ?>><?php esc_html_e( 'Quoted', 'smart-forms-for-midland' ); ?></option>
                    <option value="<?php echo esc_url( add_query_arg( 'status', 'won' ) ); ?>" <?php selected( $filter_status, 'won' ); ?>><?php esc_html_e( 'Won', 'smart-forms-for-midland' ); ?></option>
                    <option value="<?php echo esc_url( add_query_arg( 'status', 'lost' ) ); ?>" <?php selected( $filter_status, 'lost' ); ?>><?php esc_html_e( 'Lost', 'smart-forms-for-midland' ); ?></option>
                </select>
            </div>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'ID', 'smart-forms-for-midland' ); ?></th>
                        <th><?php esc_html_e( 'Customer', 'smart-forms-for-midland' ); ?></th>
                        <th><?php esc_html_e( 'Contact', 'smart-forms-for-midland' ); ?></th>
                        <th><?php esc_html_e( 'Project', 'smart-forms-for-midland' ); ?></th>
                        <th><?php esc_html_e( 'Timeline', 'smart-forms-for-midland' ); ?></th>
                        <th><?php esc_html_e( 'Estimate', 'smart-forms-for-midland' ); ?></th>
                        <th><?php esc_html_e( 'Date', 'smart-forms-for-midland' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ( $leads as $lead ) :
                    $timeline_class = 'timeline-normal';
                    if ( 'ASAP' === ( $lead->timeline ?? '' ) )      $timeline_class = 'timeline-urgent';
                    elseif ( 'This Week' === ( $lead->timeline ?? '' ) ) $timeline_class = 'timeline-soon';
                    ?>
                    <tr>
                        <td><?php echo esc_html( $lead->id ); ?></td>
                        <td><strong><?php echo esc_html( $lead->customer_name ?? '' ); ?></strong></td>
                        <td>
                            <a href="mailto:<?php echo esc_attr( $lead->customer_email ?? '' ); ?>"><?php echo esc_html( $lead->customer_email ?? '' ); ?></a><br>
                            <a href="tel:<?php echo esc_attr( $lead->customer_phone ?? '' ); ?>"><?php echo esc_html( $lead->customer_phone ?? '' ); ?></a>
                        </td>
                        <td>
                            <?php echo esc_html( $lead->project_type ?? '' ); ?><br>
                            <small><?php echo esc_html( number_format( (int) ( $lead->square_footage ?? 0 ) ) ); ?> sq ft</small>
                        </td>
                        <td>
                            <span class="timeline-badge <?php echo esc_attr( $timeline_class ); ?>">
                                <?php echo esc_html( $lead->timeline ?? '' ); ?>
                            </span>
                        </td>
                        <td>
                            <?php
                            if ( ! empty( $lead->estimated_cost_min ) && ! empty( $lead->estimated_cost_max ) ) {
                                echo esc_html( '$' . number_format( $lead->estimated_cost_min ) . ' - $' . number_format( $lead->estimated_cost_max ) );
                            } else {
                                echo esc_html__( 'N/A', 'smart-forms-for-midland' );
                            }
                            ?>
                        </td>
                        <td><?php echo esc_html( date_i18n( 'M j, Y', strtotime( $lead->created_at ?? 'now' ) ) ); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
}

new SFCO_Admin();
