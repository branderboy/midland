<?php
/**
 * Admin dashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SFCO_Admin {
    
    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_menu_pages' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
    }
    
    public function add_menu_pages() {
        add_menu_page(
            esc_html__( 'Smart Forms', 'smart-forms-for-midland' ),
            esc_html__( 'Smart Forms', 'smart-forms-for-midland' ),
            'manage_options',
            'smart-forms-leads',
            array( $this, 'render_leads_page' ),
            'dashicons-forms',
            30
        );
    }
    
    public function enqueue_admin_assets( $hook ) {
        if ( strpos( $hook, 'smart-forms' ) === false ) {
            return;
        }
        
        wp_enqueue_style( 'sfco-admin', SFCO_PLUGIN_URL . 'assets/css/admin.css', array(), SFCO_VERSION );
        wp_enqueue_script( 'sfco-admin', SFCO_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery' ), SFCO_VERSION, true );
    }
    
    public function render_leads_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filtering, no data modification
        $filter_status = isset( $_GET['status'] ) ? sanitize_text_field( wp_unslash( $_GET['status'] ) ) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filtering, no data modification
        $filter_timeline = isset( $_GET['timeline'] ) ? sanitize_text_field( wp_unslash( $_GET['timeline'] ) ) : '';

        $leads = SFCO_Database::get_leads( array(
            'status' => $filter_status,
            'timeline' => $filter_timeline,
            'limit' => 50,
        ) );
        
        ?>
        <div class="wrap">
            <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
            
            <div class="smart-forms-filters">
                <select name="status" onchange="location = this.value;">
                    <option value="<?php echo esc_url( admin_url( 'admin.php?page=smart-forms-leads' ) ); ?>"><?php esc_html_e( 'All Statuses', 'smart-forms-for-midland' ); ?></option>
                    <option value="<?php echo esc_url( add_query_arg( 'status', 'new' ) ); ?>" <?php selected( $filter_status, 'new' ); ?>><?php esc_html_e( 'New', 'smart-forms-for-midland' ); ?></option>
                    <option value="<?php echo esc_url( add_query_arg( 'status', 'contacted' ) ); ?>" <?php selected( $filter_status, 'contacted' ); ?>><?php esc_html_e( 'Contacted', 'smart-forms-for-midland' ); ?></option>
                    <option value="<?php echo esc_url( add_query_arg( 'status', 'quoted' ) ); ?>" <?php selected( $filter_status, 'quoted' ); ?>><?php esc_html_e( 'Quoted', 'smart-forms-for-midland' ); ?></option>
                    <option value="<?php echo esc_url( add_query_arg( 'status', 'won' ) ); ?>" <?php selected( $filter_status, 'won' ); ?>><?php esc_html_e( 'Won', 'smart-forms-for-midland' ); ?></option>
                    <option value="<?php echo esc_url( add_query_arg( 'status', 'lost' ) ); ?>" <?php selected( $filter_status, 'lost' ); ?>><?php esc_html_e( 'Lost', 'smart-forms-for-midland' ); ?></option>
                </select>
            </div>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'ID', 'smart-forms-for-midland' ); ?></th>
                        <th><?php esc_html_e( 'Customer', 'smart-forms-for-midland' ); ?></th>
                        <th><?php esc_html_e( 'Contact', 'smart-forms-for-midland' ); ?></th>
                        <th><?php esc_html_e( 'Project', 'smart-forms-for-midland' ); ?></th>
                        <th><?php esc_html_e( 'Timeline', 'smart-forms-for-midland' ); ?></th>
                        <th><?php esc_html_e( 'Estimate', 'smart-forms-for-midland' ); ?></th>
                        <th><?php esc_html_e( 'Date', 'smart-forms-for-midland' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $leads ) ) : ?>
                        <tr>
                            <td colspan="7"><?php esc_html_e( 'No leads found', 'smart-forms-for-midland' ); ?></td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ( $leads as $lead ) : ?>
                            <tr>
                                <td><?php echo esc_html( $lead->id ); ?></td>
                                <td><strong><?php echo esc_html( $lead->customer_name ); ?></strong></td>
                                <td>
                                    <a href="mailto:<?php echo esc_attr( $lead->customer_email ); ?>"><?php echo esc_html( $lead->customer_email ); ?></a><br>
                                    <a href="tel:<?php echo esc_attr( $lead->customer_phone ); ?>"><?php echo esc_html( $lead->customer_phone ); ?></a>
                                </td>
                                <td>
                                    <?php echo esc_html( $lead->project_type ); ?><br>
                                    <small><?php echo esc_html( number_format( $lead->square_footage ) ); ?> sq ft</small>
                                </td>
                                <td>
                                    <?php
                                    $timeline_class = '';
                                    switch ( $lead->timeline ) {
                                        case 'ASAP':
                                            $timeline_class = 'timeline-urgent';
                                            break;
                                        case 'This Week':
                                            $timeline_class = 'timeline-soon';
                                            break;
                                        default:
                                            $timeline_class = 'timeline-normal';
                                    }
                                    ?>
                                    <span class="timeline-badge <?php echo esc_attr( $timeline_class ); ?>">
                                        <?php echo esc_html( $lead->timeline ); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php
                                    if ( $lead->estimated_cost_min && $lead->estimated_cost_max ) {
                                        echo esc_html( '$' . number_format( $lead->estimated_cost_min ) . ' - $' . number_format( $lead->estimated_cost_max ) );
                                    } else {
                                        echo esc_html__( 'N/A', 'smart-forms-for-midland' );
                                    }
                                    ?>
                                </td>
                                <td><?php echo esc_html( date_i18n( 'M j, Y', strtotime( $lead->created_at ) ) ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
}

new SFCO_Admin();
