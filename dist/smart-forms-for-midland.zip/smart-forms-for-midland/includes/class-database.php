<?php
/**
 * Database handler for Smart Forms
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SFCO_Database {
    
    public static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        $table_name = $wpdb->prefix . 'sfco_leads';
        
        $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            customer_name varchar(255) NOT NULL,
            customer_email varchar(255) NOT NULL,
            customer_phone varchar(50) NOT NULL,
            project_type varchar(100) NOT NULL,
            square_footage int(11) DEFAULT NULL,
            material_type varchar(100) DEFAULT NULL,
            finish_level varchar(100) DEFAULT NULL,
            timeline varchar(50) DEFAULT NULL,
            zip_code varchar(20) DEFAULT NULL,
            additional_notes text DEFAULT NULL,
            photo_urls text DEFAULT NULL,
            estimated_cost_min decimal(10,2) DEFAULT NULL,
            estimated_cost_max decimal(10,2) DEFAULT NULL,
            status varchar(50) DEFAULT 'new',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY timeline (timeline),
            KEY status (status),
            KEY created_at (created_at)
        ) {$charset_collate};";
        
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
        
        update_option( 'sfco_version', SFCO_VERSION );
    }
    
    public static function get_lead( $lead_id ) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'sfco_leads';
        // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is built from $wpdb->prefix; $sql is prepared.
        $sql = $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d",
            absint( $lead_id )
        );
        return $wpdb->get_row( $sql );
        // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,PluginCheck.Security.DirectDB.UnescapedDBParameter
    }
    
    public static function get_leads( $args = array() ) {
        global $wpdb;
        
        $defaults = array(
            'status'   => '',
            'timeline' => '',
            'limit'    => 20,
            'offset'   => 0,
            'orderby'  => 'created_at',
            'order'    => 'DESC',
        );
        
        $args = wp_parse_args( $args, $defaults );
        
        $allowed_orderby = array( 'created_at', 'status', 'timeline', 'id', 'customer_name' );
        $orderby         = in_array( $args['orderby'], $allowed_orderby, true ) ? $args['orderby'] : 'created_at';
        $order           = ( 'ASC' === strtoupper( $args['order'] ) ) ? 'ASC' : 'DESC';
        $table           = $wpdb->prefix . 'sfco_leads';
        
        $where_sql = '1=1';
        $prepare   = array();
        
        if ( ! empty( $args['status'] ) ) {
            $where_sql .= ' AND status = %s';
            $prepare[] = sanitize_text_field( $args['status'] );
        }
        
        if ( ! empty( $args['timeline'] ) ) {
            $where_sql .= ' AND timeline = %s';
            $prepare[] = sanitize_text_field( $args['timeline'] );
        }
        
        $prepare[] = absint( $args['limit'] );
        $prepare[] = absint( $args['offset'] );
        
        // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name built from $wpdb->prefix; $where_sql built with placeholders; $orderby/$order are allow-listed; $sql is prepared.
        $sql = $wpdb->prepare(
            "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d",
            $prepare
        );
        return $wpdb->get_results( $sql );
        // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,PluginCheck.Security.DirectDB.UnescapedDBParameter
    }
    
    public static function create_lead( $data ) {
        global $wpdb;
        $table = $wpdb->prefix . 'sfco_leads';
        
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom table owned by plugin.
        $wpdb->insert(
            $table,
            array(
                'customer_name' => sanitize_text_field( $data['customer_name'] ),
                'customer_email' => sanitize_email( $data['customer_email'] ),
                'customer_phone' => sanitize_text_field( $data['customer_phone'] ),
                'project_type' => sanitize_text_field( $data['project_type'] ),
                'square_footage' => isset( $data['square_footage'] ) ? absint( $data['square_footage'] ) : null,
                'material_type' => isset( $data['material_type'] ) ? sanitize_text_field( $data['material_type'] ) : null,
                'finish_level' => isset( $data['finish_level'] ) ? sanitize_text_field( $data['finish_level'] ) : null,
                'timeline' => isset( $data['timeline'] ) ? sanitize_text_field( $data['timeline'] ) : null,
                'zip_code' => isset( $data['zip_code'] ) ? sanitize_text_field( $data['zip_code'] ) : null,
                'additional_notes' => isset( $data['additional_notes'] ) ? sanitize_textarea_field( $data['additional_notes'] ) : null,
                'photo_urls' => isset( $data['photo_urls'] ) ? wp_json_encode( $data['photo_urls'] ) : null,
                'estimated_cost_min' => isset( $data['estimated_cost_min'] ) ? floatval( $data['estimated_cost_min'] ) : null,
                'estimated_cost_max' => isset( $data['estimated_cost_max'] ) ? floatval( $data['estimated_cost_max'] ) : null,
            ),
            array( '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%f', '%f' )
        );
        
        return $wpdb->insert_id;
    }
    
    public static function update_lead_status( $lead_id, $status ) {
        global $wpdb;
        $table = $wpdb->prefix . 'sfco_leads';
        
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table owned by plugin.
        return $wpdb->update(
            $table,
            array( 'status' => sanitize_text_field( $status ) ),
            array( 'id' => absint( $lead_id ) ),
            array( '%s' ),
            array( '%d' )
        );
    }
}
