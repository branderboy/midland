<?php
/**
 * Plugin Name: Midland Smart Reviews
 * Description: Midland-branded survey-gated review collection. A 1–5 star survey fires automatically after job completion (driven by sfco_lead_completed + sfco_lead_status_changed actions from Midland Smart Forms / Smart CRM). Score ≥4★ sends the Google review link + up to 3 follow-up reminders; score <4★ captures private feedback only and emails the manager — no public review request.
 * Version: 1.5.3
 * Author: Midland Floor Care
 * Author URI: https://midlandfloors.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: smart-reviews-pro
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Requires Plugins: smart-forms-for-midland
 * Tested up to: 6.7
 * Update URI: false
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'SRP_VERSION', '1.5.3' );
define( 'SRP_PATH',    plugin_dir_path( __FILE__ ) );
define( 'SRP_URL',     plugin_dir_url( __FILE__ ) );
define( 'SRP_FILE',    __FILE__ );

class Smart_Reviews_Pro {

    private static $instance = null;

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        register_activation_hook( SRP_FILE, array( $this, 'activate' ) );
        register_deactivation_hook( SRP_FILE, array( $this, 'deactivate' ) );
        add_action( 'plugins_loaded', array( $this, 'init' ) );
    }

    public function activate() {
        require_once SRP_PATH . 'includes/class-srp-db.php';
        SRP_DB::create_tables();
    }

    public function deactivate() {
        // Clear the hooks this plugin actually schedules. (The old code cleared
        // 'srp_send_reminders', which is never registered, so the real cron
        // events were left orphaned in WP-Cron.)
        wp_clear_scheduled_hook( 'srp_cron_reminders' );  // hourly survey reminders
        wp_clear_scheduled_hook( 'srp_crm_poll' );        // hourly CRM poll
        // srp_review_reminder is scheduled WITH an arg (the survey id), so
        // wp_clear_scheduled_hook() (no args) would leave those events orphaned.
        // wp_unschedule_hook() removes every event for the hook regardless of args.
        wp_unschedule_hook( 'srp_review_reminder' );      // 48h GMB review nudges (per-survey args)
    }

    public function init() {
        load_plugin_textdomain( 'smart-reviews-pro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
        $this->includes();
        SRP_DB::maybe_upgrade(); // add new columns on existing installs without reactivation
        $this->boot();
    }

    private function includes() {
        require_once SRP_PATH . 'includes/class-srp-db.php';
        require_once SRP_PATH . 'includes/class-srp-survey.php';
        require_once SRP_PATH . 'includes/class-srp-review-router.php';
        require_once SRP_PATH . 'includes/class-srp-admin.php';
        require_once SRP_PATH . 'includes/class-srp-crm-integration.php';
    }

    private function boot() {
        SRP_Survey::get_instance();
        SRP_Review_Router::get_instance();
        SRP_Admin::get_instance();
        SRP_CRM_Integration::get_instance();
    }
}

Smart_Reviews_Pro::get_instance();
