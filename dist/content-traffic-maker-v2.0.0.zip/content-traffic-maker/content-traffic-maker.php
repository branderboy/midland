<?php
/**
 * Plugin Name: Content Traffic Maker
 * Description: Video Content Intelligence Engine — daily SEO, offer, and viral video briefs with trend validation, proof sources, editing workflow, performance tracking, and multi-client support.
 * Version: 2.0.0
 * Author: Midland Floor Care
 * Author URI: https://midlandfloors.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: content-traffic-maker
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Tested up to: 6.7
 * Update URI: false
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CTM_VERSION', '2.0.0' );
define( 'CTM_FILE', __FILE__ );
define( 'CTM_PATH', plugin_dir_path( __FILE__ ) );
define( 'CTM_URL', plugin_dir_url( __FILE__ ) );

require_once CTM_PATH . 'includes/class-wgb-settings.php';
require_once CTM_PATH . 'includes/class-db.php';
require_once CTM_PATH . 'includes/class-generator.php';
require_once CTM_PATH . 'includes/class-emailer.php';
require_once CTM_PATH . 'includes/class-cron.php';
require_once CTM_PATH . 'includes/class-admin.php';

final class Content_Traffic_Maker {

	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		register_activation_hook( CTM_FILE, array( $this, 'activate' ) );
		register_deactivation_hook( CTM_FILE, array( $this, 'deactivate' ) );
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	public function activate() {
		CTM_DB::create_table();
		add_filter( 'cron_schedules', array( 'CTM_Cron', 'add_schedules' ) );
		CTM_Cron::reschedule();
	}

	public function deactivate() {
		CTM_Cron::clear();
	}

	public function init() {
		CTM_DB::maybe_upgrade();
		add_filter( 'cron_schedules', array( 'CTM_Cron', 'add_schedules' ) );
		CTM_Admin::get_instance();
		CTM_Cron::get_instance();
	}
}

Content_Traffic_Maker::get_instance();
