<?php
/**
 * Video brief generator — 6 videos per client: 3 per segment (SEO + Offer + Viral).
 * v2.0: Trend validation layer, proof source metadata, confidence scoring,
 *       tone-aware prompts, competitor awareness.
 *
 * @package ContentTrafficMaker
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CTM_Generator {

	const ENDPOINT = 'https://api.perplexity.ai/chat/completions';

	/**
	 * All JSON keys the brief must contain.
	 */
	public static function fields() {
		$segments = array( 'com', 'res' );
		$types    = array( 'seo', 'offer', 'viral' );
		$fields   = array();

		foreach ( $segments as $seg ) {
			foreach ( $types as $type ) {
				$p = "{$seg}_{$type}";
				if ( 'seo' === $type ) {
					$fields = array_merge( $fields, array(
						"{$p}_keyword", "{$p}_search_intent", "{$p}_video_title",
						"{$p}_hook", "{$p}_cta", "{$p}_difficulty",
						"{$p}_priority", "{$p}_example_title", "{$p}_example_url",
						"{$p}_example_platform", "{$p}_example_date", "{$p}_confidence",
					) );
				} elseif ( 'offer' === $type ) {
					$fields = array_merge( $fields, array(
						"{$p}_video_title", "{$p}_name", "{$p}_audience",
						"{$p}_hook", "{$p}_cta", "{$p}_priority",
						"{$p}_example_title", "{$p}_example_url",
						"{$p}_example_platform", "{$p}_example_date", "{$p}_confidence",
					) );
				} elseif ( 'viral' === $type ) {
					$fields = array_merge( $fields, array(
						"{$p}_video_title", "{$p}_trending_format", "{$p}_concept",
						"{$p}_opening_shot", "{$p}_trend_reason", "{$p}_cta",
						"{$p}_priority", "{$p}_example_title", "{$p}_example_url",
						"{$p}_example_platform", "{$p}_example_date", "{$p}_confidence",
						"{$p}_trend_evidence",
					) );
				}
			}
		}
		$fields[] = 'brief_date';
		return $fields;
	}

	private static function int_keys() {
		return array(
			'com_seo_priority', 'com_offer_priority', 'com_viral_priority',
			'res_seo_priority', 'res_offer_priority', 'res_viral_priority',
			'com_seo_confidence', 'com_offer_confidence', 'com_viral_confidence',
			'res_seo_confidence', 'res_offer_confidence', 'res_viral_confidence',
		);
	}

	private static function url_keys() {
		return array(
			'com_seo_example_url', 'com_offer_example_url', 'com_viral_example_url',
			'res_seo_example_url', 'res_offer_example_url', 'res_viral_example_url',
		);
	}

	/**
	 * Generate a brief for a given set of settings. Returns array or WP_Error.
	 */
	public static function generate( $settings ) {
		$api_key = trim( (string) ( $settings['api_key'] ?? '' ) );
		if ( '' === $api_key ) {
			return new WP_Error( 'no_api_key', 'Perplexity API key is not set.' );
		}

		$model  = sanitize_text_field( (string) ( $settings['model'] ?? 'sonar-pro' ) );
		$schema = self::json_schema();

		$body = array(
			'model'           => $model,
			'max_tokens'      => 8000,
			'temperature'     => 0.4,
			'response_format' => array(
				'type'        => 'json_schema',
				'json_schema' => array(
					'schema' => $schema,
					'name'   => 'video_brief',
					'strict' => true,
				),
			),
			'messages'        => array(
				array( 'role' => 'system',  'content' => self::system_prompt() ),
				array( 'role' => 'user',    'content' => self::build_prompt( $settings ) ),
			),
		);

		$response = wp_remote_post(
			self::ENDPOINT,
			array(
				'timeout' => 90,
				'headers' => array(
					'Authorization' => 'Bearer ' . $api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$raw  = wp_remote_retrieve_body( $response );

		if ( 200 !== (int) $code ) {
			$err = json_decode( $raw, true );
			$msg = isset( $err['error']['message'] ) ? $err['error']['message'] : "HTTP {$code}";
			return new WP_Error( 'api_error', "Perplexity API error: {$msg}" );
		}

		$data    = json_decode( $raw, true );
		$content = $data['choices'][0]['message']['content'] ?? '';
		$brief   = self::extract_json( $content );

		if ( ! is_array( $brief ) ) {
			return new WP_Error( 'parse_error', 'Could not parse JSON from API response.' );
		}

		// Inject real source URLs from search_results if available
		$search_results = $data['search_results'] ?? ( $data['citations'] ?? array() );
		if ( ! empty( $search_results ) ) {
			$brief = self::inject_proof_sources( $brief, $search_results );
		}

		return self::sanitize_brief( $brief );
	}

	/**
	 * Match search results to each video's example fields intelligently.
	 * Uses keyword matching against the video title / trend to pick the best source.
	 */
	private static function inject_proof_sources( $brief, $search_results ) {
		$url_keys = self::url_keys();

		// Map each url key to its corresponding title key and a search term
		$key_map = array(
			'com_seo_example_url'   => array( 'title_key' => 'com_seo_example_title',   'term_key' => 'com_seo_keyword' ),
			'com_offer_example_url' => array( 'title_key' => 'com_offer_example_title', 'term_key' => 'com_offer_name' ),
			'com_viral_example_url' => array( 'title_key' => 'com_viral_example_title', 'term_key' => 'com_viral_trending_format' ),
			'res_seo_example_url'   => array( 'title_key' => 'res_seo_example_title',   'term_key' => 'res_seo_keyword' ),
			'res_offer_example_url' => array( 'title_key' => 'res_offer_example_title', 'term_key' => 'res_offer_name' ),
			'res_viral_example_url' => array( 'title_key' => 'res_viral_example_title', 'term_key' => 'res_viral_trending_format' ),
		);

		// Build a flat array of search result {title, url} for matching
		$sources = array();
		foreach ( $search_results as $sr ) {
			$url   = $sr['url'] ?? '';
			$title = $sr['title'] ?? $sr['name'] ?? '';
			if ( $url && $title ) {
				$sources[] = array( 'url' => $url, 'title' => $title );
			}
		}

		if ( empty( $sources ) ) {
			return $brief;
		}

		$used = array();

		foreach ( $key_map as $url_key => $meta ) {
			$title_key = $meta['title_key'];
			$term_key  = $meta['term_key'];
			$term      = strtolower( (string) ( $brief[ $term_key ] ?? '' ) );
			$video_title = strtolower( (string) ( $brief[ $title_key ] ?? '' ) );

			$best_score = -1;
			$best_idx   = -1;

			foreach ( $sources as $idx => $src ) {
				if ( in_array( $idx, $used, true ) ) {
					continue;
				}
				$src_text = strtolower( $src['title'] . ' ' . $src['url'] );
				$score    = 0;

				// Score by word overlap between search term and source
				$term_words = array_filter( explode( ' ', $term ) );
				foreach ( $term_words as $word ) {
					if ( strlen( $word ) > 3 && strpos( $src_text, $word ) !== false ) {
						$score++;
					}
				}
				// Bonus for TikTok/YouTube in URL
				if ( strpos( $src['url'], 'tiktok.com' ) !== false || strpos( $src['url'], 'youtube.com' ) !== false ) {
					$score += 2;
				}

				if ( $score > $best_score ) {
					$best_score = $score;
					$best_idx   = $idx;
				}
			}

			if ( $best_idx >= 0 ) {
				// Only override if LLM left the URL empty or we found a better match
				if ( empty( $brief[ $url_key ] ) || $best_score > 1 ) {
					$brief[ $url_key ] = $sources[ $best_idx ]['url'];
					$used[]            = $best_idx;
				}
			}
		}

		return $brief;
	}

	private static function system_prompt() {
		return 'You are a Video Content Intelligence Engine for local service businesses. Your job is to produce highly specific, actionable video briefs with real proof sources.

PROOF REQUIREMENTS (critical):
- Every example must be a real, verifiable video or content piece. Use your live web search.
- example_url: must be a real URL from TikTok, YouTube, Instagram, or a credible media source. If you cannot verify a real URL, leave it empty — DO NOT fabricate URLs.
- example_platform: which platform the example lives on (TikTok, YouTube, Instagram, etc.)
- example_date: when this was published or when you found it trending (month/year format)
- confidence: integer 1-10 reflecting how confident you are this example is real and currently active

TREND VALIDATION (for viral videos):
- trend_evidence: cite specific evidence the trend is active RIGHT NOW — name real creators using it, view counts, hashtag volumes, or platform trends pages. Be specific.
- trending_format: this must be a named, identifiable trend (e.g. "Day in the Life", "Before & After Reveal", "Silent Tutorial", "Stitch Chain") — not a vague description.

LANGUAGE RULES:
- Write like a real person talking, not a marketer.
- Video titles must sound like real TikTok captions or YouTube titles.
- BAD: "VCT Strip and Wax Maintenance for DC Facility Managers"
- GOOD: "This DC Office Floor Hadn\'t Been Cleaned in 2 Years. Watch What Happened."
- Hooks must stop the scroll. First 8 words, punchy, no jargon.
- Offers must feel like real deals.

Return ONLY valid JSON matching the schema provided. No prose, no markdown, no code fences.';
	}

	public static function build_prompt( $settings ) {
		$business    = sanitize_text_field( (string) ( $settings['business_name'] ?? '' ) );
		$city        = sanitize_text_field( (string) ( $settings['target_city']   ?? '' ) );
		$state       = sanitize_text_field( (string) ( $settings['target_state']  ?? '' ) );
		$label_a     = sanitize_text_field( (string) ( $settings['segment_a_label']    ?? 'Commercial' ) );
		$aud_a       = sanitize_text_field( (string) ( $settings['segment_a_audience'] ?? '' ) );
		$svc_a       = sanitize_text_field( (string) ( $settings['segment_a_services'] ?? '' ) );
		$label_b     = sanitize_text_field( (string) ( $settings['segment_b_label']    ?? 'Residential' ) );
		$aud_b       = sanitize_text_field( (string) ( $settings['segment_b_audience'] ?? '' ) );
		$svc_b       = sanitize_text_field( (string) ( $settings['segment_b_services'] ?? '' ) );
		$tone        = sanitize_text_field( (string) ( $settings['tone'] ?? 'conversational' ) );
		$competitors = sanitize_text_field( (string) ( $settings['competitors'] ?? '' ) );
		$today       = gmdate( 'F j, Y' );

		$competitor_line = $competitors ? "\nKnown competitors to differentiate from: {$competitors}" : '';
		$tone_line       = "Tone: {$tone}";

		return "Today is {$today}. Business: {$business}, {$city}, {$state}.
{$tone_line}{$competitor_line}

━━━ {$label_a} SEGMENT (com_* keys) ━━━
Audience: {$aud_a}
Services: {$svc_a}

[{$label_a} SEO VIDEO — com_seo_* keys]
keyword, search_intent, video_title, hook (first 8 words), cta, difficulty (Easy/Medium/Hard), priority (1-10)
example_title, example_url (verified), example_platform, example_date, confidence (1-10)

[{$label_a} OFFER VIDEO — com_offer_* keys]
video_title, name (the actual offer), audience, hook, cta, priority (1-10)
example_title, example_url (verified), example_platform, example_date, confidence (1-10)

[{$label_a} VIRAL VIDEO — com_viral_* keys]
video_title, trending_format (named trend active RIGHT NOW), concept, opening_shot, trend_reason, cta, priority (1-10)
example_title, example_url (verified), example_platform, example_date, confidence (1-10)
trend_evidence: cite SPECIFIC evidence this trend is active now (creator names, view counts, hashtag data)

━━━ {$label_b} SEGMENT (res_* keys) ━━━
Audience: {$aud_b}
Services: {$svc_b}

[{$label_b} SEO VIDEO — res_seo_* keys]
keyword, search_intent, video_title, hook, cta, difficulty, priority (1-10)
example_title, example_url (verified), example_platform, example_date, confidence (1-10)

[{$label_b} OFFER VIDEO — res_offer_* keys]
video_title, name, audience, hook, cta, priority (1-10)
example_title, example_url (verified), example_platform, example_date, confidence (1-10)

[{$label_b} VIRAL VIDEO — res_viral_* keys]
video_title, trending_format (named, active now), concept, opening_shot, trend_reason, cta, priority (1-10)
example_title, example_url (verified), example_platform, example_date, confidence (1-10)
trend_evidence: cite SPECIFIC evidence

brief_date: \"{$today}\"";
	}

	private static function json_schema() {
		$int_keys = self::int_keys();
		$properties = array();

		foreach ( self::fields() as $key ) {
			if ( in_array( $key, $int_keys, true ) ) {
				$properties[ $key ] = array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 10 );
			} else {
				$properties[ $key ] = array( 'type' => 'string' );
			}
		}

		return array(
			'type'                 => 'object',
			'properties'           => $properties,
			'required'             => array_values( self::fields() ),
			'additionalProperties' => false,
		);
	}

	private static function extract_json( $content ) {
		$content = trim( $content );
		$decoded = json_decode( $content, true );
		if ( is_array( $decoded ) ) {
			return $decoded;
		}
		$content = preg_replace( '/^```(?:json)?|```$/m', '', $content );
		$start   = strpos( $content, '{' );
		$end     = strrpos( $content, '}' );
		if ( false !== $start && false !== $end && $end > $start ) {
			$decoded = json_decode( substr( $content, $start, $end - $start + 1 ), true );
			if ( is_array( $decoded ) ) {
				return $decoded;
			}
		}
		return null;
	}

	private static function sanitize_brief( $brief ) {
		$int_keys = self::int_keys();
		$url_keys = self::url_keys();
		$clean    = array();

		foreach ( self::fields() as $key ) {
			$val = $brief[ $key ] ?? '';
			if ( in_array( $key, $int_keys, true ) ) {
				$clean[ $key ] = max( 1, min( 10, (int) $val ) );
			} elseif ( in_array( $key, $url_keys, true ) ) {
				$clean[ $key ] = esc_url_raw( is_scalar( $val ) ? (string) $val : '' );
			} else {
				$clean[ $key ] = sanitize_textarea_field( is_scalar( $val ) ? (string) $val : wp_json_encode( $val ) );
			}
		}

		return $clean;
	}
}
