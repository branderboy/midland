<?php
/**
 * CTM_Crypto — standalone AES-256-CBC encryption for Content Traffic Maker.
 *
 * Completely self-contained: no dependency on WGB_Settings or any other
 * plugin class. If wp-github-backup is also active its WGB_Settings class
 * coexists without any conflict.
 *
 * Keys are stored under ctm_encryption_key (CTM's own option) so they are
 * never affected by wp-github-backup being uninstalled.
 *
 * Migration: values encrypted by the unpatched v1.9.0 (which used WGB_Settings
 * and therefore wgb_encryption_key) are transparently decrypted via legacy_key().
 *
 * @package ContentTrafficMaker
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( class_exists( 'CTM_Crypto' ) ) {
    return;
}

class CTM_Crypto {

    const AES_PREFIX = 'ctmaes:';
    const B64_PREFIX = 'ctmb64:';
    const CIPHER     = 'aes-256-cbc';

    /**
     * Return the 32-byte AES key, generating and persisting it on first use.
     * Stored in ctm_encryption_key — independent of any other plugin.
     */
    private static function key() {
        $stored = get_option( 'ctm_encryption_key', '' );
        if ( ! is_string( $stored ) || '' === $stored ) {
            if ( function_exists( 'random_bytes' ) ) {
                $raw = random_bytes( 32 );
            } elseif ( function_exists( 'openssl_random_pseudo_bytes' ) ) {
                $raw = openssl_random_pseudo_bytes( 32 );
            } else {
                $raw = hash( 'sha256', wp_salt( 'auth' ) . '|content-traffic-maker|v1|' . microtime( true ), true );
            }
            $stored = base64_encode( $raw );
            update_option( 'ctm_encryption_key', $stored, false );
            return $raw;
        }
        $decoded = base64_decode( $stored, true );
        return ( false !== $decoded && 32 === strlen( $decoded ) ) ? $decoded : hash( 'sha256', $stored, true );
    }

    /**
     * Migration key: decrypts values that were saved by the unpatched v1.9.0
     * which used WGB_Settings (and therefore wgb_encryption_key) for CTM keys.
     * Only tried as a fallback when current-key decryption returns false.
     */
    private static function legacy_key() {
        $stored = get_option( 'wgb_encryption_key', '' );
        if ( is_string( $stored ) && '' !== $stored ) {
            $decoded = base64_decode( $stored, true );
            return ( false !== $decoded && 32 === strlen( $decoded ) ) ? $decoded : hash( 'sha256', $stored, true );
        }
        // Pre-v1.9.0 fallback: salt-derived key used by early builds.
        return hash( 'sha256', wp_salt( 'auth' ) . '|content-traffic-maker|v1', true );
    }

    /**
     * Encrypt a plain-text secret for storage.
     *
     * @param  string $value Plain text.
     * @return string Encrypted payload with ctmaes: or ctmb64: prefix, or '' if empty.
     */
    public static function encrypt( $value ) {
        $value = (string) $value;
        if ( '' === $value ) {
            return '';
        }
        if ( function_exists( 'openssl_encrypt' ) && function_exists( 'random_bytes' ) ) {
            try {
                $iv     = random_bytes( 16 );
                $cipher = openssl_encrypt( $value, self::CIPHER, self::key(), OPENSSL_RAW_DATA, $iv );
                if ( false !== $cipher ) {
                    return self::AES_PREFIX . base64_encode( $iv . $cipher );
                }
            } catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
                // Fall through to base64 mode.
            }
        }
        return self::B64_PREFIX . base64_encode( $value );
    }

    /**
     * Decrypt a stored secret.
     *
     * Handles four formats:
     *   'ctmaes:…'  — AES-256-CBC encrypted by this class (current).
     *   'ctmb64:…'  — base64 obfuscation fallback by this class.
     *   'wgbaes:…'  — AES-256-CBC written by unpatched v1.9.0 via WGB_Settings.
     *   'b64:…'     — base64 written by unpatched v1.9.0 via WGB_Settings.
     *
     * @param  string $value Stored payload.
     * @return string Plain text, or '' on failure.
     */
    public static function decrypt( $value ) {
        $value = (string) $value;
        if ( '' === $value ) {
            return '';
        }

        // Current CTM AES format.
        if ( 0 === strpos( $value, self::AES_PREFIX ) ) {
            $raw = base64_decode( substr( $value, strlen( self::AES_PREFIX ) ), true );
            if ( false === $raw || strlen( $raw ) < 17 ) {
                return '';
            }
            $iv     = substr( $raw, 0, 16 );
            $cipher = substr( $raw, 16 );
            $plain  = openssl_decrypt( $cipher, self::CIPHER, self::key(), OPENSSL_RAW_DATA, $iv );
            return false === $plain ? '' : $plain;
        }

        // Current CTM base64 format.
        if ( 0 === strpos( $value, self::B64_PREFIX ) ) {
            $plain = base64_decode( substr( $value, strlen( self::B64_PREFIX ) ), true );
            return false === $plain ? '' : $plain;
        }

        // Legacy WGB AES format (written by unpatched v1.9.0).
        if ( 0 === strpos( $value, 'wgbaes:' ) ) {
            $raw = base64_decode( substr( $value, strlen( 'wgbaes:' ) ), true );
            if ( false === $raw || strlen( $raw ) < 17 ) {
                return '';
            }
            $iv     = substr( $raw, 0, 16 );
            $cipher = substr( $raw, 16 );
            $plain  = openssl_decrypt( $cipher, self::CIPHER, self::legacy_key(), OPENSSL_RAW_DATA, $iv );
            return false === $plain ? '' : $plain;
        }

        // Legacy WGB base64 format (written by unpatched v1.9.0).
        if ( 0 === strpos( $value, 'b64:' ) ) {
            $plain = base64_decode( substr( $value, strlen( 'b64:' ) ), true );
            return false === $plain ? '' : $plain;
        }

        // Raw plain text (stored before any encryption existed).
        return $value;
    }

    /**
     * True when AES-256 encryption is available on this host.
     *
     * @return bool
     */
    public static function is_openssl_available() {
        return function_exists( 'openssl_encrypt' ) && function_exists( 'random_bytes' );
    }
}
