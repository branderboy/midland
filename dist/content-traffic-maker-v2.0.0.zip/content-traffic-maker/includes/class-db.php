<?php
/**
 * Database layer — briefs table, clients table, performance table, settings.
 *
 * @package ContentTrafficMaker
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CTM_DB {

	const BRIEFS_TABLE   = 'ctm_briefs';
	const CLIENTS_TABLE  = 'ctm_clients';
	const PERF_TABLE     = 'ctm_performance';
	const EMAIL_LOG      = 'ctm_email_log';
	const OPTION         = 'ctm_settings';
	const DB_VERSION     = '2.0.0';
	const DB_VERS_KEY    = 'ctm_db_version';

	public static function table( $name ) {
		global $wpdb;
		return $wpdb->prefix . $name;
	}

	public static function create_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();

		// Briefs table — now includes client_id, status workflow, draft support
		$briefs = self::table( self::BRIEFS_TABLE );
		dbDelta( "CREATE TABLE {$briefs} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			client_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			brief_json LONGTEXT NULL,
			brief_html LONGTEXT NULL,
			status VARCHAR(30) NOT NULL DEFAULT 'draft',
			created_at DATETIME NOT NULL DEFAULT '1970-01-01 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '1970-01-01 00:00:00',
			sent_to VARCHAR(255) NOT NULL DEFAULT '',
			sent_at DATETIME NULL,
			notes TEXT NULL,
			PRIMARY KEY (id),
			KEY client_id (client_id),
			KEY created_at (created_at),
			KEY status (status)
		) {$charset};" );

		// Clients table
		$clients = self::table( self::CLIENTS_TABLE );
		dbDelta( "CREATE TABLE {$clients} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(255) NOT NULL DEFAULT '',
			business_name VARCHAR(255) NOT NULL DEFAULT '',
			target_city VARCHAR(100) NOT NULL DEFAULT '',
			target_state VARCHAR(50) NOT NULL DEFAULT '',
			segment_a_label VARCHAR(100) NOT NULL DEFAULT 'Commercial',
			segment_a_audience TEXT NULL,
			segment_a_services TEXT NULL,
			segment_a_sub VARCHAR(255) NOT NULL DEFAULT '',
			segment_b_label VARCHAR(100) NOT NULL DEFAULT 'Residential',
			segment_b_audience TEXT NULL,
			segment_b_services TEXT NULL,
			segment_b_sub VARCHAR(255) NOT NULL DEFAULT '',
			recipient VARCHAR(255) NOT NULL DEFAULT '',
			from_name VARCHAR(255) NOT NULL DEFAULT '',
			from_email VARCHAR(255) NOT NULL DEFAULT '',
			frequency VARCHAR(20) NOT NULL DEFAULT 'weekly',
			send_time VARCHAR(10) NOT NULL DEFAULT '08:00',
			enabled TINYINT(1) NOT NULL DEFAULT 0,
			tone VARCHAR(50) NOT NULL DEFAULT 'conversational',
			competitors TEXT NULL,
			notes TEXT NULL,
			created_at DATETIME NOT NULL DEFAULT '1970-01-01 00:00:00',
			PRIMARY KEY (id)
		) {$charset};" );

		// Performance tracker
		$perf = self::table( self::PERF_TABLE );
		dbDelta( "CREATE TABLE {$perf} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			brief_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			client_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			video_key VARCHAR(50) NOT NULL DEFAULT '',
			posted_url VARCHAR(500) NOT NULL DEFAULT '',
			platform VARCHAR(50) NOT NULL DEFAULT '',
			views INT(11) NOT NULL DEFAULT 0,
			watch_time_minutes INT(11) NOT NULL DEFAULT 0,
			clicks INT(11) NOT NULL DEFAULT 0,
			leads INT(11) NOT NULL DEFAULT 0,
			booked_jobs INT(11) NOT NULL DEFAULT 0,
			winner TINYINT(1) NOT NULL DEFAULT 0,
			notes TEXT NULL,
			recorded_at DATETIME NOT NULL DEFAULT '1970-01-01 00:00:00',
			PRIMARY KEY (id),
			KEY brief_id (brief_id),
			KEY client_id (client_id)
		) {$charset};" );

		// Email delivery log
		$log = self::table( self::EMAIL_LOG );
		dbDelta( "CREATE TABLE {$log} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			brief_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			client_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			recipient VARCHAR(255) NOT NULL DEFAULT '',
			status VARCHAR(30) NOT NULL DEFAULT 'pending',
			provider VARCHAR(30) NOT NULL DEFAULT '',
			response_code INT(11) NULL,
			response_body TEXT NULL,
			sent_at DATETIME NOT NULL DEFAULT '1970-01-01 00:00:00',
			PRIMARY KEY (id),
			KEY brief_id (brief_id)
		) {$charset};" );

		update_option( self::DB_VERS_KEY, self::DB_VERSION );
	}

	public static function maybe_upgrade() {
		if ( get_option( self::DB_VERS_KEY ) !== self::DB_VERSION ) {
			self::create_table();
		}
	}

	// ── Global Settings ────────────────────────────────────────────────────────

	public static function get_settings() {
		$defaults = array(
			'api_key'        => '',
			'resend_api_key' => '',
			'active_client'  => 0,
		);
		$saved = get_option( self::OPTION, array() );
		$merged = wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );

		// Decrypt API keys
		if ( ! empty( $merged['api_key'] ) ) {
			$merged['api_key'] = CTM_Crypto::decrypt( $merged['api_key'] );
		}
		if ( ! empty( $merged['resend_api_key'] ) ) {
			$merged['resend_api_key'] = CTM_Crypto::decrypt( $merged['resend_api_key'] );
		}

		return $merged;
	}

	public static function update_settings( $data ) {
		$existing = get_option( self::OPTION, array() );
		if ( ! is_array( $existing ) ) {
			$existing = array();
		}

		foreach ( array( 'api_key', 'resend_api_key' ) as $key ) {
			if ( isset( $data[ $key ] ) ) {
				if ( '' === $data[ $key ] ) {
					unset( $data[ $key ] ); // Keep existing
				} else {
					$data[ $key ] = CTM_Crypto::encrypt( $data[ $key ] );
				}
			}
		}

		update_option( self::OPTION, array_merge( $existing, $data ) );
	}

	// ── Clients ────────────────────────────────────────────────────────────────

	public static function get_clients() {
		global $wpdb;
		$table = self::table( self::CLIENTS_TABLE );
		return $wpdb->get_results( "SELECT * FROM {$table} ORDER BY name ASC" ); // phpcs:ignore
	}

	public static function get_client( $id ) {
		global $wpdb;
		$table = self::table( self::CLIENTS_TABLE );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) ); // phpcs:ignore
	}

	public static function insert_client( $data ) {
		global $wpdb;
		$data['created_at'] = current_time( 'mysql' );
		$wpdb->insert( self::table( self::CLIENTS_TABLE ), $data ); // phpcs:ignore
		return (int) $wpdb->insert_id;
	}

	public static function update_client( $id, $data ) {
		global $wpdb;
		$wpdb->update( self::table( self::CLIENTS_TABLE ), $data, array( 'id' => $id ) ); // phpcs:ignore
	}

	public static function delete_client( $id ) {
		global $wpdb;
		$wpdb->delete( self::table( self::CLIENTS_TABLE ), array( 'id' => $id ) ); // phpcs:ignore
	}

	public static function client_to_settings( $client ) {
		if ( ! $client ) {
			return array();
		}
		return array(
			'business_name'      => $client->business_name,
			'target_city'        => $client->target_city,
			'target_state'       => $client->target_state,
			'segment_a_label'    => $client->segment_a_label,
			'segment_a_audience' => $client->segment_a_audience,
			'segment_a_services' => $client->segment_a_services,
			'segment_a_sub'      => $client->segment_a_sub,
			'segment_b_label'    => $client->segment_b_label,
			'segment_b_audience' => $client->segment_b_audience,
			'segment_b_services' => $client->segment_b_services,
			'segment_b_sub'      => $client->segment_b_sub,
			'recipient'          => $client->recipient,
			'from_name'          => $client->from_name,
			'from_email'         => $client->from_email,
			'frequency'          => $client->frequency,
			'send_time'          => $client->send_time,
			'enabled'            => $client->enabled,
			'tone'               => $client->tone,
			'competitors'        => $client->competitors,
		);
	}

	// ── Briefs ─────────────────────────────────────────────────────────────────

	public static function insert_brief( $data ) {
		global $wpdb;
		$now = current_time( 'mysql' );
		$wpdb->insert( // phpcs:ignore
			self::table( self::BRIEFS_TABLE ),
			array(
				'client_id'   => absint( $data['client_id'] ?? 0 ),
				'brief_json'  => wp_json_encode( $data['brief'] ?? array() ),
				'brief_html'  => (string) ( $data['brief_html'] ?? '' ),
				'status'      => sanitize_key( $data['status'] ?? 'draft' ),
				'created_at'  => $now,
				'updated_at'  => $now,
				'sent_to'     => sanitize_text_field( $data['sent_to'] ?? '' ),
				'notes'       => sanitize_textarea_field( $data['notes'] ?? '' ),
			)
		);
		return (int) $wpdb->insert_id;
	}

	public static function update_brief( $id, $data ) {
		global $wpdb;
		$data['updated_at'] = current_time( 'mysql' );
		if ( isset( $data['brief'] ) ) {
			$data['brief_json'] = wp_json_encode( $data['brief'] );
			unset( $data['brief'] );
		}
		$wpdb->update( self::table( self::BRIEFS_TABLE ), $data, array( 'id' => $id ) ); // phpcs:ignore
	}

	public static function get_brief( $id ) {
		global $wpdb;
		$table = self::table( self::BRIEFS_TABLE );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) ); // phpcs:ignore
	}

	public static function get_briefs( $limit = 20, $client_id = 0, $status = '' ) {
		global $wpdb;
		$table = self::table( self::BRIEFS_TABLE );
		$where = 'WHERE 1=1';
		$args  = array();
		if ( $client_id ) {
			$where .= ' AND client_id = %d';
			$args[] = $client_id;
		}
		if ( $status ) {
			$where .= ' AND status = %s';
			$args[] = $status;
		}
		$args[] = absint( $limit );
		$sql    = "SELECT * FROM {$table} {$where} ORDER BY created_at DESC LIMIT %d";
		if ( $args ) {
			$sql = $wpdb->prepare( $sql, ...$args ); // phpcs:ignore
		}
		return $wpdb->get_results( $sql ); // phpcs:ignore
	}

	// ── Performance ────────────────────────────────────────────────────────────

	public static function insert_performance( $data ) {
		global $wpdb;
		$data['recorded_at'] = current_time( 'mysql' );
		$wpdb->insert( self::table( self::PERF_TABLE ), $data ); // phpcs:ignore
		return (int) $wpdb->insert_id;
	}

	public static function get_performance( $brief_id ) {
		global $wpdb;
		$table = self::table( self::PERF_TABLE );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE brief_id = %d", $brief_id ) ); // phpcs:ignore
	}

	public static function get_top_performers( $client_id = 0, $limit = 10 ) {
		global $wpdb;
		$table = self::table( self::PERF_TABLE );
		$where = $client_id ? $wpdb->prepare( 'WHERE client_id = %d', $client_id ) : '';
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} {$where} ORDER BY views DESC LIMIT %d", $limit ) ); // phpcs:ignore
	}

	// ── Email Log ──────────────────────────────────────────────────────────────

	public static function log_email( $data ) {
		global $wpdb;
		$data['sent_at'] = current_time( 'mysql' );
		$wpdb->insert( self::table( self::EMAIL_LOG ), $data ); // phpcs:ignore
	}

	public static function get_email_log( $brief_id ) {
		global $wpdb;
		$table = self::table( self::EMAIL_LOG );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE brief_id = %d ORDER BY sent_at DESC", $brief_id ) ); // phpcs:ignore
	}

	public static function get_recent_email_log( $limit = 30 ) {
		global $wpdb;
		$table = self::table( self::EMAIL_LOG );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY sent_at DESC LIMIT %d", $limit ) ); // phpcs:ignore
	}
}
