<?php
/**
 * Admin — full Video Content Intelligence Engine command center.
 * v2.0: Dashboard, Clients, Brief Builder (edit/approve/reject/regenerate),
 *       Content Calendar, Performance Tracker, Email Log, Global Settings.
 *
 * @package ContentTrafficMaker
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CTM_Admin {

	const PAGE = 'content-traffic-maker';
	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu',            array( $this, 'add_menu' ) );
		add_action( 'admin_init',            array( $this, 'handle_saves' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_ajax_ctm_update_performance', array( $this, 'ajax_update_performance' ) );
		add_action( 'wp_ajax_ctm_update_brief_field',  array( $this, 'ajax_update_brief_field' ) );
		add_action( 'wp_ajax_ctm_regenerate_section',  array( $this, 'ajax_regenerate_section' ) );
		add_action( 'admin_post_ctm_generate_now',    array( $this, 'handle_generate_now' ) );
		add_action( 'admin_post_ctm_send_brief',      array( $this, 'handle_send_brief' ) );
		add_action( 'admin_post_ctm_approve_brief',   array( $this, 'handle_approve_brief' ) );
		add_action( 'admin_post_ctm_reject_brief',    array( $this, 'handle_reject_brief' ) );
		add_action( 'admin_post_ctm_save_client',     array( $this, 'handle_save_client' ) );
		add_action( 'admin_post_ctm_delete_client',   array( $this, 'handle_delete_client' ) );
		add_action( 'admin_post_ctm_send_test_email', array( $this, 'handle_send_test_email' ) );
		add_action( 'admin_post_ctm_save_settings',   array( $this, 'handle_save_settings' ) );
	}

	// ── Menu ───────────────────────────────────────────────────────────────────

	public function add_menu() {
		add_menu_page(
			__( 'Content Traffic Maker', 'content-traffic-maker' ),
			__( 'Content Traffic Maker', 'content-traffic-maker' ),
			'manage_options',
			self::PAGE,
			array( $this, 'render_dashboard' ),
			'dashicons-video-alt3',
			58
		);
		add_submenu_page( self::PAGE, __( 'Dashboard', 'content-traffic-maker' ),   __( 'Dashboard', 'content-traffic-maker' ),   'manage_options', self::PAGE,                    array( $this, 'render_dashboard' ) );
		add_submenu_page( self::PAGE, __( 'Clients', 'content-traffic-maker' ),     __( 'Clients', 'content-traffic-maker' ),     'manage_options', self::PAGE . '-clients',      array( $this, 'render_clients' ) );
		add_submenu_page( self::PAGE, __( 'Brief Builder', 'content-traffic-maker' ), __( 'Brief Builder', 'content-traffic-maker' ), 'manage_options', self::PAGE . '-briefs',  array( $this, 'render_briefs' ) );
		add_submenu_page( self::PAGE, __( 'Performance', 'content-traffic-maker' ),  __( 'Performance', 'content-traffic-maker' ),  'manage_options', self::PAGE . '-perf',      array( $this, 'render_performance' ) );
		add_submenu_page( self::PAGE, __( 'Email Log', 'content-traffic-maker' ),    __( 'Email Log', 'content-traffic-maker' ),    'manage_options', self::PAGE . '-emaillog',  array( $this, 'render_email_log' ) );
		add_submenu_page( self::PAGE, __( 'Settings', 'content-traffic-maker' ),     __( 'Settings', 'content-traffic-maker' ),     'manage_options', self::PAGE . '-settings',  array( $this, 'render_settings' ) );
	}

	public function enqueue_assets( $hook ) {
		if ( false === strpos( $hook, self::PAGE ) ) return;
		wp_enqueue_style( 'ctm-admin', CTM_URL . 'assets/admin.css', array(), CTM_VERSION );
		wp_enqueue_script( 'ctm-admin', CTM_URL . 'assets/admin.js', array( 'jquery' ), CTM_VERSION, true );
		wp_localize_script( 'ctm-admin', 'ctm', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'ctm_ajax' ),
		) );
	}

	// ── Action Handlers ────────────────────────────────────────────────────────

	public function handle_saves() {
		// Placeholder — actual saves handled via admin_post_* actions
	}

	public function handle_generate_now() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Insufficient permissions.' );
		check_admin_referer( 'ctm_generate_now' );
		$client_id = absint( $_POST['client_id'] ?? 0 );
		$result = CTM_Cron::generate_for_client( $client_id );
		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE . '-briefs', 'gen_error' => rawurlencode( $result->get_error_message() ) ), admin_url( 'admin.php' ) ) );
		} else {
			wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE . '-briefs', 'brief_id' => $result['brief_id'], 'generated' => 1 ), admin_url( 'admin.php' ) ) );
		}
		exit;
	}

	public function handle_send_brief() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Insufficient permissions.' );
		check_admin_referer( 'ctm_send_brief' );
		$brief_id = absint( $_POST['brief_id'] ?? 0 );
		$result = CTM_Cron::send_brief_by_id( $brief_id );
		$base = add_query_arg( array( 'page' => self::PAGE . '-briefs', 'brief_id' => $brief_id ), admin_url( 'admin.php' ) );
		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'send_error', rawurlencode( $result->get_error_message() ), $base ) );
		} else {
			wp_safe_redirect( add_query_arg( 'sent', 1, $base ) );
		}
		exit;
	}

	public function handle_approve_brief() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Insufficient permissions.' );
		check_admin_referer( 'ctm_approve_brief' );
		$brief_id = absint( $_POST['brief_id'] ?? 0 );
		CTM_DB::update_brief( $brief_id, array( 'status' => 'approved' ) );
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE . '-briefs', 'brief_id' => $brief_id, 'approved' => 1 ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function handle_reject_brief() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Insufficient permissions.' );
		check_admin_referer( 'ctm_reject_brief' );
		$brief_id = absint( $_POST['brief_id'] ?? 0 );
		CTM_DB::update_brief( $brief_id, array( 'status' => 'rejected' ) );
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE . '-briefs', 'brief_id' => $brief_id, 'rejected' => 1 ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function handle_save_client() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Insufficient permissions.' );
		check_admin_referer( 'ctm_save_client' );
		$id   = absint( $_POST['client_id'] ?? 0 );
		$data = array(
			'name'               => sanitize_text_field( wp_unslash( $_POST['name']               ?? '' ) ),
			'business_name'      => sanitize_text_field( wp_unslash( $_POST['business_name']      ?? '' ) ),
			'target_city'        => sanitize_text_field( wp_unslash( $_POST['target_city']        ?? '' ) ),
			'target_state'       => sanitize_text_field( wp_unslash( $_POST['target_state']       ?? '' ) ),
			'segment_a_label'    => sanitize_text_field( wp_unslash( $_POST['segment_a_label']    ?? 'Commercial' ) ),
			'segment_a_audience' => sanitize_textarea_field( wp_unslash( $_POST['segment_a_audience'] ?? '' ) ),
			'segment_a_services' => sanitize_textarea_field( wp_unslash( $_POST['segment_a_services'] ?? '' ) ),
			'segment_a_sub'      => sanitize_text_field( wp_unslash( $_POST['segment_a_sub']      ?? '' ) ),
			'segment_b_label'    => sanitize_text_field( wp_unslash( $_POST['segment_b_label']    ?? 'Residential' ) ),
			'segment_b_audience' => sanitize_textarea_field( wp_unslash( $_POST['segment_b_audience'] ?? '' ) ),
			'segment_b_services' => sanitize_textarea_field( wp_unslash( $_POST['segment_b_services'] ?? '' ) ),
			'segment_b_sub'      => sanitize_text_field( wp_unslash( $_POST['segment_b_sub']      ?? '' ) ),
			'recipient'          => sanitize_email( wp_unslash( $_POST['recipient']          ?? '' ) ),
			'from_name'          => sanitize_text_field( wp_unslash( $_POST['from_name']          ?? '' ) ),
			'from_email'         => sanitize_email( wp_unslash( $_POST['from_email']          ?? '' ) ),
			'frequency'          => in_array( sanitize_key( wp_unslash( $_POST['frequency'] ?? 'weekly' ) ), array( 'daily', 'weekly' ), true ) ? sanitize_key( wp_unslash( $_POST['frequency'] ?? 'weekly' ) ) : 'weekly',
			'send_time'          => preg_match( '/^([01]?\d|2[0-3]):([0-5]\d)$/', (string) ( $_POST['send_time'] ?? '08:00' ) ) ? sanitize_text_field( wp_unslash( $_POST['send_time'] ) ) : '08:00',
			'enabled'            => isset( $_POST['enabled'] ) ? 1 : 0,
			'tone'               => sanitize_text_field( wp_unslash( $_POST['tone'] ?? 'conversational' ) ),
			'competitors'        => sanitize_textarea_field( wp_unslash( $_POST['competitors'] ?? '' ) ),
			'notes'              => sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) ),
		);
		if ( $id ) {
			CTM_DB::update_client( $id, $data );
		} else {
			$id = CTM_DB::insert_client( $data );
		}
		CTM_Cron::reschedule();
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE . '-clients', 'saved' => 1, 'client_id' => $id ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function handle_delete_client() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Insufficient permissions.' );
		check_admin_referer( 'ctm_delete_client' );
		$id = absint( $_POST['client_id'] ?? 0 );
		CTM_DB::delete_client( $id );
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE . '-clients', 'deleted' => 1 ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function handle_save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Insufficient permissions.' );
		check_admin_referer( 'ctm_save_settings' );
		CTM_DB::update_settings( array(
			'api_key'        => trim( (string) wp_unslash( $_POST['api_key']        ?? '' ) ),
			'resend_api_key' => trim( (string) wp_unslash( $_POST['resend_api_key'] ?? '' ) ),
			'model'          => sanitize_text_field( wp_unslash( $_POST['model'] ?? 'sonar-pro' ) ),
		) );
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE . '-settings', 'saved' => 1 ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function handle_send_test_email() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Insufficient permissions.' );
		check_admin_referer( 'ctm_send_test_email' );
		$s      = CTM_DB::get_settings();
		$to     = sanitize_email( wp_unslash( $_POST['test_recipient'] ?? '' ) );
		$result = CTM_Emailer::send_test( $to, $s['from_name'] ?? '', $s['from_email'] ?? '', $s['resend_api_key'] ?? '' );
		$base   = add_query_arg( array( 'page' => self::PAGE . '-settings' ), admin_url( 'admin.php' ) );
		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'test_error', rawurlencode( $result->get_error_message() ), $base ) );
		} else {
			wp_safe_redirect( add_query_arg( 'test_sent', 1, $base ) );
		}
		exit;
	}

	// ── AJAX ───────────────────────────────────────────────────────────────────

	public function ajax_update_performance() {
		check_ajax_referer( 'ctm_ajax', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions' );
		$data = array(
			'brief_id'            => absint( $_POST['brief_id']    ?? 0 ),
			'client_id'           => absint( $_POST['client_id']   ?? 0 ),
			'video_key'           => sanitize_key( $_POST['video_key'] ?? '' ),
			'posted_url'          => esc_url_raw( wp_unslash( $_POST['posted_url'] ?? '' ) ),
			'platform'            => sanitize_text_field( wp_unslash( $_POST['platform']  ?? '' ) ),
			'views'               => absint( $_POST['views']        ?? 0 ),
			'watch_time_minutes'  => absint( $_POST['watch_time']   ?? 0 ),
			'clicks'              => absint( $_POST['clicks']       ?? 0 ),
			'leads'               => absint( $_POST['leads']        ?? 0 ),
			'booked_jobs'         => absint( $_POST['booked_jobs']  ?? 0 ),
			'winner'              => isset( $_POST['winner'] ) ? 1 : 0,
			'notes'               => sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) ),
		);
		$id = CTM_DB::insert_performance( $data );
		wp_send_json_success( array( 'id' => $id ) );
	}

	public function ajax_update_brief_field() {
		check_ajax_referer( 'ctm_ajax', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions' );
		$brief_id = absint( $_POST['brief_id'] ?? 0 );
		$field    = sanitize_key( $_POST['field'] ?? '' );
		$value    = sanitize_textarea_field( wp_unslash( $_POST['value'] ?? '' ) );
		$row      = CTM_DB::get_brief( $brief_id );
		if ( ! $row ) wp_send_json_error( 'Not found' );
		$brief = json_decode( (string) $row->brief_json, true );
		if ( ! is_array( $brief ) ) wp_send_json_error( 'Bad data' );
		$brief[ $field ] = $value;
		CTM_DB::update_brief( $brief_id, array( 'brief' => $brief ) );
		wp_send_json_success();
	}

	public function ajax_regenerate_section() {
		check_ajax_referer( 'ctm_ajax', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permissions' );
		// Placeholder — full section regeneration would call CTM_Generator with a targeted prompt
		wp_send_json_error( 'Section regeneration coming in next release.' );
	}

	// ── Dashboard ─────────────────────────────────────────────────────────────

	public function render_dashboard() {
		if ( ! current_user_can( 'manage_options' ) ) return;
		$clients     = CTM_DB::get_clients();
		$recent      = CTM_DB::get_briefs( 5 );
		$sent_today  = CTM_DB::get_briefs( 100, 0, 'sent' );
		$email_log   = CTM_DB::get_recent_email_log( 5 );
		?>
		<div class="wrap ctm-wrap">
			<?php $this->render_page_header( __( 'Command Center', 'content-traffic-maker' ) ); ?>

			<?php $this->render_notices(); ?>

			<!-- Stat Cards -->
			<div class="ctm-stat-row">
				<div class="ctm-stat-card">
					<div class="ctm-stat-number"><?php echo count( $clients ); ?></div>
					<div class="ctm-stat-label"><?php esc_html_e( 'Active Clients', 'content-traffic-maker' ); ?></div>
				</div>
				<div class="ctm-stat-card">
					<div class="ctm-stat-number"><?php echo count( CTM_DB::get_briefs( 1000 ) ); ?></div>
					<div class="ctm-stat-label"><?php esc_html_e( 'Total Briefs', 'content-traffic-maker' ); ?></div>
				</div>
				<div class="ctm-stat-card">
					<div class="ctm-stat-number"><?php echo count( CTM_DB::get_briefs( 1000, 0, 'sent' ) ); ?></div>
					<div class="ctm-stat-label"><?php esc_html_e( 'Briefs Sent', 'content-traffic-maker' ); ?></div>
				</div>
				<div class="ctm-stat-card">
					<div class="ctm-stat-number"><?php echo count( CTM_DB::get_briefs( 1000, 0, 'draft' ) ); ?></div>
					<div class="ctm-stat-label"><?php esc_html_e( 'Awaiting Approval', 'content-traffic-maker' ); ?></div>
				</div>
			</div>

			<div class="ctm-grid-2col">
				<!-- Clients Quick Generate -->
				<div class="ctm-card">
					<h3><?php esc_html_e( 'Generate Brief', 'content-traffic-maker' ); ?></h3>
					<?php if ( empty( $clients ) ) : ?>
						<p><?php esc_html_e( 'No clients yet.', 'content-traffic-maker' ); ?> <a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE . '-clients&new=1' ) ); ?>"><?php esc_html_e( 'Add your first client', 'content-traffic-maker' ); ?></a>.</p>
					<?php else : ?>
						<?php foreach ( $clients as $c ) : ?>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="ctm-quick-generate">
							<?php wp_nonce_field( 'ctm_generate_now' ); ?>
							<input type="hidden" name="action"    value="ctm_generate_now">
							<input type="hidden" name="client_id" value="<?php echo esc_attr( (string) $c->id ); ?>">
							<div class="ctm-client-generate-row">
								<div>
									<strong><?php echo esc_html( $c->business_name ); ?></strong>
									<span class="ctm-badge ctm-badge--<?php echo $c->enabled ? 'sent' : 'draft'; ?>"><?php echo $c->enabled ? esc_html__( 'Auto', 'content-traffic-maker' ) : esc_html__( 'Manual', 'content-traffic-maker' ); ?></span>
								</div>
								<button type="submit" class="button button-primary"><?php esc_html_e( '⚡ Generate', 'content-traffic-maker' ); ?></button>
							</div>
						</form>
						<?php endforeach; ?>
					<?php endif; ?>
				</div>

				<!-- Recent Briefs -->
				<div class="ctm-card">
					<h3><?php esc_html_e( 'Recent Briefs', 'content-traffic-maker' ); ?></h3>
					<?php if ( empty( $recent ) ) : ?>
						<p class="description"><?php esc_html_e( 'No briefs generated yet.', 'content-traffic-maker' ); ?></p>
					<?php else : ?>
					<table class="widefat striped">
						<thead><tr><th><?php esc_html_e( 'Date', 'content-traffic-maker' ); ?></th><th><?php esc_html_e( 'Status', 'content-traffic-maker' ); ?></th><th></th></tr></thead>
						<tbody>
							<?php foreach ( $recent as $b ) : ?>
							<tr>
								<td><?php echo esc_html( gmdate( 'M j', strtotime( $b->created_at ) ) ); ?></td>
								<td><?php $this->render_status_badge( $b->status ); ?></td>
								<td><a href="<?php echo esc_url( add_query_arg( array( 'page' => self::PAGE . '-briefs', 'brief_id' => $b->id ), admin_url( 'admin.php' ) ) ); ?>"><?php esc_html_e( 'View', 'content-traffic-maker' ); ?></a></td>
							</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
					<?php endif; ?>
				</div>
			</div>

			<!-- Recent Email Activity -->
			<?php if ( ! empty( $email_log ) ) : ?>
			<div class="ctm-card" style="margin-top:16px;">
				<h3><?php esc_html_e( 'Recent Email Activity', 'content-traffic-maker' ); ?></h3>
				<table class="widefat striped">
					<thead><tr>
						<th><?php esc_html_e( 'Sent', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'To', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Provider', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Status', 'content-traffic-maker' ); ?></th>
					</tr></thead>
					<tbody>
						<?php foreach ( $email_log as $log ) : ?>
						<tr>
							<td><?php echo esc_html( gmdate( 'M j g:ia', strtotime( $log->sent_at ) ) ); ?></td>
							<td><?php echo esc_html( $log->recipient ); ?></td>
							<td><?php echo esc_html( $log->provider ); ?></td>
							<td><?php $this->render_status_badge( $log->status ); ?></td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<?php endif; ?>
		</div>
		<?php
	}

	// ── Clients ────────────────────────────────────────────────────────────────

	public function render_clients() {
		if ( ! current_user_can( 'manage_options' ) ) return;
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$editing   = isset( $_GET['client_id'] ) ? absint( $_GET['client_id'] ) : 0;
		$new       = isset( $_GET['new'] );
		// phpcs:enable
		$client    = $editing ? CTM_DB::get_client( $editing ) : null;
		$clients   = CTM_DB::get_clients();

		?>
		<div class="wrap ctm-wrap">
			<?php $this->render_page_header( __( 'Clients', 'content-traffic-maker' ) ); ?>
			<?php $this->render_notices(); ?>

			<?php if ( $editing || $new ) : ?>
				<?php $this->render_client_form( $client ); ?>
				<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE . '-clients' ) ); ?>">&larr; <?php esc_html_e( 'Back to Clients', 'content-traffic-maker' ); ?></a></p>
			<?php else : ?>
				<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE . '-clients&new=1' ) ); ?>" class="button button-primary"><?php esc_html_e( '+ New Client', 'content-traffic-maker' ); ?></a></p>
				<?php if ( empty( $clients ) ) : ?>
					<div class="ctm-card"><p><?php esc_html_e( 'No clients yet. Add your first one.', 'content-traffic-maker' ); ?></p></div>
				<?php else : ?>
				<table class="widefat striped" style="margin-top:16px;">
					<thead><tr>
						<th><?php esc_html_e( 'Client Name', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Business', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Location', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Recipient', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Schedule', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Auto', 'content-traffic-maker' ); ?></th>
						<th></th>
					</tr></thead>
					<tbody>
						<?php foreach ( $clients as $c ) : ?>
						<tr>
							<td><strong><?php echo esc_html( $c->name ); ?></strong></td>
							<td><?php echo esc_html( $c->business_name ); ?></td>
							<td><?php echo esc_html( $c->target_city . ', ' . $c->target_state ); ?></td>
							<td><?php echo esc_html( $c->recipient ); ?></td>
							<td><?php echo esc_html( ucfirst( $c->frequency ) . ' @ ' . $c->send_time ); ?></td>
							<td><?php echo $c->enabled ? '<span style="color:#16a34a;">&#10003;</span>' : '<span style="color:#94a3b8;">&#8212;</span>'; ?></td>
							<td>
								<a href="<?php echo esc_url( add_query_arg( array( 'page' => self::PAGE . '-clients', 'client_id' => $c->id ), admin_url( 'admin.php' ) ) ); ?>"><?php esc_html_e( 'Edit', 'content-traffic-maker' ); ?></a>
								&nbsp;|&nbsp;
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;" onsubmit="return confirm('Delete this client?');">
									<?php wp_nonce_field( 'ctm_delete_client' ); ?>
									<input type="hidden" name="action"    value="ctm_delete_client">
									<input type="hidden" name="client_id" value="<?php echo esc_attr( (string) $c->id ); ?>">
									<button type="submit" class="button-link" style="color:#dc2626;"><?php esc_html_e( 'Delete', 'content-traffic-maker' ); ?></button>
								</form>
							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<?php endif; ?>
			<?php endif; ?>
		</div>
		<?php
	}

	private function render_client_form( $client = null ) {
		$v = function( $k, $default = '' ) use ( $client ) {
			if ( $client ) return esc_attr( (string) ( $client->$k ?? $default ) );
			return esc_attr( $default );
		};
		$t = function( $k, $default = '' ) use ( $client ) {
			if ( $client ) return esc_textarea( (string) ( $client->$k ?? $default ) );
			return esc_textarea( $default );
		};
		?>
		<div class="ctm-card">
			<h3><?php echo $client ? esc_html__( 'Edit Client', 'content-traffic-maker' ) : esc_html__( 'New Client', 'content-traffic-maker' ); ?></h3>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'ctm_save_client' ); ?>
				<input type="hidden" name="action"    value="ctm_save_client">
				<input type="hidden" name="client_id" value="<?php echo $client ? esc_attr( (string) $client->id ) : '0'; ?>">
				<table class="form-table" role="presentation">
					<tr><th><label><?php esc_html_e( 'Client Name', 'content-traffic-maker' ); ?></label></th>
						<td><input type="text" name="name" class="regular-text" value="<?php echo $v( 'name' ); ?>" required>
							<p class="description"><?php esc_html_e( 'Internal reference label.', 'content-traffic-maker' ); ?></p></td></tr>
					<tr><th><label><?php esc_html_e( 'Business Name', 'content-traffic-maker' ); ?></label></th>
						<td><input type="text" name="business_name" class="regular-text" value="<?php echo $v( 'business_name' ); ?>"></td></tr>
					<tr><th><label><?php esc_html_e( 'City', 'content-traffic-maker' ); ?></label></th>
						<td><input type="text" name="target_city" class="regular-text" value="<?php echo $v( 'target_city' ); ?>"></td></tr>
					<tr><th><label><?php esc_html_e( 'State', 'content-traffic-maker' ); ?></label></th>
						<td><input type="text" name="target_state" style="max-width:80px;" value="<?php echo $v( 'target_state' ); ?>"></td></tr>
					<tr><th colspan="2"><hr><strong><?php esc_html_e( 'Segment A', 'content-traffic-maker' ); ?></strong></th></tr>
					<tr><th><label><?php esc_html_e( 'Label', 'content-traffic-maker' ); ?></label></th>
						<td><input type="text" name="segment_a_label" class="regular-text" value="<?php echo $v( 'segment_a_label', 'Commercial' ); ?>" placeholder="Commercial"></td></tr>
					<tr><th><label><?php esc_html_e( 'Sub-label', 'content-traffic-maker' ); ?></label></th>
						<td><input type="text" name="segment_a_sub" class="regular-text" value="<?php echo $v( 'segment_a_sub' ); ?>"></td></tr>
					<tr><th><label><?php esc_html_e( 'Audience', 'content-traffic-maker' ); ?></label></th>
						<td><textarea name="segment_a_audience" class="regular-text" rows="2"><?php echo $t( 'segment_a_audience' ); ?></textarea></td></tr>
					<tr><th><label><?php esc_html_e( 'Services', 'content-traffic-maker' ); ?></label></th>
						<td><textarea name="segment_a_services" class="regular-text" rows="2"><?php echo $t( 'segment_a_services' ); ?></textarea></td></tr>
					<tr><th colspan="2"><hr><strong><?php esc_html_e( 'Segment B', 'content-traffic-maker' ); ?></strong></th></tr>
					<tr><th><label><?php esc_html_e( 'Label', 'content-traffic-maker' ); ?></label></th>
						<td><input type="text" name="segment_b_label" class="regular-text" value="<?php echo $v( 'segment_b_label', 'Residential' ); ?>" placeholder="Residential"></td></tr>
					<tr><th><label><?php esc_html_e( 'Sub-label', 'content-traffic-maker' ); ?></label></th>
						<td><input type="text" name="segment_b_sub" class="regular-text" value="<?php echo $v( 'segment_b_sub' ); ?>"></td></tr>
					<tr><th><label><?php esc_html_e( 'Audience', 'content-traffic-maker' ); ?></label></th>
						<td><textarea name="segment_b_audience" class="regular-text" rows="2"><?php echo $t( 'segment_b_audience' ); ?></textarea></td></tr>
					<tr><th><label><?php esc_html_e( 'Services', 'content-traffic-maker' ); ?></label></th>
						<td><textarea name="segment_b_services" class="regular-text" rows="2"><?php echo $t( 'segment_b_services' ); ?></textarea></td></tr>
					<tr><th colspan="2"><hr><strong><?php esc_html_e( 'Delivery', 'content-traffic-maker' ); ?></strong></th></tr>
					<tr><th><label><?php esc_html_e( 'Recipient', 'content-traffic-maker' ); ?></label></th>
						<td><input type="email" name="recipient" class="regular-text" value="<?php echo $v( 'recipient' ); ?>"></td></tr>
					<tr><th><label><?php esc_html_e( 'From Name', 'content-traffic-maker' ); ?></label></th>
						<td><input type="text" name="from_name" class="regular-text" value="<?php echo $v( 'from_name' ); ?>"></td></tr>
					<tr><th><label><?php esc_html_e( 'From Email', 'content-traffic-maker' ); ?></label></th>
						<td><input type="email" name="from_email" class="regular-text" value="<?php echo $v( 'from_email' ); ?>">
							<p class="description"><?php esc_html_e( 'Must match a verified domain in your Resend account.', 'content-traffic-maker' ); ?></p></td></tr>
					<tr><th><label><?php esc_html_e( 'Frequency', 'content-traffic-maker' ); ?></label></th>
						<td><select name="frequency">
							<option value="daily"  <?php selected( $client ? $client->frequency : '', 'daily' ); ?>><?php esc_html_e( 'Daily', 'content-traffic-maker' ); ?></option>
							<option value="weekly" <?php selected( $client ? $client->frequency : 'weekly', 'weekly' ); ?>><?php esc_html_e( 'Weekly', 'content-traffic-maker' ); ?></option>
						</select></td></tr>
					<tr><th><label><?php esc_html_e( 'Send Time', 'content-traffic-maker' ); ?></label></th>
						<td><input type="time" name="send_time" value="<?php echo $v( 'send_time', '08:00' ); ?>"></td></tr>
					<tr><th colspan="2"><hr><strong><?php esc_html_e( 'Content Settings', 'content-traffic-maker' ); ?></strong></th></tr>
					<tr><th><label><?php esc_html_e( 'Tone', 'content-traffic-maker' ); ?></label></th>
						<td><select name="tone">
							<?php foreach ( array( 'conversational', 'bold', 'professional', 'friendly', 'urgent' ) as $tone ) : ?>
							<option value="<?php echo esc_attr( $tone ); ?>" <?php selected( $client ? $client->tone : 'conversational', $tone ); ?>><?php echo esc_html( ucfirst( $tone ) ); ?></option>
							<?php endforeach; ?>
						</select></td></tr>
					<tr><th><label><?php esc_html_e( 'Competitors', 'content-traffic-maker' ); ?></label></th>
						<td><textarea name="competitors" class="regular-text" rows="2"><?php echo $t( 'competitors' ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Comma-separated competitor names to differentiate from in content.', 'content-traffic-maker' ); ?></p></td></tr>
					<tr><th><label><?php esc_html_e( 'Notes', 'content-traffic-maker' ); ?></label></th>
						<td><textarea name="notes" class="regular-text" rows="2"><?php echo $t( 'notes' ); ?></textarea></td></tr>
					<tr><th><?php esc_html_e( 'Auto-send', 'content-traffic-maker' ); ?></th>
						<td><label><input type="checkbox" name="enabled" value="1" <?php checked( $client ? (int) $client->enabled : 0, 1 ); ?>>
							<?php esc_html_e( 'Auto-generate and email on schedule', 'content-traffic-maker' ); ?></label></td></tr>
				</table>
				<p class="submit"><button type="submit" class="button button-primary"><?php esc_html_e( 'Save Client', 'content-traffic-maker' ); ?></button></p>
			</form>
		</div>
		<?php
	}

	// ── Brief Builder ─────────────────────────────────────────────────────────

	public function render_briefs() {
		if ( ! current_user_can( 'manage_options' ) ) return;
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$brief_id  = isset( $_GET['brief_id'] ) ? absint( $_GET['brief_id'] ) : 0;
		$generated = isset( $_GET['generated'] );
		$approved  = isset( $_GET['approved'] );
		$rejected  = isset( $_GET['rejected'] );
		$sent      = isset( $_GET['sent'] );
		$gen_error = isset( $_GET['gen_error'] ) ? sanitize_text_field( wp_unslash( $_GET['gen_error'] ) ) : '';
		$send_err  = isset( $_GET['send_error'] ) ? sanitize_text_field( wp_unslash( $_GET['send_error'] ) ) : '';
		// phpcs:enable
		?>
		<div class="wrap ctm-wrap">
			<?php $this->render_page_header( __( 'Brief Builder', 'content-traffic-maker' ) ); ?>

			<?php if ( $generated ) : ?><div class="notice notice-info is-dismissible"><p>📄 <?php esc_html_e( 'Brief generated. Review, edit, then approve and send.', 'content-traffic-maker' ); ?></p></div><?php endif; ?>
			<?php if ( $approved )  : ?><div class="notice notice-success is-dismissible"><p>✅ <?php esc_html_e( 'Brief approved.', 'content-traffic-maker' ); ?></p></div><?php endif; ?>
			<?php if ( $rejected )  : ?><div class="notice notice-warning is-dismissible"><p><?php esc_html_e( 'Brief rejected.', 'content-traffic-maker' ); ?></p></div><?php endif; ?>
			<?php if ( $sent )      : ?><div class="notice notice-success is-dismissible"><p>📧 <?php esc_html_e( 'Brief sent successfully.', 'content-traffic-maker' ); ?></p></div><?php endif; ?>
			<?php if ( $gen_error ) : ?><div class="notice notice-error is-dismissible"><p><?php echo esc_html( $gen_error ); ?></p></div><?php endif; ?>
			<?php if ( $send_err )  : ?><div class="notice notice-error is-dismissible"><p><?php echo esc_html( $send_err ); ?></p></div><?php endif; ?>

			<?php if ( $brief_id ) : ?>
				<?php $this->render_brief_builder( $brief_id ); ?>
			<?php else : ?>
				<?php $this->render_briefs_list(); ?>
			<?php endif; ?>
		</div>
		<?php
	}

	private function render_briefs_list() {
		$briefs  = CTM_DB::get_briefs( 30 );
		$clients = CTM_DB::get_clients();
		$client_map = array();
		foreach ( $clients as $c ) {
			$client_map[ $c->id ] = $c->business_name;
		}
		?>
		<div class="ctm-card">
			<h3><?php esc_html_e( 'All Briefs', 'content-traffic-maker' ); ?></h3>
			<?php if ( empty( $briefs ) ) : ?>
				<p><?php esc_html_e( 'No briefs yet. Generate one from the Dashboard.', 'content-traffic-maker' ); ?></p>
			<?php else : ?>
			<table class="widefat striped">
				<thead><tr>
					<th><?php esc_html_e( 'Date', 'content-traffic-maker' ); ?></th>
					<th><?php esc_html_e( 'Client', 'content-traffic-maker' ); ?></th>
					<th><?php esc_html_e( 'Status', 'content-traffic-maker' ); ?></th>
					<th><?php esc_html_e( 'Sent To', 'content-traffic-maker' ); ?></th>
					<th></th>
				</tr></thead>
				<tbody>
					<?php foreach ( $briefs as $b ) : ?>
					<tr>
						<td><?php echo esc_html( gmdate( 'M j, Y', strtotime( $b->created_at ) ) ); ?></td>
						<td><?php echo esc_html( $client_map[ $b->client_id ] ?? 'Unknown' ); ?></td>
						<td><?php $this->render_status_badge( $b->status ); ?></td>
						<td><?php echo esc_html( $b->sent_to ?: '—' ); ?></td>
						<td><a href="<?php echo esc_url( add_query_arg( array( 'page' => self::PAGE . '-briefs', 'brief_id' => $b->id ), admin_url( 'admin.php' ) ) ); ?>" class="button button-small"><?php esc_html_e( 'Open', 'content-traffic-maker' ); ?></a></td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php endif; ?>
		</div>
		<?php
	}

	private function render_brief_builder( $brief_id ) {
		$row = CTM_DB::get_brief( $brief_id );
		if ( ! $row ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'Brief not found.', 'content-traffic-maker' ) . '</p></div>';
			return;
		}
		$brief   = json_decode( (string) $row->brief_json, true );
		if ( ! is_array( $brief ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'Brief data is corrupt.', 'content-traffic-maker' ) . '</p></div>';
			return;
		}
		$client  = CTM_DB::get_client( $row->client_id );
		$s_label_a = $client ? $client->segment_a_label : 'Commercial';
		$s_label_b = $client ? $client->segment_b_label : 'Residential';
		$s_sub_a   = $client ? $client->segment_a_sub   : '';
		$s_sub_b   = $client ? $client->segment_b_sub   : '';
		$status    = $row->status;
		?>
		<div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;flex-wrap:wrap;">
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE . '-briefs' ) ); ?>">&larr; <?php esc_html_e( 'All Briefs', 'content-traffic-maker' ); ?></a>
			<span><?php esc_html_e( 'Brief', 'content-traffic-maker' ); ?> #<?php echo esc_html( (string) $brief_id ); ?></span>
			<?php $this->render_status_badge( $status ); ?>
			<div style="margin-left:auto;display:flex;gap:8px;flex-wrap:wrap;">
				<?php if ( 'draft' === $status || 'generated' === $status ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:0;">
					<?php wp_nonce_field( 'ctm_approve_brief' ); ?>
					<input type="hidden" name="action"   value="ctm_approve_brief">
					<input type="hidden" name="brief_id" value="<?php echo esc_attr( (string) $brief_id ); ?>">
					<button type="submit" class="button button-primary">✅ <?php esc_html_e( 'Approve', 'content-traffic-maker' ); ?></button>
				</form>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:0;">
					<?php wp_nonce_field( 'ctm_reject_brief' ); ?>
					<input type="hidden" name="action"   value="ctm_reject_brief">
					<input type="hidden" name="brief_id" value="<?php echo esc_attr( (string) $brief_id ); ?>">
					<button type="submit" class="button" style="border-color:#dc2626;color:#dc2626;">✗ <?php esc_html_e( 'Reject', 'content-traffic-maker' ); ?></button>
				</form>
				<?php endif; ?>
				<?php if ( in_array( $status, array( 'approved', 'draft', 'generated' ), true ) ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:0;">
					<?php wp_nonce_field( 'ctm_send_brief' ); ?>
					<input type="hidden" name="action"   value="ctm_send_brief">
					<input type="hidden" name="brief_id" value="<?php echo esc_attr( (string) $brief_id ); ?>">
					<button type="submit" class="button button-primary">📧 <?php esc_html_e( 'Send', 'content-traffic-maker' ); ?></button>
				</form>
				<?php endif; ?>
			</div>
		</div>

		<?php
		$videos = array(
			array( 'key' => 'com_seo',   'label' => 'SEO Video',   'section' => $s_label_a, 'sub' => $s_sub_a, 'accent' => '#1d4ed8', 'bg' => '#1e3a5f' ),
			array( 'key' => 'com_offer', 'label' => 'Offer Video', 'section' => $s_label_a, 'sub' => $s_sub_a, 'accent' => '#1d4ed8', 'bg' => '#1e3a5f' ),
			array( 'key' => 'com_viral', 'label' => 'Viral Video', 'section' => $s_label_a, 'sub' => $s_sub_a, 'accent' => '#1d4ed8', 'bg' => '#1e3a5f' ),
			array( 'key' => 'res_seo',   'label' => 'SEO Video',   'section' => $s_label_b, 'sub' => $s_sub_b, 'accent' => '#7c3aed', 'bg' => '#2e1065' ),
			array( 'key' => 'res_offer', 'label' => 'Offer Video', 'section' => $s_label_b, 'sub' => $s_sub_b, 'accent' => '#7c3aed', 'bg' => '#2e1065' ),
			array( 'key' => 'res_viral', 'label' => 'Viral Video', 'section' => $s_label_b, 'sub' => $s_sub_b, 'accent' => '#7c3aed', 'bg' => '#2e1065' ),
		);
		$prev_section = '';
		?>

		<?php foreach ( $videos as $num => $v ) :
			$k   = $v['key'];
			$pri = (int) ( $brief["{$k}_priority"]   ?? 0 );
			$conf = (int) ( $brief["{$k}_confidence"] ?? 0 );
			$pri_color = $pri >= 8 ? '#16a34a' : ( $pri >= 5 ? '#d97706' : '#94a3b8' );

			if ( $v['section'] !== $prev_section ) :
				$prev_section = $v['section'];
				?>
				<div style="background:<?php echo esc_attr( $v['bg'] ); ?>;padding:10px 20px;margin-bottom:0;border-radius:6px 6px 0 0;margin-top:20px;">
					<span style="color:#fff;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.07em;"><?php echo esc_html( $v['section'] ); ?></span>
					<?php if ( $v['sub'] ) : ?><span style="color:rgba(255,255,255,.5);font-size:11px;margin-left:8px;"><?php echo esc_html( $v['sub'] ); ?></span><?php endif; ?>
				</div>
			<?php endif; ?>

			<div class="ctm-card ctm-video-card" style="margin-top:0;border-radius:<?php echo ( $v['section'] !== $prev_section && $num < 2 ) ? '0' : '0'; ?> 0 6px 6px;border-top:3px solid <?php echo esc_attr( $v['accent'] ); ?>;">
				<div class="ctm-video-header">
					<span class="ctm-video-num" style="background:<?php echo esc_attr( $v['accent'] ); ?>;"><?php echo str_pad( (string)($num+1), 2, '0', STR_PAD_LEFT ); ?></span>
					<span class="ctm-video-type"><?php echo esc_html( $v['label'] ); ?></span>
					<span class="ctm-badge-priority" style="background:<?php echo esc_attr( $pri_color ); ?>;"><?php echo esc_html( (string) $pri ); ?>/10</span>
					<?php if ( $conf ) : ?><span class="ctm-conf-badge">Confidence <?php echo esc_html( (string) $conf ); ?>/10</span><?php endif; ?>
				</div>

				<?php
				// Define editable fields per video type
				$fields = array();
				if ( 'seo' === substr( $k, -3 ) ) {
					$fields = array(
						'video_title' => array( 'label' => 'Title', 'style' => 'title' ),
						'keyword'     => array( 'label' => 'Keyword', 'style' => 'kw' ),
						'search_intent' => array( 'label' => 'Search Intent' ),
						'hook'        => array( 'label' => 'Hook', 'style' => 'hook' ),
						'cta'         => array( 'label' => 'CTA', 'style' => 'cta' ),
						'difficulty'  => array( 'label' => 'Difficulty' ),
					);
				} elseif ( 'offer' === substr( $k, -5 ) ) {
					$fields = array(
						'video_title' => array( 'label' => 'Title', 'style' => 'title' ),
						'name'        => array( 'label' => 'Offer' ),
						'audience'    => array( 'label' => 'Audience' ),
						'hook'        => array( 'label' => 'Hook', 'style' => 'hook' ),
						'cta'         => array( 'label' => 'CTA', 'style' => 'cta' ),
					);
				} else {
					$fields = array(
						'video_title'      => array( 'label' => 'Title', 'style' => 'title' ),
						'trending_format'  => array( 'label' => 'Trend Format', 'style' => 'kw' ),
						'concept'          => array( 'label' => 'Concept' ),
						'opening_shot'     => array( 'label' => 'Opening Shot' ),
						'trend_reason'     => array( 'label' => 'Why It Works' ),
						'trend_evidence'   => array( 'label' => 'Trend Evidence' ),
						'cta'              => array( 'label' => 'CTA', 'style' => 'cta' ),
					);
				}
				?>

				<div class="ctm-fields">
					<?php foreach ( $fields as $suffix => $fd ) :
						$field_key = "{$k}_{$suffix}";
						$val       = (string) ( $brief[ $field_key ] ?? '' );
						if ( '' === $val ) continue;
						$style = $fd['style'] ?? '';
					?>
					<div class="ctm-field-row">
						<span class="ctm-field-label"><?php echo esc_html( $fd['label'] ); ?></span>
						<span class="ctm-field-value ctm-editable <?php echo esc_attr( $style ? "ctm-field-{$style}" : '' ); ?>"
							data-brief-id="<?php echo esc_attr( (string) $brief_id ); ?>"
							data-field="<?php echo esc_attr( $field_key ); ?>"
							contenteditable="true"><?php
								if ( 'hook' === $style ) echo '&ldquo;' . esc_html( $val ) . '&rdquo;';
								else echo esc_html( $val );
							?></span>
					</div>
					<?php endforeach; ?>
				</div>

				<!-- Proof source -->
				<?php
				$ex_title = (string) ( $brief["{$k}_example_title"] ?? '' );
				$ex_url   = esc_url( (string) ( $brief["{$k}_example_url"] ?? '' ) );
				$ex_plat  = (string) ( $brief["{$k}_example_platform"] ?? '' );
				$ex_date  = (string) ( $brief["{$k}_example_date"]     ?? '' );
				if ( $ex_title ) :
				?>
				<div class="ctm-proof-source">
					<span class="ctm-proof-icon">🔗</span>
					<div>
						<span class="ctm-field-label"><?php esc_html_e( 'Proof Source', 'content-traffic-maker' ); ?></span>
						<?php if ( $ex_url ) : ?>
							<a href="<?php echo $ex_url; ?>" target="_blank" rel="noopener" class="ctm-example-link"><?php echo esc_html( $ex_title ); ?></a>
						<?php else : ?>
							<span class="ctm-example-unverified"><?php echo esc_html( $ex_title ); ?> <?php esc_html_e( '(URL unverified)', 'content-traffic-maker' ); ?></span>
						<?php endif; ?>
						<?php if ( $ex_plat || $ex_date ) : ?>
							<span class="ctm-proof-meta"><?php echo esc_html( trim( $ex_plat . ' ' . $ex_date ) ); ?></span>
						<?php endif; ?>
					</div>
				</div>
				<?php endif; ?>

				<!-- Performance log trigger -->
				<div class="ctm-perf-trigger">
					<button class="button button-small ctm-log-perf-btn" data-brief-id="<?php echo esc_attr( (string) $brief_id ); ?>" data-client-id="<?php echo esc_attr( (string) $row->client_id ); ?>" data-video-key="<?php echo esc_attr( $k ); ?>">
						📊 <?php esc_html_e( 'Log Performance', 'content-traffic-maker' ); ?>
					</button>
				</div>

				<!-- Performance form (hidden) -->
				<div class="ctm-perf-form" id="perf-<?php echo esc_attr( $k ); ?>" style="display:none;">
					<div class="ctm-perf-grid">
						<label><?php esc_html_e( 'Posted URL', 'content-traffic-maker' ); ?><input type="url" class="ctm-pf posted_url" placeholder="https://..."></label>
						<label><?php esc_html_e( 'Platform', 'content-traffic-maker' ); ?><select class="ctm-pf platform"><option>TikTok</option><option>YouTube</option><option>Instagram</option><option>Facebook</option></select></label>
						<label><?php esc_html_e( 'Views', 'content-traffic-maker' ); ?><input type="number" class="ctm-pf views" value="0"></label>
						<label><?php esc_html_e( 'Watch Time (min)', 'content-traffic-maker' ); ?><input type="number" class="ctm-pf watch_time" value="0"></label>
						<label><?php esc_html_e( 'Clicks', 'content-traffic-maker' ); ?><input type="number" class="ctm-pf clicks" value="0"></label>
						<label><?php esc_html_e( 'Leads', 'content-traffic-maker' ); ?><input type="number" class="ctm-pf leads" value="0"></label>
						<label><?php esc_html_e( 'Booked Jobs', 'content-traffic-maker' ); ?><input type="number" class="ctm-pf booked_jobs" value="0"></label>
						<label style="display:flex;align-items:center;gap:6px;"><input type="checkbox" class="ctm-pf winner"> <?php esc_html_e( 'Winner Format', 'content-traffic-maker' ); ?></label>
					</div>
					<label style="display:block;margin-top:8px;"><?php esc_html_e( 'Notes', 'content-traffic-maker' ); ?><textarea class="ctm-pf notes" rows="2" style="width:100%;"></textarea></label>
					<button class="button button-primary ctm-save-perf" data-brief-id="<?php echo esc_attr( (string) $brief_id ); ?>" data-client-id="<?php echo esc_attr( (string) $row->client_id ); ?>" data-video-key="<?php echo esc_attr( $k ); ?>"><?php esc_html_e( 'Save', 'content-traffic-maker' ); ?></button>
					<button class="button ctm-cancel-perf"><?php esc_html_e( 'Cancel', 'content-traffic-maker' ); ?></button>
				</div>
			</div>
		<?php endforeach; ?>
		<?php
	}

	// ── Performance ────────────────────────────────────────────────────────────

	public function render_performance() {
		if ( ! current_user_can( 'manage_options' ) ) return;
		$top     = CTM_DB::get_top_performers( 0, 20 );
		$clients = CTM_DB::get_clients();
		$client_map = array();
		foreach ( $clients as $c ) $client_map[ $c->id ] = $c->business_name;
		?>
		<div class="wrap ctm-wrap">
			<?php $this->render_page_header( __( 'Performance Tracker', 'content-traffic-maker' ) ); ?>
			<div class="ctm-card">
				<h3><?php esc_html_e( 'Top Performing Videos', 'content-traffic-maker' ); ?></h3>
				<?php if ( empty( $top ) ) : ?>
					<p><?php esc_html_e( 'No performance data yet. Log results from the Brief Builder after posting videos.', 'content-traffic-maker' ); ?></p>
				<?php else : ?>
				<table class="widefat striped">
					<thead><tr>
						<th><?php esc_html_e( 'Client', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Video Type', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Platform', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Views', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Clicks', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Leads', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Jobs', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Winner', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Link', 'content-traffic-maker' ); ?></th>
					</tr></thead>
					<tbody>
						<?php foreach ( $top as $p ) : ?>
						<tr<?php echo $p->winner ? ' style="background:#f0fdf4;"' : ''; ?>>
							<td><?php echo esc_html( $client_map[ $p->client_id ] ?? '—' ); ?></td>
							<td><?php echo esc_html( str_replace( '_', ' ', strtoupper( $p->video_key ) ) ); ?></td>
							<td><?php echo esc_html( $p->platform ); ?></td>
							<td><?php echo number_format( $p->views ); ?></td>
							<td><?php echo number_format( $p->clicks ); ?></td>
							<td><?php echo number_format( $p->leads ); ?></td>
							<td><?php echo number_format( $p->booked_jobs ); ?></td>
							<td><?php echo $p->winner ? '🏆' : ''; ?></td>
							<td><?php if ( $p->posted_url ) : ?><a href="<?php echo esc_url( $p->posted_url ); ?>" target="_blank">↗</a><?php endif; ?></td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	// ── Email Log ─────────────────────────────────────────────────────────────

	public function render_email_log() {
		if ( ! current_user_can( 'manage_options' ) ) return;
		$log = CTM_DB::get_recent_email_log( 50 );
		?>
		<div class="wrap ctm-wrap">
			<?php $this->render_page_header( __( 'Email Delivery Log', 'content-traffic-maker' ) ); ?>
			<div class="ctm-card">
				<?php if ( empty( $log ) ) : ?>
					<p><?php esc_html_e( 'No email activity yet.', 'content-traffic-maker' ); ?></p>
				<?php else : ?>
				<table class="widefat striped">
					<thead><tr>
						<th><?php esc_html_e( 'Sent', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Brief', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'To', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Provider', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Status', 'content-traffic-maker' ); ?></th>
						<th><?php esc_html_e( 'Detail', 'content-traffic-maker' ); ?></th>
					</tr></thead>
					<tbody>
						<?php foreach ( $log as $entry ) : ?>
						<tr>
							<td><?php echo esc_html( gmdate( 'M j, Y g:ia', strtotime( $entry->sent_at ) ) ); ?></td>
							<td><?php if ( $entry->brief_id ) : ?><a href="<?php echo esc_url( add_query_arg( array( 'page' => self::PAGE . '-briefs', 'brief_id' => $entry->brief_id ), admin_url( 'admin.php' ) ) ); ?>">#<?php echo esc_html( (string) $entry->brief_id ); ?></a><?php endif; ?></td>
							<td><?php echo esc_html( $entry->recipient ); ?></td>
							<td><?php echo esc_html( $entry->provider ); ?></td>
							<td><?php $this->render_status_badge( $entry->status ); ?></td>
							<td><?php if ( $entry->response_body ) echo '<span title="' . esc_attr( $entry->response_body ) . '" style="cursor:help;color:#64748b;">ⓘ</span>'; ?></td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	// ── Settings ───────────────────────────────────────────────────────────────

	public function render_settings() {
		if ( ! current_user_can( 'manage_options' ) ) return;
		$s        = CTM_DB::get_settings();
		$key_set  = '' !== (string) ( $s['api_key'] ?? '' );
		$res_set  = '' !== (string) ( $s['resend_api_key'] ?? '' );
		$aes_ok   = CTM_Crypto::is_openssl_available();
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$saved      = isset( $_GET['saved'] );
		$test_sent  = isset( $_GET['test_sent'] );
		$test_error = isset( $_GET['test_error'] ) ? sanitize_text_field( wp_unslash( $_GET['test_error'] ) ) : '';
		// phpcs:enable
		?>
		<div class="wrap ctm-wrap">
			<?php $this->render_page_header( __( 'Global Settings', 'content-traffic-maker' ) ); ?>
			<?php if ( $saved )     : ?><div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Settings saved.', 'content-traffic-maker' ); ?></p></div><?php endif; ?>
			<?php if ( $test_sent ) : ?><div class="notice notice-success is-dismissible"><p>✅ <?php esc_html_e( 'Test email sent successfully.', 'content-traffic-maker' ); ?></p></div><?php endif; ?>
			<?php if ( $test_error ): ?><div class="notice notice-error is-dismissible"><p><?php echo esc_html( $test_error ); ?></p></div><?php endif; ?>
			<?php if ( ! $aes_ok )  : ?><div class="notice notice-warning"><p><?php esc_html_e( 'OpenSSL not available — API keys are stored with base64 obfuscation. Enable the OpenSSL PHP extension for AES-256 encryption.', 'content-traffic-maker' ); ?></p></div><?php endif; ?>
			<?php if ( $res_set && ! isset( $s['from_email'] ) ) : ?><div class="notice notice-warning"><p><?php esc_html_e( 'Resend API key is set but no From Email is configured per client. Set a From Email in each Client profile.', 'content-traffic-maker' ); ?></p></div><?php endif; ?>

			<div class="ctm-card" style="max-width:680px;">
				<h3><?php esc_html_e( 'API Keys', 'content-traffic-maker' ); ?></h3>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'ctm_save_settings' ); ?>
					<input type="hidden" name="action" value="ctm_save_settings">
					<table class="form-table" role="presentation">
						<tr><th><label><?php esc_html_e( 'Perplexity API Key', 'content-traffic-maker' ); ?></label></th>
							<td><input type="password" name="api_key" class="regular-text" value="" autocomplete="off"
								placeholder="<?php echo esc_attr( $key_set ? '•••••••• saved — leave blank to keep' : 'pplx-...' ); ?>">
								<p class="description"><?php esc_html_e( 'perplexity.ai → Settings → API Keys', 'content-traffic-maker' ); ?></p></td></tr>
						<tr><th><label><?php esc_html_e( 'Resend API Key', 'content-traffic-maker' ); ?></label></th>
							<td><input type="password" name="resend_api_key" class="regular-text" value="" autocomplete="off"
								placeholder="<?php echo esc_attr( $res_set ? '•••••••• saved — leave blank to keep' : 're_...' ); ?>">
								<p class="description"><?php esc_html_e( 'resend.com → API Keys. Falls back to wp_mail if empty.', 'content-traffic-maker' ); ?></p></td></tr>
						<tr><th><label><?php esc_html_e( 'Perplexity Model', 'content-traffic-maker' ); ?></label></th>
							<td><input type="text" name="model" class="regular-text" value="<?php echo esc_attr( $s['model'] ?? 'sonar-pro' ); ?>" placeholder="sonar-pro">
								<p class="description"><?php esc_html_e( 'sonar-pro (default, recommended) or sonar.', 'content-traffic-maker' ); ?></p></td></tr>
					</table>
					<p class="submit"><button type="submit" class="button button-primary"><?php esc_html_e( 'Save Settings', 'content-traffic-maker' ); ?></button></p>
				</form>
			</div>

			<div class="ctm-card" style="max-width:680px;margin-top:16px;">
				<h3><?php esc_html_e( 'Test Email Delivery', 'content-traffic-maker' ); ?></h3>
				<p class="description"><?php esc_html_e( 'Send a test email to verify your Resend API key and sender configuration are working correctly.', 'content-traffic-maker' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'ctm_send_test_email' ); ?>
					<input type="hidden" name="action" value="ctm_send_test_email">
					<table class="form-table" role="presentation">
						<tr><th><label><?php esc_html_e( 'Send Test To', 'content-traffic-maker' ); ?></label></th>
							<td><input type="email" name="test_recipient" class="regular-text" placeholder="you@example.com" required></td></tr>
					</table>
					<p class="submit">
						<?php if ( ! $res_set ) : ?>
							<span class="description" style="color:#d97706;"><?php esc_html_e( '⚠ Set a Resend API key above first.', 'content-traffic-maker' ); ?></span>
						<?php endif; ?>
						<button type="submit" class="button button-secondary" <?php echo ! $res_set ? 'disabled' : ''; ?>><?php esc_html_e( '📧 Send Test', 'content-traffic-maker' ); ?></button>
					</p>
				</form>
			</div>
		</div>
		<?php
	}

	// ── Helpers ────────────────────────────────────────────────────────────────

	private function render_page_header( $title ) {
		?>
		<div class="ctm-page-header">
			<div class="ctm-logo">🎬 <?php esc_html_e( 'Content Traffic Maker', 'content-traffic-maker' ); ?></div>
			<h1><?php echo esc_html( $title ); ?></h1>
		</div>
		<?php
	}

	private function render_notices() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['saved'] ) )   echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Saved.', 'content-traffic-maker' ) . '</p></div>';
		if ( isset( $_GET['deleted'] ) ) echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Deleted.', 'content-traffic-maker' ) . '</p></div>';
		// phpcs:enable
	}

	private function render_status_badge( $status ) {
		$colors = array(
			'draft'    => '#64748b',
			'generated'=> '#0ea5e9',
			'approved' => '#16a34a',
			'rejected' => '#dc2626',
			'sent'     => '#7c3aed',
			'failed'   => '#dc2626',
		);
		$color = $colors[ $status ] ?? '#64748b';
		echo '<span style="background:' . esc_attr( $color ) . ';color:#fff;font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;text-transform:uppercase;letter-spacing:.05em;">' . esc_html( $status ) . '</span>';
	}
}
