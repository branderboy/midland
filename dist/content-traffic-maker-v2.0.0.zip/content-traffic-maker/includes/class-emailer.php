<?php
/**
 * Emailer — Resend API with fallback to wp_mail.
 * v2.0: test email button support, delivery logging, sender verification warning,
 *       detailed failure info stored in DB.
 *
 * @package ContentTrafficMaker
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CTM_Emailer {

	const RESEND_ENDPOINT = 'https://api.resend.com/emails';

	/**
	 * Send a brief email. Returns true or WP_Error.
	 *
	 * @param string $to
	 * @param string $subject
	 * @param string $html
	 * @param string $text
	 * @param string $from_name
	 * @param string $from_email
	 * @param string $resend_key
	 * @param int    $brief_id
	 * @param int    $client_id
	 * @return true|WP_Error
	 */
	public static function send( $to, $subject, $html, $text, $from_name, $from_email, $resend_key, $brief_id = 0, $client_id = 0 ) {
		if ( ! empty( $resend_key ) && ! empty( $from_email ) ) {
			$result = self::send_resend( $to, $subject, $html, $text, $from_name, $from_email, $resend_key );
		} else {
			$result = self::send_wp_mail( $to, $subject, $html, $text, $from_name, $from_email );
		}

		// Log every send attempt
		$log_data = array(
			'brief_id'      => $brief_id,
			'client_id'     => $client_id,
			'recipient'     => $to,
			'provider'      => ( ! empty( $resend_key ) ) ? 'resend' : 'wp_mail',
		);

		if ( is_wp_error( $result ) ) {
			$log_data['status']        = 'failed';
			$log_data['response_body'] = $result->get_error_message();
		} else {
			$log_data['status']        = 'sent';
			$log_data['response_code'] = 200;
		}

		CTM_DB::log_email( $log_data );

		return $result;
	}

	private static function send_resend( $to, $subject, $html, $text, $from_name, $from_email, $key ) {
		$from = $from_name ? "{$from_name} <{$from_email}>" : $from_email;

		$response = wp_remote_post(
			self::RESEND_ENDPOINT,
			array(
				'timeout' => 30,
				'headers' => array(
					'Authorization' => 'Bearer ' . $key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( array(
					'from'    => $from,
					'to'      => array( $to ),
					'subject' => $subject,
					'html'    => $html,
					'text'    => $text,
				) ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( $code >= 200 && $code < 300 ) {
			return true;
		}

		$body = wp_remote_retrieve_body( $response );
		$err  = json_decode( $body, true );
		$msg  = $err['message'] ?? $err['name'] ?? "HTTP {$code}: {$body}";
		return new WP_Error( 'resend_error', "Resend error: {$msg}" );
	}

	private static function send_wp_mail( $to, $subject, $html, $text, $from_name, $from_email ) {
		add_filter( 'wp_mail_content_type', function() { return 'text/html'; } );
		if ( $from_name && $from_email ) {
			add_filter( 'wp_mail_from',      function() use ( $from_email ) { return $from_email; } );
			add_filter( 'wp_mail_from_name', function() use ( $from_name )  { return $from_name; } );
		}
		$sent = wp_mail( $to, $subject, $html );
		return $sent ? true : new WP_Error( 'wp_mail_failed', 'wp_mail() returned false — check your server mail config.' );
	}

	/**
	 * Send a test email to verify sender config and Resend key.
	 */
	public static function send_test( $to, $from_name, $from_email, $resend_key ) {
		$subject = '[Content Traffic Maker] Test Email — Sender Config Verified';
		$html    = '<p style="font-family:sans-serif;">Your Content Traffic Maker sender is configured correctly. Resend API key and from address are working.</p>';
		$text    = 'Your Content Traffic Maker sender is configured correctly.';
		return self::send( $to, $subject, $html, $text, $from_name, $from_email, $resend_key );
	}
}
