<?php
/**
 * Cron — schedules briefs per client and runs the pipeline.
 * v2.0: Multi-client support, draft status, clean separation of generate vs send.
 *
 * @package ContentTrafficMaker
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CTM_Cron {

	const HOOK = 'ctm_send_brief';

	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
		add_action( 'init', array( __CLASS__, 'maybe_schedule' ) );
	}

	public static function add_schedules( $schedules ) {
		if ( ! is_array( $schedules ) ) {
			$schedules = array();
		}
		if ( ! isset( $schedules['weekly'] ) ) {
			$schedules['weekly'] = array(
				'interval' => WEEK_IN_SECONDS,
				'display'  => __( 'Once Weekly', 'content-traffic-maker' ),
			);
		}
		return $schedules;
	}

	public static function maybe_schedule() {
		// Schedule based on any enabled client
		$clients = CTM_DB::get_clients();
		$any_enabled = false;
		foreach ( $clients as $client ) {
			if ( $client->enabled ) {
				$any_enabled = true;
				break;
			}
		}

		$next = wp_next_scheduled( self::HOOK );
		if ( ! $any_enabled ) {
			if ( $next ) self::clear();
			return;
		}
		if ( ! $next ) {
			wp_schedule_event( time() + 300, 'daily', self::HOOK );
		}
	}

	public static function reschedule() {
		self::clear();
		self::maybe_schedule();
	}

	public static function clear() {
		wp_clear_scheduled_hook( self::HOOK );
	}

	/**
	 * Cron callback — loop enabled clients and generate+send for each.
	 */
	public static function run() {
		$global   = CTM_DB::get_settings();
		$clients  = CTM_DB::get_clients();
		foreach ( $clients as $client ) {
			if ( ! $client->enabled ) continue;
			$settings = array_merge( $global, CTM_DB::client_to_settings( $client ) );
			$brief    = CTM_Generator::generate( $settings );
			if ( is_wp_error( $brief ) ) continue;

			$html     = self::render_brief_html( $brief, $settings );
			$brief_id = CTM_DB::insert_brief( array(
				'client_id'  => $client->id,
				'brief'      => $brief,
				'brief_html' => $html,
				'status'     => 'draft',
			) );

			// Auto-send if enabled
			$result = CTM_Emailer::send(
				$client->recipient,
				'[' . $client->business_name . '] Video Brief — ' . gmdate( 'M j, Y' ),
				$html,
				strip_tags( $html ),
				$client->from_name,
				$client->from_email,
				$global['resend_api_key'] ?? '',
				$brief_id,
				$client->id
			);

			$status = ( true === $result ) ? 'sent' : 'failed';
			CTM_DB::update_brief( $brief_id, array(
				'status'  => $status,
				'sent_to' => ( true === $result ) ? $client->recipient : '',
				'sent_at' => ( true === $result ) ? current_time( 'mysql' ) : null,
			) );
		}
	}

	/**
	 * Generate a draft brief for a specific client. Returns array or WP_Error.
	 */
	public static function generate_for_client( $client_id ) {
		$global   = CTM_DB::get_settings();
		$client   = CTM_DB::get_client( $client_id );
		if ( ! $client ) {
			return new WP_Error( 'not_found', 'Client not found.' );
		}
		$settings = array_merge( $global, CTM_DB::client_to_settings( $client ) );
		$brief    = CTM_Generator::generate( $settings );
		if ( is_wp_error( $brief ) ) return $brief;

		$html     = self::render_brief_html( $brief, $settings );
		$brief_id = CTM_DB::insert_brief( array(
			'client_id'  => $client_id,
			'brief'      => $brief,
			'brief_html' => $html,
			'status'     => 'draft',
		) );

		return array( 'brief' => $brief, 'brief_html' => $html, 'brief_id' => $brief_id );
	}

	/**
	 * Send an existing brief by ID.
	 */
	public static function send_brief_by_id( $brief_id ) {
		$global = CTM_DB::get_settings();
		$row    = CTM_DB::get_brief( $brief_id );
		if ( ! $row ) {
			return new WP_Error( 'not_found', 'Brief not found.' );
		}
		$client = CTM_DB::get_client( $row->client_id );
		if ( ! $client ) {
			return new WP_Error( 'no_client', 'Client not found for this brief.' );
		}

		$brief = json_decode( (string) $row->brief_json, true );
		if ( ! is_array( $brief ) ) {
			return new WP_Error( 'bad_json', 'Brief data is corrupt.' );
		}
		$html = (string) $row->brief_html ?: self::render_brief_html( $brief, CTM_DB::client_to_settings( $client ) );

		$result = CTM_Emailer::send(
			$client->recipient,
			'[' . $client->business_name . '] Video Brief — ' . gmdate( 'M j, Y' ),
			$html,
			strip_tags( $html ),
			$client->from_name,
			$client->from_email,
			$global['resend_api_key'] ?? '',
			$brief_id,
			$client->id
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		CTM_DB::update_brief( $brief_id, array(
			'status'  => 'sent',
			'sent_to' => $client->recipient,
			'sent_at' => current_time( 'mysql' ),
		) );

		return array( 'sent' => true, 'brief_id' => $brief_id );
	}

	/**
	 * Minimal plain-text HTML for email delivery.
	 * The admin UI uses its own richer render method.
	 */
	public static function render_brief_html( $brief, $settings ) {
		$business = esc_html( $settings['business_name'] ?? '' );
		$date     = esc_html( $brief['brief_date'] ?? gmdate( 'F j, Y' ) );
		$html     = "<html><body style='font-family:Arial,sans-serif;color:#1a1a1a;max-width:680px;margin:0 auto;'>";
		$html    .= "<h2 style='color:#0f172a;'>{$business} — Video Brief</h2><p style='color:#64748b;'>{$date}</p><hr>";

		$segments = array(
			'com' => $settings['segment_a_label'] ?? 'Commercial',
			'res' => $settings['segment_b_label'] ?? 'Residential',
		);
		$types = array( 'seo' => 'SEO Video', 'offer' => 'Offer Video', 'viral' => 'Viral Video' );
		$num   = 1;

		foreach ( $segments as $seg => $seg_label ) {
			$html .= "<h3 style='margin-top:24px;color:#1e3a5f;'>{$seg_label}</h3>";
			foreach ( $types as $type => $type_label ) {
				$p        = "{$seg}_{$type}";
				$title    = esc_html( $brief["{$p}_video_title"] ?? '' );
				$priority = (int) ( $brief["{$p}_priority"] ?? 0 );
				$hook     = esc_html( $brief["{$p}_hook"] ?? '' );
				$cta      = esc_html( $brief["{$p}_cta"] ?? '' );
				$ex_title = esc_html( $brief["{$p}_example_title"] ?? '' );
				$ex_url   = esc_url( $brief["{$p}_example_url"] ?? '' );
				$ex_plat  = esc_html( $brief["{$p}_example_platform"] ?? '' );
				$conf     = (int) ( $brief["{$p}_confidence"] ?? 0 );

				$html .= "<div style='margin-bottom:20px;padding:12px;background:#f8fafc;border-left:4px solid #1d4ed8;'>";
				$html .= "<strong>#{$num} {$type_label}</strong> — Priority: {$priority}/10<br>";
				$html .= "<strong>{$title}</strong><br>";
				if ( $hook ) $html .= "<em>Hook:</em> \"{$hook}\"<br>";
				if ( $cta )  $html .= "<em>CTA:</em> {$cta}<br>";
				if ( $ex_title ) {
					$html .= "<em>Example:</em> ";
					$html .= $ex_url ? "<a href='{$ex_url}'>{$ex_title}</a>" : $ex_title;
					if ( $ex_plat ) $html .= " ({$ex_plat})";
					if ( $conf )    $html .= " — Confidence: {$conf}/10";
				}
				$html .= '</div>';
				$num++;
			}
		}
		$html .= '</body></html>';
		return $html;
	}
}
