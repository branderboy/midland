=== Content Traffic Maker ===
Contributors: tagglefish
Tags: video content, content marketing, SEO, video briefs, social media
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Video Content Intelligence Engine — AI-powered daily video briefs with trend validation, proof sources, multi-client management, and performance tracking.

== Description ==

Content Traffic Maker generates daily video briefs powered by Perplexity AI's live web search. Built for agencies and marketing teams managing multiple clients.

**Core Features**

* Multi-client workspace — separate profiles per client with individual schedules
* Video brief generation — 6 videos per client (SEO, Offer, Viral x 2 segments)
* Trend validation — confidence scores, source platform, date found, and evidence
* Brief workflow — Draft → Approve → Reject → Send (never auto-sends without review)
* Inline editing — edit any field directly in the Brief Builder
* Performance tracker — log views, clicks, leads, booked jobs, and winner formats
* Email delivery log — provider, status, and failure detail for every send
* Test email button — verify Resend config before going live
* AES-256 encrypted API key storage

== Requirements ==

* Perplexity API key (sonar-pro model recommended)
* Resend API key (optional, falls back to wp_mail)

== Installation ==

1. Upload the plugin folder to /wp-content/plugins/
2. Activate in Plugins → Installed Plugins
3. Go to CTM → Settings, add your API keys
4. Go to CTM → Clients, add your first client
5. Go to CTM → Dashboard and hit Generate

== Changelog ==

= 2.0.0 =
* Multi-client system with per-client profiles, segments, tone, competitors, schedule
* Brief workflow: Draft / Approve / Reject / Send stages
* Inline editing of all brief fields with auto-save
* Performance tracker: views, watch time, clicks, leads, booked jobs, winner format
* Email delivery log with per-send provider, status, and failure detail
* Test email button for sender verification
* Trend validation: confidence score, platform, date found, trend evidence field
* Proof source matching: intelligent keyword-based URL assignment vs. sequential injection
* Renamed from "Midland Floors Video Brief" to Content Traffic Maker
* New admin CSS/JS: command center aesthetic, stat cards, editable fields

= 1.9.0 =
* Initial release
