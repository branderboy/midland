<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;
$tables = array( 'ctm_briefs', 'ctm_clients', 'ctm_performance', 'ctm_email_log' );
foreach ( $tables as $t ) {
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$t}" ); // phpcs:ignore
}
delete_option( 'ctm_settings' );
delete_option( 'ctm_db_version' );
delete_option( 'ctm_encryption_key' );
