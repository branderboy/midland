/* Content Traffic Maker — Admin JS v2.0 */
(function($) {
	'use strict';

	// ── Inline field editing ───────────────────────────────────────────────────
	var saveTimer = null;
	$(document).on('input', '.ctm-editable', function() {
		var $el = $(this);
		clearTimeout(saveTimer);
		saveTimer = setTimeout(function() {
			var briefId = $el.data('brief-id');
			var field   = $el.data('field');
			var value   = $el.text().replace(/[""]/g, ''); // strip quote decorators

			$.post(ctm.ajax_url, {
				action:   'ctm_update_brief_field',
				nonce:    ctm.nonce,
				brief_id: briefId,
				field:    field,
				value:    value
			}, function(resp) {
				if (resp.success) {
					var $ind = $el.siblings('.ctm-save-indicator');
					if (!$ind.length) {
						$ind = $('<span class="ctm-save-indicator">✓ Saved</span>').insertAfter($el);
					}
					$ind.addClass('visible');
					setTimeout(function() { $ind.removeClass('visible'); }, 1500);
				}
			});
		}, 800);
	});

	// ── Performance form toggle ────────────────────────────────────────────────
	$(document).on('click', '.ctm-log-perf-btn', function() {
		var key  = $(this).data('video-key');
		var $frm = $('#perf-' + key);
		$frm.slideToggle(150);
	});

	$(document).on('click', '.ctm-cancel-perf', function() {
		$(this).closest('.ctm-perf-form').slideUp(150);
	});

	// ── Save performance ───────────────────────────────────────────────────────
	$(document).on('click', '.ctm-save-perf', function() {
		var $btn    = $(this);
		var $form   = $btn.closest('.ctm-perf-form');
		var briefId = $btn.data('brief-id');
		var clientId= $btn.data('client-id');
		var videoKey= $btn.data('video-key');

		var data = {
			action:     'ctm_update_performance',
			nonce:      ctm.nonce,
			brief_id:   briefId,
			client_id:  clientId,
			video_key:  videoKey,
			posted_url: $form.find('.posted_url').val(),
			platform:   $form.find('.platform').val(),
			views:      $form.find('.views').val(),
			watch_time: $form.find('.watch_time').val(),
			clicks:     $form.find('.clicks').val(),
			leads:      $form.find('.leads').val(),
			booked_jobs:$form.find('.booked_jobs').val(),
			winner:     $form.find('.winner').is(':checked') ? 1 : 0,
			notes:      $form.find('.notes').val()
		};

		$btn.text('Saving…').prop('disabled', true);
		$.post(ctm.ajax_url, data, function(resp) {
			if (resp.success) {
				$form.html('<p style="color:#16a34a;font-weight:600;">✓ Performance logged.</p>');
				setTimeout(function() { $form.slideUp(200); }, 1500);
			} else {
				$btn.text('Save').prop('disabled', false);
				alert('Error: ' + (resp.data || 'Could not save.'));
			}
		});
	});

})(jQuery);
