=== Smart Chat AI ===
Contributors: tagglefish
Tags: chat, ai chat, chatbot, lead capture, perplexity, customer support, contractor chat
Requires at least: 5.8
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.9.31
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI-powered chat widget that captures leads 24/7. Answers customer questions, books appointments, and collects contact info using Perplexity or OpenAI.

== Description ==

**Smart Chat AI** adds an intelligent chat widget to your website that answers visitor questions, captures leads, and collects contact information around the clock.

Powered by Perplexity Sonar or OpenAI (GPT-4o, GPT-4, GPT-3.5), the chat assistant responds naturally to customer questions about your services, pricing, and availability. When a visitor is ready, it captures their name, email, phone, and project details as a lead.

**Features:**

* AI chat widget on every page (configurable position and colors)
* Lead capture with name, email, phone, project details
* Conversation history stored and viewable in admin
* Dashboard with lead stats and analytics
* Email notifications when new leads are captured (via Resend or wp_mail)
* WhatsApp click-to-chat handoff button
* Calendly / booking link integration
* Customizable AI personality (helpful, professional, friendly)
* Starter question suggestions shown when chat opens
* Site content ingestion via sitemap for context-aware answers
* Business name and type configurable in settings

**Perfect for:**

Contractors, service businesses, agencies, and anyone who wants to capture leads outside business hours.

= Third-Party Services =

**Perplexity API (api.perplexity.ai)**

This plugin can send chat messages to the Perplexity API to generate AI responses. A Perplexity API key is required when this provider is selected and is stored in the WordPress database.

* [Perplexity Terms of Service](https://www.perplexity.ai/hub/legal/terms-of-service)
* [Perplexity Privacy Policy](https://www.perplexity.ai/hub/legal/privacy-policy)
* Data sent: chat messages, conversation history, business context

**OpenAI API (api.openai.com)**

This plugin can send chat messages to the OpenAI API to generate AI responses. An OpenAI API key is required when this provider is selected and is stored in the WordPress database.

* [OpenAI Terms of Use](https://openai.com/policies/terms-of-use)
* [OpenAI Privacy Policy](https://openai.com/policies/privacy-policy)
* Data sent: chat messages, conversation history, business context

**Resend (api.resend.com)**

When a Resend API key and From address are configured, lead notification emails are sent through the Resend delivery service. If no Resend key is set, notifications fall back to WordPress wp_mail.

* [Resend Privacy Policy](https://resend.com/privacy-policy)
* Data sent: lead name, email, phone, and project details

== Installation ==

1. Upload the plugin zip via Plugins > Add New > Upload Plugin
2. Activate the plugin
3. Go to Smart Chat AI > Settings and enter your Perplexity or OpenAI API key
4. Customize chat widget colors, position, and business info
5. The chat widget appears on your site automatically

== Frequently Asked Questions ==

= Do I need a Perplexity or OpenAI API key? =

Yes. You need one API key depending on which provider you choose. Create a Perplexity key at perplexity.ai or an OpenAI key at platform.openai.com. The plugin stores your key in the WordPress database.

= How much does the API cost? =

Both providers charge per token. Perplexity Sonar and OpenAI GPT-4o-mini are affordable for chat. Most conversations cost less than $0.01.

= Can I customize what the AI says? =

Yes. Set your business name, type, and AI personality in Settings. You can also write a custom preprompt to shape how the assistant responds. The AI adapts its responses accordingly.

== Changelog ==

= 1.9.31 =
* Security: added sanitize callbacks for all bare register_setting() calls (API keys, model, title, subtitle, provider, business fields)
* Bugfix: uninstall.php no longer uses %i identifier placeholder for DROP TABLE (incompatible with WP < 6.1); table names are now built directly from $wpdb->prefix
* Bugfix: AI handler now returns a fallback error message when the API returns an empty response body with no formal error code
* Code quality: lead capture now requires a real name alongside email or phone before creating a lead record; email-prefix and "Website visitor" fallback names removed

= 1.9.15 =
* Restored the Leads tab (Smart Chat AI > Leads) so chat leads captured through the conversation are visible in the admin.

= 1.9.14 =
* Conversation capture hardened: the visitor message is saved before the AI call, and the AI call is guarded, so the conversation is always recorded even if the provider errors. Native lead capture (name/email/phone from the chat) still runs and emails the lead.

= 1.9.13 =
* Hardened: native lead capture is wrapped so a failing CRM/bridge hook can never break message sending (conversation always works)

= 1.9.12 =
* Native free-hand lead capture: the assistant just asks for name, email or phone, and what it's about (no form). Once shared, a chat lead is saved and an email notification is sent.

= 1.9.11 =
* Removed the chat own lead system. Leads are captured by the embedded Smart Form instead.
* Conversations page now shows the full transcript with a date and time on every message, and the session start/last-message timestamps.

= 1.9.10 =
* Chat scheduling uses the embedded form again so leads are captured; the Calendly "Pick a time" link is now offered after the form submits.

= 1.9.9 =
* Booking link is now read from the embedded form per-form setting (Smart Forms > edit form > Booking link), not a global chat setting; removed the Booking URL field from chat Settings.

= 1.9.8 =
* Added a Booking URL (Calendly) field to Smart Chat AI > Settings so the link can be managed from the admin.

= 1.9.7 =
* Scheduling in chat now shows a clean "Pick a time" Calendly button instead of the embedded form, avoiding the submit error and page redirect.

= 1.9.6 =
* Form title inside the chat is now chat-sized (14px), the description smaller (12px).

= 1.9.4 =
* The chat window now auto-expands to its larger size when the booking form opens, and restores the previous size when the form closes.

= 1.9.3 =
* Fixed the double-scrollbar when the booking form opens: the form now takes over the chat body so there is a single scroll area.
* Added an Enlarge button in the header to expand the chat window (and shrink it back).

= 1.9.2 =
* Rewrote the default chat prompt: shorter replies, no dashes, no long-winded statements.
* When a visitor wants to schedule, the AI now points them to the booking form that opens in the chat instead of asking for name and phone in text.

= 1.9.1 =
* Sitemap ingestion: try multiple sitemap URLs so the crawl works regardless of SEO plugin.
* Send a browser-like user-agent and follow redirects, fixing "sitemap empty or unreachable" caused by hosts/WAFs blocking the default WordPress user-agent.

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.9.31 =
Security release. Update immediately to apply sanitization patches and uninstall compatibility fix.
