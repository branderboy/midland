<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// Clear the daily content-context refresh cron.
if ( function_exists( 'wp_clear_scheduled_hook' ) ) {
    wp_clear_scheduled_hook( 'scai_ctx_refresh' );
}

// Drop tables.
// Note: %i (identifier placeholder) requires WP 6.1+. Since this plugin
// targets WP 5.8+, we build the table names directly from the known prefix
// instead. The names are not user-supplied so there is no injection risk.
$leads_table         = $wpdb->prefix . 'smart_chat_leads';
$conversations_table = $wpdb->prefix . 'smart_chat_conversations';

// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
$wpdb->query( "DROP TABLE IF EXISTS `{$leads_table}`" );
// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
$wpdb->query( "DROP TABLE IF EXISTS `{$conversations_table}`" );

// Delete options.
// Use delete_option() instead of a raw DELETE query so there is no
// interpolated table name, no LIKE wildcard escaping ambiguity, and
// WordPress fires the expected option-deletion hooks.
// List every option key the plugin registers so nothing is left behind.
$plugin_options = array(
    'smart_chat_chat_enabled',
    'smart_chat_chat_position',
    'smart_chat_chat_color',
    'smart_chat_chat_logo',
    'smart_chat_chat_title',
    'smart_chat_chat_subtitle',
    'smart_chat_ai_provider',
    'smart_chat_perplexity_api_key',
    'smart_chat_openai_api_key',
    'smart_chat_ai_model',
    'smart_chat_ai_temperature',
    'smart_chat_lead_email',
    'smart_chat_enable_email_notifications',
    'smart_chat_business_name',
    'smart_chat_business_type',
    'smart_chat_ai_personality',
    'smart_chat_preprompt',
    'smart_chat_whatsapp_number',
    'smart_chat_whatsapp_greeting',
    'smart_chat_booking_url',
    'smart_chat_resend_api_key',
    'smart_chat_resend_from',
    'smart_chat_suggestions',
    'smart_chat_db_version',
    // Content context options (registered via SCAI_Content_Context constants).
    'scai_ctx_enabled',
    'scai_ctx_sitemap_url',
    'scai_ctx_page_limit',
    'scai_ctx_chars_per',
    'scai_content_context',
);

foreach ( $plugin_options as $option ) {
    delete_option( $option );
}
