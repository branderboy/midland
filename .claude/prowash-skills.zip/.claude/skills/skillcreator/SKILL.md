---
description: Generate a new project-level skill from observed patterns in this repo. Scans recent commits and files for repeated conventions, then writes a SKILL.md capturing them. Invoke with /skillcreator <skill-name> [topic-hint].
---

# Skill Creator

Generates a new `.claude/skills/<name>/SKILL.md` for this project.

## Args

- `<skill-name>` (required): kebab-case directory + slash-command name
- `<topic-hint>` (optional): a phrase narrowing what the skill should cover (e.g. "deploy workflow", "schema patterns", "blog authoring")

## Workflow

1. **Confirm scope.** Restate what the skill will cover in one sentence; ask the user to confirm.
2. **Sample the repo.** Read the most recent 20 commits, the directories most affected, and 3-5 representative files in that area.
3. **Extract conventions.** Look for:
   - Repeated patterns (file structure, naming, copy strings)
   - Forbidden patterns (things consistently scrubbed)
   - Required boilerplate (header chrome, schema blocks, footer)
   - Magic constants (colors, phone, addresses)
4. **Draft SKILL.md.** Use this structure:
   ```markdown
   ---
   description: <when-to-invoke description, ends with "Invoke with /<skill-name>.">
   ---

   # <Title>

   ## Conventions
   <bulleted list of MUST / NEVER rules>

   ## Required steps when invoked
   <numbered list>

   ## Output format
   <how to report findings>
   ```
5. **Show the draft.** Print the proposed SKILL.md to the user.
6. **On approval, write + commit.** Create `.claude/skills/<skill-name>/SKILL.md`, stage it, commit with message `skills: add /<skill-name> project-level skill`, push.

## Constraints

- Don't invent rules - only capture what's actually observed in the codebase.
- One skill = one focused responsibility. If the topic is broad, propose splitting into multiple skills.
- Keep SKILL.md under 200 lines. Skills are recipes, not manuals.
- Reference existing skills (`ui-polish`, etc.) instead of duplicating rules.

## On approval

After the user approves, write the file, then run:
```bash
git add .claude/skills/<skill-name>/SKILL.md
git commit -m "skills: add /<skill-name> project-level skill"
git push -u origin <current-branch>
```
