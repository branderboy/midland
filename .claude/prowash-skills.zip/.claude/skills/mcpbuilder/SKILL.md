---
description: Scaffold a Model Context Protocol (MCP) server. Generates Python or TypeScript boilerplate with tools, resources, and the right SDK imports. Invoke with /mcpbuilder <server-name> [language=python|ts].
---

# MCP Builder

Scaffolds a fresh MCP server in a new subdirectory of the repo (or a path the user specifies). MCP = Model Context Protocol, the standard Claude Code uses for plugging in custom tools.

## Args

- `<server-name>` (required): kebab-case server name. Becomes the package name.
- `language=python|ts` (optional, default `python`): which SDK to use.
- `path=<dir>` (optional, default `.mcp/<server-name>`): where to scaffold.

## Workflow

1. **Confirm.** Restate: "I'll scaffold an MCP server named `<name>` in `<lang>` at `<path>`. It will expose tools `[a, b]` and resources `[x, y]` based on what you tell me. OK?"
2. **Ask the tool/resource shape.** Two questions:
   - "What tools do you want? (e.g. `query_database(sql)`, `send_slack(channel, msg)`)"
   - "Any resources to expose? (URI patterns the model can read, e.g. `prowash://orders/{id}`)"
3. **Scaffold the directory:**

### Python layout
```
.mcp/<name>/
├── pyproject.toml
├── README.md
├── src/<name>/
│   ├── __init__.py
│   └── server.py
└── .gitignore
```

`server.py` template:
```python
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("<server-name>")

@mcp.tool()
def example_tool(arg1: str) -> str:
    """One-line description shown to the model."""
    return f"got {arg1}"

@mcp.resource("example://{id}")
def example_resource(id: str) -> str:
    """One-line description shown to the model."""
    return f"resource for {id}"

if __name__ == "__main__":
    mcp.run()
```

`pyproject.toml`:
```toml
[project]
name = "<server-name>"
version = "0.1.0"
dependencies = ["mcp>=1.0.0"]
[project.scripts]
<server-name> = "<server_name>.server:mcp.run"
```

### TypeScript layout
```
.mcp/<name>/
├── package.json
├── tsconfig.json
├── README.md
├── src/server.ts
└── .gitignore
```

`server.ts` template:
```ts
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

const server = new McpServer({ name: "<server-name>", version: "0.1.0" });

server.tool(
  "example_tool",
  { arg1: z.string() },
  async ({ arg1 }) => ({ content: [{ type: "text", text: `got ${arg1}` }] })
);

await server.connect(new StdioServerTransport());
```

`package.json`:
```json
{
  "name": "<server-name>",
  "version": "0.1.0",
  "type": "module",
  "main": "dist/server.js",
  "scripts": { "build": "tsc", "start": "node dist/server.js" },
  "dependencies": {
    "@modelcontextprotocol/sdk": "^1.0.0",
    "zod": "^3.0.0"
  },
  "devDependencies": { "typescript": "^5.0.0", "@types/node": "^20.0.0" }
}
```

4. **README.md** with: install, run, register-with-Claude-Code instructions (the JSON snippet for `~/.claude/settings.json` `mcpServers` entry).

5. **Wire into Claude Code config.** Show the user the snippet to paste into `~/.claude/settings.json`:
```json
{
  "mcpServers": {
    "<server-name>": {
      "command": "uvx",
      "args": ["--from", ".mcp/<server-name>", "<server-name>"]
    }
  }
}
```
For TS: command becomes `node` with the built `dist/server.js`.

6. **Don't auto-install dependencies.** Tell the user to run `uv sync` or `npm install` themselves.

## Constraints

- No fabricated SDK APIs. The Python `FastMCP` and TS `McpServer` patterns above are the official ones.
- Skill output is scaffold + instructions. The user runs the install/build themselves.
- Don't auto-register the MCP server in their settings - show the snippet and let them decide.
- Keep tools focused. If they ask for many tools, propose grouping them by domain into multiple servers.

## Reference docs

- https://modelcontextprotocol.io/quickstart/server (Python + TS)
- https://github.com/modelcontextprotocol/python-sdk
- https://github.com/modelcontextprotocol/typescript-sdk
