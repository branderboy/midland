---
description: Smoke-test the static site - link checking, HTML/schema validation, broken images, page load. Invoke with /webapptesting before merging a branch or after big sitewide edits.
---

# Web App Testing

Static-site testing for prowashdetail.net. Runs entirely from the command line - no headless browser required.

## Test suite

When invoked, run all sections in order. Stop and report after a section fails only if the failure blocks subsequent tests.

### 1. HTML well-formedness
For every `*.html` file:
- Confirm balanced `<html>`, `<head>`, `<body>` open/close
- Confirm `<title>` exists and is non-empty
- Flag inline `<style>` blocks longer than 100 lines (refactor candidates)

```bash
find . -name "*.html" -exec sh -c '
  for f; do
    grep -q "<title>" "$f" || echo "MISSING TITLE: $f"
    grep -q "</html>" "$f" || echo "MISSING </html>: $f"
  done
' sh {} +
```

### 2. Internal link integrity
Walk every `<a href="...">` and `src="..."` value. For relative paths:
- Confirm the target file exists at the resolved path
- Skip `mailto:`, `tel:`, `#fragment`, `https://`

Use `python3` with `BeautifulSoup` if available, otherwise a `grep` + path-resolution shell loop.

### 3. Schema validation
For each JSON-LD block (between `<script type="application/ld+json">` ... `</script>`):
- Confirm valid JSON
- Confirm required `@context` and `@type`
- For `AutoWash`/`LocalBusiness`: confirm `name`, `address`, `telephone`
- For `BreadcrumbList`: confirm itemListElement is an array
- For `FAQPage`: confirm mainEntity has Question + acceptedAnswer

```bash
python3 -c '
import re, json, sys, glob
for p in glob.glob("**/*.html", recursive=True):
    txt = open(p).read()
    for m in re.finditer(r"<script type=\"application/ld\+json\">(.*?)</script>", txt, re.S):
        try: json.loads(m.group(1))
        except Exception as e: print(f"BAD JSON-LD in {p}: {e}")
'
```

### 4. Broken images
For every `<img src="..."`:
- If relative, confirm file exists
- If absolute (Pexels, etc.), `curl -sI` and check for 200/3xx
- If `prowashdetail.net/wp-content/...`, FLAG (legacy WordPress URL, may not exist)

### 5. Sitewide chrome
Each HTML page must declare:
- canonical link
- `meta name="description"`
- `og:type`, `og:url`, `og:title`, `og:description`, `og:image`
- `twitter:card`, `twitter:title`, `twitter:description`, `twitter:image`
- `link rel="icon"` and `link rel="apple-touch-icon"`
- `link rel="stylesheet"` with cache-bust query

Report any page missing any of those.

### 6. Brand-copy lint
Re-run the `ui-polish` checklist (em-dash, middle-dot, "Facility Hours", $10 dispatch, etc.) and report violations.

### 7. Sitemap & robots sanity
- `sitemap.xml` parses
- Every URL in sitemap.xml resolves to an existing file in the repo
- `robots.txt` if present allows the right paths

### 8. Live smoke (optional)
If the user passes `--live`, curl each page URL on the production domain and confirm 200. Use the sitemap as the page list.

## Output format

```
=== /webapptesting report ===
HTML well-formedness: PASS (45 files)
Link integrity: 2 broken
  - locations/clinton.html:194 -> locations/clinton/window-tinting.html (OK)
  - blog/hand-wash-vs-automatic-car-wash.html:88 -> images/wash.jpg MISSING
Schema validation: PASS
Broken images: 1
  - rewards.html line 47 -> wp-content/uploads/2016/.../detail2.jpg returns 404
Sitewide chrome: PASS
Brand-copy lint: 3 violations
  - faq.html line 312 has em-dash
  - ...
Sitemap: PASS
=== Summary: 6 issues. ===
```

Apply fixes for trivial issues (broken relative links to known-good targets, brand-copy violations); ask before doing schema or live-domain changes.
