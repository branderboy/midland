---
description: Apply Pro Wash brand conventions, schema patterns, and front-end rules to any UI change in this repo. Use when editing HTML/CSS, adding pages, or polishing a section. Invoke with /ui-polish.
---

# Pro Wash UI Polish

Conventions for prowashdetail.net (`branderboy/prowash-html`).

## Brand palette

Use the CSS variables in `css/styles.css`. **Never** hardcode hex values that already have a variable.

- `--dark-blue` — primary navy (headers, footer, body text accents)
- `--red` — primary CTA, highlights, accent stripe
- `--white` — surface
- `--gray-mid` — borders
- `--text-muted` — body secondary text
- Gold accent (used sparingly): `#FFD976`

Tagline: **"More Shine. Less Time."** (capitalization exact)
Award badge: Steve Harvey "Steve's Standout" — when shown, link/cite consistently.

## Typography

- Headings: Montserrat, 700–900
- Body: Open Sans, 400–700
- ALL-CAPS headlines for h1/h2 in heroes; sentence case for h3+ otherwise.

## Cache-busting (REQUIRED)

`css/styles.css` is referenced as `css/styles.css?v=YYYYMMDD-N` (or `../css/...` from subfolders).

After any CSS or sitewide HTML change, **bump the version** sitewide:

```bash
grep -rl "styles.css?v=20260504-N" --include="*.html" \
  | xargs -r sed -i 's/styles\.css?v=20260504-N/styles.css?v=20260504-(N+1)/g'
```

The version travels in the same commit as the change. HostGator caches aggressively without it.

## Body-copy rules

- **No em-dashes (—) or en-dashes (–) in body copy.** Use ` - ` (space-hyphen-space) or comma. Em-dashes were stripped sitewide; don't reintroduce.
- **No middle dots (·) as separators.** Use commas or pipes (`|`) in footers/breadcrumbs.
- "Business Hours", never "Facility Hours".
- "Walk-Ins & Appointments Welcome" for the wash; "Book Car Detailing" CTA goes to `book.html` (Acuity).
- Mobile dispatch fee: **$50** (was $10 — never roll back).
- Phone everywhere: `(301) 307-1414`. Tel links: `tel:3013071414`.

## Locations & HQ

5 stores. **HQ is Capitol Heights** (29 Hampton Park Blvd, 38.8895, -76.8562). Don't say HQ is Clinton.

| Slug | Address | GBP CID |
|------|---------|---------|
| capitol-heights | 29 Hampton Park Blvd | 9335521404958725292 |
| clinton | 6311 Coventry Way | 6639174920859153601 |
| bowie | 4406 NW Crain Hwy | 12474360556806488085 |
| upper-marlboro | 7538 NW Crain Hwy | 2474880660976643027 |
| washington-dc | 1329 Kenilworth Ave NE | 15828396497321689317 |

## Booking & service routing

- **Car wash → walk-in only**, no booking. Pages may say "No Appointment Necessary".
- **Car detailing → book via Acuity** at `book.html` with location tabs.
- **Window tinting → book via category-filtered Acuity iframe** on `services/window-tinting.html` (`?owner=14099514&appointmentType=category:Window+Tinting`).
- Tinting Trucks tier: **$60 = 2 front windows only**. Always include "Additional windows / SUVs: call (301) 307-1414." The tint truck card itself does NOT advertise the bundled free wash; the cars tier does.

## Pricing canon

Use the exact descriptions from the canonical pricing file:

- Pro Wash: #1 Express Wash $20, #2 Pro Wash $35, #3 Express Hand Wax $85
- Pro Detail: #4, #5, #8, #9, #10 — each card uses "Includes #X +..." phrasing
- Detail cards include an **XL "Upcharge possible"** column

## Schema (JSON-LD) patterns

- Top-level business node has `"@id": "https://www.prowashdetail.net/#business"`
- Each location AutoWash has `"@id": "https://www.prowashdetail.net/locations/<slug>.html#location"`
- Homepage `sameAs` array: FB, IG, Yelp (Capitol Heights + Clinton), all 5 GBP `cid` URLs
- Per-location `sameAs`: FB + IG + that location's GBP (+ Yelp where matched)
- FAQ pages emit `FAQPage` JSON-LD; blog posts emit `BlogPosting` + `BreadcrumbList`
- Service pages reference Wikipedia in `sameAs` where an authoritative article exists (e.g. ceramic-coating → `en.wikipedia.org/wiki/Ceramic_coating`)

## Page chrome (every HTML page)

Required `<head>` order:
1. charset, viewport
2. `<title>` (under 60 chars, includes brand)
3. `<meta name="description">` (150-160 chars)
4. `<link rel="canonical">`
5. Open Graph (`og:type`, `og:url`, `og:title`, `og:description`, `og:image`, `og:site_name`)
6. Twitter Card (`twitter:card=summary_large_image`, title, description, image)
7. Favicon: `<link rel="icon">` + `<link rel="apple-touch-icon">` (path adjusts for subfolders)
8. JSON-LD structured data
9. Font preconnects + Google Fonts CSS link
10. `<link rel="stylesheet" href="...styles.css?v=...">`

`/favicon.ico` and `/favicon.png` exist at the repo root as fallback.

## Footer

- Background is `--dark-blue`. **All h3/h4/h5 in `.footer-col` must be `color: white !important`** — otherwise they inherit dark-blue and disappear.
- Footer bottom line: `&copy; 2026 ... | Blog | Privacy Policy | Terms & Conditions`
- Footer link colors set explicitly to white where they sit on the dark band.

## Nav

- Site-wide nav button is `.nav-cta`: two-line "Book Car / Detailing" red pill.
- Services dropdown includes `Ceramic Coating` as an indented `.dd-sub` under Car Detailing.
- Programs dropdown contains rideshare and car-dealerships under a "For Business" subheading.

## File-path conventions

- Root pages reference `images/...`, `css/styles.css?v=...`, `book.html`
- One-level subfolder pages (`services/`, `locations/`) reference `../images/`, `../css/`, `../book.html`
- Two-level subfolder pages (`services/car-detailing/ceramic-coating.html`, `locations/<slug>/<service>.html`) reference `../../images/`, `../../css/`

## When invoked

When the user types `/ui-polish` (or you're applying these rules implicitly), do the following pass on the changes since the last commit:

1. Search for newly introduced em/en-dashes in body copy → replace with hyphens
2. Search for hardcoded `#hex` colors that match an existing CSS variable → replace
3. Confirm the cache-bust version was bumped if any `.css` or shared HTML changed
4. Confirm any new page declares: canonical, OG, Twitter, JSON-LD, favicon, stylesheet
5. If a service page mentions tint truck pricing, confirm the "2 front windows / call for additional or SUVs" clarifier is present
6. If a footer was added/modified, verify `.footer-col h3/h4/h5` resolve to white
7. Report any violations found and propose the smallest patch
