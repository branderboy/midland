---
description: Search for front-end design resources - skills, plugins, components, accessibility patterns, color/typography references. Invoke when the user wants to discover external design tooling or evaluate options for a UI change. Use /frontenddesign.
---

# Front-End Design Search

When invoked, run a focused search across these sources and surface what's relevant to the user's question. Do not pull in everything; rank by recency and trust.

## Sources to query

1. **Claude Code skills registry** - https://agentskills.io (community)
2. **Claude Code plugins** - any plugin manifests in `~/.claude/plugins/` and the plugin marketplace
3. **GitHub** via WebSearch:
   - `site:github.com "claude-code" skill` for community skills
   - `site:github.com SKILL.md frontend OR design OR ui`
4. **Component libraries (only if relevant)**: Radix UI, shadcn/ui, Headless UI, Reach UI, Tailwind UI
5. **Authoritative references**:
   - WCAG 2.2 quick reference (accessibility) - https://www.w3.org/WAI/WCAG22/quickref/
   - MDN CSS reference
   - Smashing Magazine, web.dev, CSS-Tricks for pattern articles

## Workflow

1. Restate the user's goal in one sentence so they can correct it.
2. Run 2-3 parallel `WebSearch` calls covering: (a) prebuilt skill/plugin, (b) authoritative pattern article, (c) component-library implementation if applicable.
3. Return a short ranked list (5-8 items max) with: title, URL, one-sentence why-it-matters.
4. End with a recommendation: "If you want to ship in 1 commit, use X. If you want to learn the pattern, read Y."

## Constraints

- Don't fabricate URLs. If a search returns no good match, say so.
- Don't paste large excerpts; link out.
- Mention licensing if recommending code (MIT vs proprietary matters for embed).
- Skip results older than 2 years for pattern articles unless they're foundational (WCAG, MDN).
