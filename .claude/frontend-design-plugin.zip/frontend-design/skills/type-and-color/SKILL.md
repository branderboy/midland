---
name: type-and-color
description: Use this skill when setting up the typography and color tokens for any web build, immediately after design-direction has locked in an aesthetic. Triggers on font selection, color palette decisions, CSS variables, design tokens, theme setup, dark mode, or anything related to the visual foundation of a page. Also triggers when the user says "the colors feel off," "the fonts look generic," "needs better contrast," "make the type more interesting," or asks to fix a visual hierarchy problem. This skill provides specific font pairings (none of them Inter/Roboto/Arial as display), real color systems with hex values, and the rules that separate professional type and color work from AI defaults.
---

# Type and Color

Typography and color are 80% of why a design looks designed. Get them right and everything else can be average. Get them wrong and nothing else can save it.

## The two rules above all others

**Rule 1: Pair, don't repeat.** A real type system has tension. Display vs. body. Serif vs. sans. Tight vs. loose. Don't ship three weights of one sans and call it a system.

**Rule 2: Dominate, don't distribute.** Color works through hierarchy. ONE dominant color (60-70% of the screen), ONE accent (5-10%), the rest neutrals. A palette of five equal colors is what AI generates. A real palette has a clear leader.

## Font pairings that actually work

These are tested combinations. All paid fonts have a free Google Fonts swap noted. Pick a row, use both fonts, don't mix rows.

### Editorial / Premium pairings

| Display | Body | Vibe |
|---|---|---|
| GT Sectra | GT America | The NYT Magazine standard |
| Tiempos Headline | Söhne | Pentagram-coded |
| **Fraunces** (free) | **Inter Tight** (free) | Premium-feeling for free |
| **Cormorant** (free) | **Lora** (free) | Old-world editorial |
| **Newsreader** (free) | **Inter Tight** (free) | Modern editorial |
| **EB Garamond** (free) | **Work Sans** (free) | Classical serif + clean sans |

### Modern tech pairings

| Display | Body | Vibe |
|---|---|---|
| Söhne | Söhne Mono | Linear / Vercel |
| **Geist** (free) | **Geist Mono** (free) | The Vercel-released gift |
| **Inter** at extreme weights | **Inter** at body | Swiss with rigor |
| **Cabinet Grotesk** (free) | **Inter Tight** (free) | Slightly warmer tech |
| **Manrope** (free) | **Manrope** (free) | Clean, neutral, geometric |

### Brutalist / Editorial-weird pairings

| Display | Body | Vibe |
|---|---|---|
| **Times New Roman** (system) | **Times New Roman** (system) | Pure brutalist |
| **Courier New** (system) | **Inter** (free) | Terminal-meets-clean |
| **Redaction** (free) | **Söhne** | Stamped-document feel |
| **PP Editorial New** | **PP Neue Montreal** | Pangram Pangram premium combo |
| **DM Serif Display** (free) | **DM Sans** (free) | Bold display, soft body |

### Luxury pairings

| Display | Body | Vibe |
|---|---|---|
| Bodoni 72 | Söhne | Hermès-coded |
| **Bodoni Moda** (free) | **Cormorant** (free) | Free luxury |
| Didot | GT America | High-end fashion |
| **Playfair Display** (free, but overused — use Bodoni Moda instead if possible) | **Lora** (free) | Recognizable luxury |

### Warm / Organic pairings

| Display | Body | Vibe |
|---|---|---|
| **Cormorant** (free) | **Cormorant** body weight | Botanical |
| **Gloock** (free) | **Manrope** (free) | Modern serif + clean sans |
| **Caveat** (free, used sparingly) | **Lora** (free) | Hand + warm serif |

### Mono-driven pairings

| Display | Body | Vibe |
|---|---|---|
| **JetBrains Mono** (free) | **JetBrains Mono** (free) | Cyberpunk / dev tool |
| **IBM Plex Mono** (free) | **IBM Plex Sans** (free) | Industrial / technical |
| **Space Mono** (free) | **Space Grotesk** (free) | Y2K / playful tech |
| **Fira Code** (free) | **Inter** (free) | Code-leaning |

### Maximalist pairings

Mix on purpose. Pick 2-3 from this set:
- **Anton** (free) for huge condensed display
- **Bebas Neue** (free) for industrial display
- **Space Grotesk** (free) for body
- **Rubik Mono One** (free) for accents
- **Press Start 2P** (free) for retro game accents

## Type rules that always apply

**Sizes:** Use a real type scale, not random pixel values. Tested scales:
```
Editorial: 12, 14, 17, 20, 28, 40, 64, 96, 144 (1.4x ratio, irregular at top)
Tech: 12, 14, 16, 20, 24, 32, 40, 48, 64, 80 (clean steps)
Display-driven: 14, 16, 20, 64, 128, 240 (huge gaps for drama)
```

**Letter-spacing:**
- Display headlines (40px+): -0.02em to -0.04em (tighter)
- Body: 0
- Small caps and labels: 0.1em to 0.2em (looser)
- All caps anything else: 0.05em minimum

**Line height:**
- Display: 0.95 to 1.05
- Headlines: 1.1 to 1.2
- Body: 1.5 to 1.65
- Captions: 1.3 to 1.4

**Font weights:** Use a maximum of 3-4 weights from any one family. More is noise. Common picks: 400 (regular) + 500 (medium for emphasis) + 700 (bold for headlines). Or 300 + 400 + 700 for more contrast.

**The italic question:** Italics belong in editorial work. They feel out of place in tech UIs. Match the aesthetic.

## Color systems that actually work

A real color system has roles, not just shades. Every project gets these tokens:

```css
:root {
  /* Background tier */
  --bg: ...;           /* main page background */
  --bg-elev: ...;      /* cards, elevated surfaces */
  --bg-deep: ...;      /* recessed areas */

  /* Foreground tier */
  --ink: ...;          /* primary text */
  --ink-mute: ...;     /* secondary text */
  --ink-dim: ...;      /* tertiary, captions */

  /* Lines and borders */
  --rule: ...;         /* hairline rules */
  --border: ...;       /* card borders */

  /* The accent */
  --accent: ...;       /* the ONE accent color */
  --accent-deep: ...;  /* hover/active state of accent */

  /* States (only if needed) */
  --warn: ...;
  --danger: ...;
  --ok: ...;
}
```

## Locked palettes by archetype

Copy these directly. Don't tweak. They work because the relationships are tested.

### Editorial Cream
```css
--bg: #F5F2EC;
--bg-elev: #FFFFFF;
--ink: #1A1A1A;
--ink-mute: #4A4A4A;
--ink-dim: #767676;
--rule: #1A1A1A;
--border: #E5E0D5;
--accent: #8B1A1A;        /* oxblood */
--accent-deep: #5C0E0E;
```

### Editorial Navy on Cream
```css
--bg: #F5F2EC;
--ink: #1A1A1A;
--accent: #1F3A5F;
--accent-deep: #122440;
```

### Soft-Tech Dark (Linear-coded)
```css
--bg: #08070B;
--bg-elev: #131218;
--bg-deep: #050407;
--ink: #FAFAFA;
--ink-mute: #A1A1AA;
--ink-dim: #71717A;
--border: #27272A;
--accent: #5E6AD2;
--accent-deep: #4751B4;
```

### Soft-Tech with Teal accent
```css
--bg: #08070B;
--bg-elev: #131218;
--ink: #FAFAFA;
--accent: #00D4AA;
--accent-deep: #00A085;
```

### Swiss White
```css
--bg: #FFFFFF;
--ink: #000000;
--ink-mute: #444444;
--rule: #000000;
--accent: #FF0000;        /* the canonical Swiss red */
```

### Swiss IBM Blue
```css
--bg: #FFFFFF;
--ink: #161616;
--mute: #525252;
--accent: #0F62FE;        /* IBM blue */
```

### Luxury Ivory
```css
--bg: #FAF7F2;
--bg-elev: #FFFFFF;
--ink: #1F1F1F;
--ink-mute: #5C5C5C;
--accent: #B8860B;        /* warm gold */
--accent-deep: #8B6508;
```

### Warm Botanical
```css
--bg: #F4F1EA;
--ink: #3D2817;
--ink-mute: #6B5544;
--sage: #9CAE94;
--terra: #C97B5C;
--mustard: #D4A574;
--accent: #C97B5C;        /* terra as the lead accent */
```

### Brutalist Default
```css
--bg: #FFFFFF;
--ink: #000000;
--link: #0000EE;          /* keep the default browser blue */
--visited: #551A8B;       /* keep the default visited */
```

### Cyberpunk Terminal Green
```css
--bg: #0A0A0A;
--bg-elev: #131313;
--ink: #00FF41;
--ink-mute: #00B82F;
--accent: #FF0040;
--mute: #1F1F1F;
```

### Cyberpunk Amber
```css
--bg: #0A0A0A;
--ink: #FFB000;
--ink-mute: #B87E00;
--accent: #FF0040;
```

### Soft-Pastel Peach
```css
--bg: #FFE8D6;
--bg-elev: #FFF1E5;
--ink: #2D2A26;
--accent: #C97B5C;        /* coral */
--accent2: #B5D6A7;       /* sage */
```

### Soft-Pastel Butter
```css
--bg: #FFF8E7;
--ink: #2D2A26;
--accent: #F4978E;        /* coral */
```

### Mono Black
```css
--bg: #000000;
--ink: #FFFFFF;
--ink-mute: #A1A1A1;
--border: #333333;
--accent: #FF3B30;        /* one accent only */
```

### Mono White
```css
--bg: #FFFFFF;
--ink: #0A0A0A;
--ink-mute: #6B6B6B;
--border: #E5E5E5;
--accent: #FF3B30;
```

## The hierarchy rule

When you have a color system, use it like this:

- **60-70%** of the screen is `--bg`
- **20-30%** is `--ink` (text and primary content)
- **5-10%** is the accent color combined
- **Less than 1%** is everything else (warn, danger, etc.)

If you find yourself coloring half the screen with the accent, you've broken the system.

## Reference files

- `references/font-loading.md` — How to load Google Fonts efficiently, fallback stacks, and FOUT/FOIT prevention. Read when setting up a new project.
- `references/contrast-and-accessibility.md` — WCAG contrast minimums, when to break them carefully, and how to check yourself. Read if working on anything that needs to be accessible.

## Output

When this skill triggers, produce a complete `:root` block of CSS variables AND the `font-family` rules in the same file. Don't ship half a system. Lock in everything before moving to layout.
