# Font Loading Guide

Loading fonts wrong is one of the fastest ways to make a designed site look amateur — flash of unstyled text, layout shift, slow first paint, blocky fallback.

## The standard Google Fonts setup

For a project using Fraunces (display) + Inter Tight (body):

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,700&family=Inter+Tight:wght@400;500;600&display=swap" rel="stylesheet">
```

Notes on this:
- Always include both preconnects. They cut latency.
- Only load the weights you actually use. Don't grab the full family.
- For variable fonts (Fraunces is one), use the `opsz,wght@` syntax to get the optical size axis.
- `display=swap` shows fallback text immediately, then swaps when the font loads. This is the right choice for most sites.

## Fallback stacks that don't look broken

When the custom font is loading or fails, the fallback shows. A bad fallback (just `serif` or `sans-serif`) means the layout shifts hard when the real font arrives.

Match the fallback to the real font's vibe:

```css
/* For modern sans (Inter, Geist, Söhne, Manrope) */
font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;

/* For warm serif (Fraunces, Cormorant, EB Garamond) */
font-family: 'Fraunces', 'Iowan Old Style', 'Palatino Linotype', Palatino, Georgia, serif;

/* For mono (JetBrains Mono, Geist Mono, IBM Plex Mono) */
font-family: 'JetBrains Mono', 'SF Mono', Menlo, Consolas, monospace;

/* For display serif (Bodoni Moda, Playfair) */
font-family: 'Bodoni Moda', 'Didot', 'Bodoni 72', Garamond, serif;
```

## Variable fonts are usually better

When given the choice, pick the variable font version. One file, every weight. Smaller download, more flexibility. Fraunces, Inter, Geist, Manrope, Cormorant — all available as variable fonts on Google Fonts.

## Self-hosting (when it matters)

For production sites, self-hosting beats Google Fonts CDN. Faster, no third-party request, more control. Use [Fontsource](https://fontsource.org) — they package every Google Font as an npm module:

```bash
npm install @fontsource-variable/fraunces @fontsource-variable/inter-tight
```

```js
import '@fontsource-variable/fraunces';
import '@fontsource-variable/inter-tight';
```

Done. No CDN.

## Premium fonts (paid)

When the project has budget and needs the real thing:

- **Pangram Pangram** (https://pangrampangram.com) — Free for personal use, paid for commercial. PP Editorial New, PP Neue Montreal, PP Neue Machina.
- **Klim Type Foundry** — Tiempos, Söhne, Founders Grotesk. The standard for tech and editorial.
- **Grilli Type** — GT America, GT Sectra, GT Walsheim. Pentagram favorites.
- **Commercial Type** — Graphik. Used by NYT.
- **Display.Type** (Adobe Fonts) — Decent collection if you have Creative Cloud.

For demos and prototypes, always use the free swap noted in the type-and-color SKILL.md. The user can upgrade to paid fonts later without rewriting CSS.

## FOUT vs FOIT decisions

- `font-display: swap` — Fallback shows, then swap. Best for content sites. (Slight layout shift on swap.)
- `font-display: optional` — If font loads in 100ms, use it. Otherwise stick with fallback for this page load. Best for sites where layout stability matters more than the perfect font.
- `font-display: block` — Hide text up to 3s waiting for font, then show. Bad UX usually. Avoid.

Default to `swap`.

## Preventing layout shift

If the custom font and fallback have very different metrics, the page jumps when fonts swap. Two ways to fix:

**1. Use `size-adjust`, `ascent-override`, `descent-override` in `@font-face` rules.** Tools like Fontaine generate these automatically. This makes the fallback text take the same space as the custom font.

**2. For Next.js projects, use `next/font`.** It does this automatically.

```js
import { Fraunces, Inter_Tight } from 'next/font/google';

const fraunces = Fraunces({ subsets: ['latin'], variable: '--font-display' });
const interTight = Inter_Tight({ subsets: ['latin'], variable: '--font-body' });
```

Then in CSS:
```css
font-family: var(--font-display);
```

## Tailwind setup

```js
// tailwind.config.js
module.exports = {
  theme: {
    fontFamily: {
      display: ['Fraunces', 'Iowan Old Style', 'serif'],
      body: ['Inter Tight', '-apple-system', 'sans-serif'],
      mono: ['JetBrains Mono', 'SF Mono', 'monospace'],
    }
  }
}
```

Then use `font-display`, `font-body`, `font-mono` as utility classes.
