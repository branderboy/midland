# Contrast and Accessibility

Most AI-designed pages either over-correct (everything is high-contrast pure black on white, harsh and amateur) or under-correct (#888 gray on #FAFAFA white, pretty but unreadable). Here's the actual rules.

## WCAG minimums (the baseline)

- **Normal text (under 18px):** 4.5:1 contrast ratio
- **Large text (18px+ bold or 24px+):** 3:1 contrast ratio
- **UI components and graphics:** 3:1 against adjacent colors
- **Decorative or disabled:** no minimum but should still be visible

These are the legal/baseline minimums. Aim higher for body text. 7:1 is the AAA standard and a good target for primary text.

## Quick reference: what passes

These primary text pairings hit at least AA (4.5:1):

| Background | Text color | Ratio |
|---|---|---|
| #FFFFFF | #1A1A1A | 17.4 ✓✓ |
| #F5F2EC (cream) | #1A1A1A | 15.5 ✓✓ |
| #FAFAFA | #18181B | 16.6 ✓✓ |
| #08070B (dark) | #FAFAFA | 18.2 ✓✓ |
| #131218 (elevated dark) | #FAFAFA | 16.1 ✓✓ |
| #FFFFFF | #525252 | 7.5 ✓ |
| #FFFFFF | #767676 | 4.5 ✓ (just passes) |
| #FFFFFF | #999999 | 2.8 ✗ FAILS |

## Common mistakes

**1. Tertiary text in #999 or lighter on white.** Fails WCAG. Bump to #767676 minimum, ideally #5C5C5C.

**2. White text on a colored accent button.** Test the contrast. White on #5E6AD2 (Linear purple) is 5.8 — passes. White on #00D4AA (teal) is 2.4 — fails. For light accents, use dark text.

**3. Placeholder text at 50% opacity.** Often fails. Set explicit color instead and check it.

**4. Hover states that drop contrast.** If your link is fine at rest but drops to barely-visible on hover, you've made it worse.

**5. Disabled buttons that you can't tell are buttons.** OK for disabled to be lower contrast, but should still read as a button.

## When to break the rules carefully

Some aesthetic decisions intentionally use lower contrast — luxury brands often run text just above the minimum to feel refined, brutalist sites might use pure black for harshness, editorial sites use slightly muted body for warmth.

When you do this:
- Never go below 4.5:1 for body text
- Make sure interactive elements (buttons, links) hit 4.5:1 minimum
- Consider users in bright sunlight, with imperfect monitors, with mild visual impairments
- If in doubt, give the user a higher-contrast option

## Color blindness

About 8% of men and 0.5% of women have some form of color blindness. The most common (red-green) means red and green look similar.

Rules:
- Don't use color alone to convey meaning. Use icons, labels, or position too.
- Red error states should also have an icon and the word "error."
- Green success should also have a checkmark.
- Charts that rely on color need patterns or labels.

## Testing tools

Built into browsers:
- Chrome DevTools → Rendering tab → "Emulate vision deficiencies"
- Firefox DevTools → Accessibility → Simulate

Online:
- WebAIM Contrast Checker (webaim.org/resources/contrastchecker)
- Coolors contrast checker
- Stark plugin for Figma

## Real values to use

When choosing text colors against a background, these are tested defaults:

**On #FFFFFF:**
- Primary: #18181B (zinc-900) or #0A0A0A
- Secondary: #525252 (neutral-600)
- Tertiary: #767676 (still passes AA)
- Disabled / decorative only: #A1A1AA

**On #F5F2EC (cream):**
- Primary: #1A1A1A
- Secondary: #4A4A4A
- Tertiary: #767676
- Borders: #E5E0D5

**On #08070B (deep dark):**
- Primary: #FAFAFA
- Secondary: #A1A1AA (zinc-400)
- Tertiary: #71717A (zinc-500)
- Borders: #27272A (zinc-800)

**On #131218 (elevated dark):**
- Primary: #FAFAFA
- Secondary: #A1A1AA
- Borders: #3F3F46 (zinc-700)

These are tested. Use them.

## Focus states

Keyboard users need visible focus indicators. The browser default (the blue outline) is fine and you don't need to remove it. If you do customize:

```css
*:focus-visible {
  outline: 2px solid var(--accent);
  outline-offset: 2px;
}
```

`:focus-visible` only shows the outline for keyboard navigation, not mouse clicks. Best of both worlds.

Never `outline: none` without replacing it. That's an accessibility regression.
