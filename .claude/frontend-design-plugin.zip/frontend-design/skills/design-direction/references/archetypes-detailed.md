# Aesthetic Archetypes — Detailed Reference

Each archetype below has: the canonical references, the type system, the color system (with hex values), the spatial logic, and a short CSS starter. Use the Google Fonts swap when the premium font is paid.

---

## 1. Editorial / Magazine

**References:** *NYT Magazine*, *Bloomberg Businessweek*, Pentagram, *Apartamento*, Frank Chimero's site

**Type system:**
- Display: GT Sectra, Tiempos Headline, or **free swap: Fraunces**
- Body: GT America, Söhne, or **free swap: Inter Tight at 16-17px** (Inter is OK ONLY as body, never display)
- Serif accent for pull quotes: Tiempos Text or **free swap: EB Garamond**

**Color:**
```
--bg: #F5F2EC;       /* warm cream, not white */
--ink: #1A1A1A;      /* near-black, not pure */
--accent: #8B1A1A;   /* oxblood OR */
--accent: #1F3A5F;   /* deep navy */
--rule: #1A1A1A;     /* hairlines */
```

**Spatial logic:** 12-column grid but break it constantly. Columns of body text 4-6 wide. Headlines that span 8-12. Pull quotes that intrude into adjacent columns. Hairline rules (1px) separating sections. Drop caps. Footnote-style margins.

**Starter CSS:**
```css
body { background: #F5F2EC; color: #1A1A1A; font-family: 'Inter Tight', sans-serif; font-size: 17px; line-height: 1.6; }
h1 { font-family: 'Fraunces', serif; font-weight: 400; font-size: clamp(48px, 8vw, 128px); line-height: 0.95; letter-spacing: -0.02em; }
.rule { border-top: 1px solid #1A1A1A; }
.dropcap::first-letter { float: left; font-family: 'Fraunces', serif; font-size: 5em; line-height: 0.85; padding-right: 0.1em; }
```

---

## 2. Swiss Modernist

**References:** Müller-Brockmann, Massimo Vignelli, Lars Müller Publishers, the MIT Press logo, Helvetica Now specimen site

**Type system:**
- Single font, three weights max
- Neue Haas Grotesk, Helvetica Now, or **free swap: Inter** (this is the one place Inter is acceptable, used with discipline)
- Or **free swap: Work Sans** for slightly warmer take

**Color:**
```
--bg: #FFFFFF;
--ink: #000000;
--accent: #FF0000;   /* the canonical Swiss red */
/* OR */
--accent: #0033FF;   /* IBM-style blue */
--mute: #767676;
```

**Spatial logic:** A real grid, used religiously. 12 columns with 24px gutters. Type sits on a baseline grid. Whitespace is structural, not decorative. No drop shadows. No rounded corners. No gradients. Ever.

**Starter CSS:**
```css
* { border-radius: 0 !important; }
body { background: #FFF; color: #000; font-family: 'Inter', sans-serif; font-size: 16px; line-height: 24px; /* baseline grid */ }
.grid { display: grid; grid-template-columns: repeat(12, 1fr); gap: 24px; }
h1 { font-weight: 700; font-size: 64px; line-height: 72px; letter-spacing: -0.02em; }
```

---

## 3. Brutalist / Raw Web

**References:** Bloomberg Terminal, Craigslist (intentionally), Drudge Report aesthetic but with taste, Are.na, Yale School of Art site

**Type system:**
- Times New Roman or Courier New (yes, the system fonts — they're free and they slap when used on purpose)
- Or **upgrade swap: Redaction, Newsreader (free), or PP Editorial New**

**Color:**
```
--bg: #FFFFFF or #000000 (pick a side);
--ink: opposite of bg;
--link: #0000EE;     /* the default browser blue, unchanged */
--visited: #551A8B;  /* yes, the default visited purple */
```

**Spatial logic:** Default browser flow. Tables. `<hr>` tags as decoration. Underlined links. No max-widths sometimes. Text wrapping the full window. Hard left-aligned everything. Or wildly absolute-positioned overlapping elements. Pick a lane.

**Starter CSS:**
```css
body { background: #FFF; color: #000; font-family: 'Times New Roman', serif; font-size: 18px; max-width: 100%; padding: 24px; }
a { color: #0000EE; }
a:visited { color: #551A8B; }
hr { border: none; border-top: 2px solid #000; }
h1 { font-size: 72px; font-weight: 400; }
```

---

## 4. Neo-Vintage / Retro-Editorial

**References:** Aesop, Blonded, vintage Penguin Books, Wes Anderson titling, Diptyque

**Type system:**
- Display: GT Super, Caslon, ITC Cheltenham, or **free swap: Cormorant Garamond, Playfair Display (used carefully — Playfair is overused, prefer Cormorant)**
- Body: Tiempos Text or **free swap: Lora**
- Sometimes a tiny all-caps sans for labels: **free: Inter at 11px, 0.15em letter-spacing**

**Color:**
```
--bg: #EFE9DD;       /* aged paper */
--ink: #2C1810;      /* dark sepia, not black */
--accent: #8B0000;   /* oxblood */
--accent2: #B8860B;  /* mustard */
--accent3: #1F3A5F;  /* navy */
```

**Spatial logic:** Centered title pages. Symmetric framing. Hairline borders around blocks. Small caps for labels. Section openers that feel like book chapters. Generous margins.

---

## 5. Soft-Tech / Linear School

**References:** Linear, Vercel, Arc Browser, Raycast, Cron, current Stripe

**Type system:**
- Display: Söhne, GT Walsheim, or **free swap: Geist** (Vercel released this free, perfect for this aesthetic)
- Body: Same family, lighter weight
- Mono for code: **free: Geist Mono or JetBrains Mono**

**Color:**
```
--bg: #08070B;       /* near-black with warmth, not pure black */
--bg-elev: #131218;  /* card backgrounds */
--ink: #FAFAFA;
--mute: #A1A1AA;
--border: #27272A;
--accent: #5E6AD2;   /* Linear's actual purple — this is OK because it's specific, not the slop gradient */
/* OR */
--accent: #00D4AA;   /* Cron-style teal */
--accent: #FF6B35;   /* electric orange for energy */
```

**Spatial logic:** Tight 8px grid. Cards with 1px borders that subtly glow on hover. Subtle radial gradients in the background (NOT diagonal purple-pink). Glassmorphism used sparingly on overlays. Sharp 6-8px border radius, never 16+.

**Starter CSS:**
```css
body { background: #08070B; color: #FAFAFA; font-family: 'Geist', sans-serif; }
.card { background: #131218; border: 1px solid #27272A; border-radius: 8px; transition: border-color 0.2s; }
.card:hover { border-color: #3F3F46; }
.bg-glow { background: radial-gradient(circle at 50% 0%, rgba(94, 106, 210, 0.15), transparent 50%); }
```

---

## 6. Maximalist / Y2K Revival

**References:** MSCHF, early Glossier, Are.na profiles, Telfar, Pleasure Garden

**Type system:**
- Mix 3-4 fonts on purpose
- Display: PP Neue Machina, Druk, or **free swap: Anton, Bebas Neue + Space Grotesk for variety**
- Body: a contrasting choice — **free: Space Mono or DM Mono**
- Decorative: **free: Rubik Mono One, Press Start 2P**

**Color:**
```
--bg: #FFFF00;  /* or hot pink, or lime, commit */
--ink: #000;
--accent1: #FF00FF;
--accent2: #00FFFF;
--accent3: #FF6600;
```

**Spatial logic:** Stickers. Badges. Marquee scrolling text. Rotated elements. GIFs. Low-fi photography. Stamps. Things on top of things. Visible HTML seams.

---

## 7. Luxury / Restrained

**References:** Hermès, Bottega Veneta web, Aesop, Loewe, vintage *Vogue* covers

**Type system:**
- Display: Didot, Bodoni, or **free swap: Bodoni Moda** (much better than Playfair for this)
- Body: a clean transitional serif — **free: Lora or Cormorant**
- Or pair the Didone with a stark sans for tension — **free: Inter Tight at body**

**Color:**
```
--bg: #FAF7F2;       /* ivory, not white */
--ink: #1F1F1F;
--accent: #B8860B;   /* warm metallic — gold */
/* OR */
--accent: #6B4E3D;   /* warm brown */
```

**Spatial logic:** Enormous whitespace. One image per screen. Text-driven. Slow. Photographs at full bleed sometimes. A single product shown like it's the only thing in the world.

---

## 8. Industrial / Utilitarian

**References:** Stripe Press, Linear's docs, *MIT Technology Review*, blueprint drawings

**Type system:**
- Mono throughout for the bold version: **free: JetBrains Mono, IBM Plex Mono**
- Or mono headers + clean sans body: **free: IBM Plex Mono + IBM Plex Sans**

**Color:**
```
--bg: #FAFAFA;
--ink: #18181B;
--accent: #1E40AF;   /* blueprint blue */
--grid: #E4E4E7;     /* visible grid lines */
```

**Spatial logic:** Visible grids. Coordinates and labels. Rulers. Diagrams. Annotated callouts. Feels like reading a technical manual that's actually beautiful.

---

## 9. Organic / Botanical

**References:** Aesop again (different mode), botanical illustrations, *Kinfolk*, Studio Ghibli web pages

**Type system:**
- Display: a humanist serif — **free: Cormorant, EB Garamond**
- Body: same family, regular weight
- Hand element: **free: Caveat or Homemade Apple — used for ONE accent only**

**Color:**
```
--bg: #F4F1EA;       /* linen */
--ink: #3D2817;      /* warm brown */
--sage: #9CAE94;
--terra: #C97B5C;
--mustard: #D4A574;
```

**Spatial logic:** Soft margins. Botanical illustrations as decoration (use SVGs of leaves, branches). Photography of natural textures. Asymmetric but gentle.

---

## 10. Cyberpunk / Terminal

**References:** classic hacker aesthetic but tasteful — Defcon, indie game dev sites, *Hyperdimension*

**Type system:**
- Mono only — **free: JetBrains Mono, Fira Code, IBM Plex Mono, VT323 for true terminal feel**

**Color:**
```
--bg: #0A0A0A;
--ink: #00FF41;      /* terminal green — the iconic one */
/* OR */
--ink: #FFB000;      /* amber */
--accent: #FF0040;   /* danger red */
--mute: #1F1F1F;
```

**Spatial logic:** Scan lines (CSS overlay). ASCII art (real ASCII, not emoji). Terminal prompts. Blinking cursors. Glitch effects on hover, not on load. Grid lines visible.

**Starter CSS:**
```css
body { background: #0A0A0A; color: #00FF41; font-family: 'JetBrains Mono', monospace; }
body::before { content: ''; position: fixed; inset: 0; pointer-events: none; background: repeating-linear-gradient(0deg, rgba(0,255,65,0.03) 0, rgba(0,255,65,0.03) 1px, transparent 1px, transparent 3px); z-index: 1; }
.cursor::after { content: '▊'; animation: blink 1s steps(2) infinite; }
@keyframes blink { 50% { opacity: 0; } }
```

---

## 11. Soft-Pastel / Gen-Z

**References:** early Glossier, Notion marketing, friend.com, Posthog's marketing pages

**Type system:**
- Display: a friendly sans — **free: Cabinet Grotesk, Outfit, or Geist**
- Body: same
- Sometimes a hand element: **free: Caveat used sparingly**

**Color (NOT purple-pink — those are slop):**
```
--bg: #FFE8D6;       /* peach */
--ink: #2D2A26;
--accent1: #B5D6A7;  /* sage */
--accent2: #FFD3B6;  /* apricot */
--accent3: #6B4226;  /* coffee */
/* alt palette */
--bg: #FFF8E7;       /* butter */
--accent: #F4978E;   /* coral */
```

**Spatial logic:** Rounded but with personality (24px corners, not 8px). Blob shapes (use SVG). Slight tilts on cards (-2deg, +1.5deg). Friendly motion (bouncy springs). Big buttons.

---

## 12. Mono / Anti-Brand

**References:** A24, Off-White web, Issey Miyake, Acne Studios

**Type system:**
- ONE font, three weights
- Often a quirky one used at scale — **free: Fraunces, Cabinet Grotesk, or Migra**

**Color:**
```
--bg: #FFFFFF or #000000;
--ink: opposite;
--accent: #FF3B30;   /* one tiny accent only, used 2x max per screen */
```

**Spatial logic:** Type as the entire design. Photography in 4:5 ratio only. Massive scale changes — 12px label next to 240px headline. Confidence through restraint.

---

## How to use this reference

When the user picks an archetype (or you pick for them), copy the type system, color system, and starter CSS for that archetype directly. Don't mix archetypes. Don't try to be clever. The constraint is the design.
