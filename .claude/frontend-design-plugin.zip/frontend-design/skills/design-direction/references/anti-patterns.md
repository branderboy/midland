# Anti-Patterns: The AI Slop Moves to Never Make

These are the specific reflexes that mark a frontend as AI-generated. Each one has a reason it happens (so you can catch yourself doing it) and what to do instead.

## Typography slop

**1. Inter for headlines.** Inter is a fine body font. As a headline, it screams "I asked ChatGPT for a SaaS landing page in 2024." Use a display font with personality. Fraunces, Cabinet Grotesk, Geist, Cormorant, even Times New Roman if the aesthetic is right.

**2. System-ui as a fallback that becomes the actual choice.** `font-family: system-ui` ships you Segoe UI on Windows, San Francisco on Mac, Roboto on Android. Three different fonts. Pick one and load it.

**3. Three weights of the same font and that's the whole system.** Real type systems have a display + body pairing, plus maybe a mono. Or one font used at extreme scale ranges (12px to 200px). Three weights of one sans is the lazy default.

**4. Uniform letter-spacing.** Headlines need negative letter-spacing (-0.02em or tighter). Small caps need positive (0.1em+). Body needs zero. If everything is at 0 you're not designing.

**5. line-height: 1.5 everywhere.** Display text wants line-height: 0.95 to 1.05. Body wants 1.5 to 1.65. Captions want 1.3. Be specific.

## Color slop

**6. Purple-to-pink gradient hero backgrounds.** This is the canonical AI move. If you're reaching for a gradient, ask: is this a Linear-style subtle radial glow (OK) or am I about to ship a bisexual lighting hero (slop)? When in doubt, no gradient.

**7. Blue-to-purple gradient anything.** Same family. Stop.

**8. The neutral gray shade #F4F4F5.** Tailwind's slate-100. The default "elevated card on white" background. If you use it, change it. #F5F2EC (warm cream) or #FAFAFA (cool) or just don't use a card background at all.

**9. Pure black (#000000) on pure white (#FFFFFF).** Real designers use #1A1A1A or #18181B or #2C1810 on a slightly off-white. Pure black on pure white is harsh and screams default.

**10. Five accent colors of equal weight.** Pick ONE accent. Maybe two if the second is for warnings/errors. A rainbow palette is what you do when you can't commit. Commit.

**11. Neon-saturated greens and pinks because the user said "make it pop."** Saturation is not the same as boldness. A deep oxblood pops more than #FF00FF in the right context.

## Layout slop

**12. The centered hero stack.** H1 → subtitle → two CTAs (one filled, one outline) → all centered → 80vh tall. If your hero has this shape, your hero is generic. Even shifting it left, or making it asymmetric, or letting one element bleed off-canvas changes everything.

**13. Three feature cards in a row, each with: icon at top → bold title → 2 lines of body → "Learn more" link.** This is the most-cloned pattern in web design. Either skip the cards entirely (use a list, a table, a story format) or break the symmetry — different sizes, different positions, one card overlapping another.

**14. "Trusted by" logo bar in muted gray below the hero.** Boring AND it looks like a stock photo. If you must show logos, do something with them — a marquee, a grid that forms a shape, integrated into a sentence ("Companies like X, Y, and Z").

**15. FAQ accordion at the bottom.** Fine, FAQs need to exist, but the default `<details>` behavior with a chevron is the lowest-effort version. Try a different format: numbered list with full answers visible, two-column Q&A grid, conversation transcript style.

**16. Footer with 4 columns: Product / Company / Resources / Legal.** Yes you need a footer. No it doesn't need to look like every other one. A footer can be a single line. Or one giant logo. Or a sitemap rendered as a poem.

**17. Centered everything.** When in doubt, AI centers. Real designers offset. Try: heading left-aligned, image right-aligned, text in a 6-column block starting at column 3. Asymmetry creates visual interest.

**18. Equal spacing between every section.** Real layouts have rhythm — sections have different vertical heights, different breathing room. 96px → 240px → 64px → 320px feels designed. 120px → 120px → 120px feels generated.

## Component slop

**19. Rounded corners everywhere at the same radius.** If everything is `rounded-lg`, nothing is. Vary: cards 8px, buttons 4px, images 0px (or 24px if the aesthetic calls for it). Or commit to all sharp corners. Or all giant radii.

**20. Soft drop shadows on every floating thing.** The "card lifted off the page" reflex. Real designers use shadow surgically — usually for one or two elements per screen, often with sharper edges or colored shadows.

**21. Lucide icons used as decoration.** Lucide is great for functional icons (close button, arrow, menu). Using a "Sparkles" icon next to a feature title is filler. Either find better imagery or skip it.

**22. Buttons that say "Get Started" or "Learn More."** Generic CTA copy is its own design failure. The button text should say what specifically happens.

**23. Placeholder text that's clearly Lorem Ipsum or "Heading goes here."** Every page should ship with real-feeling content even if it's invented for the demo. Generic placeholder content makes generic-looking design.

## Motion slop

**24. fadeInUp on every element with staggered delays of 0.1s.** This is the Framer Motion default that everyone uses. Either commit to one bigger choreographed reveal (one element does something dramatic) or don't animate page-load at all.

**25. Hover states that just change opacity to 0.8.** Real hover states are choices — color shifts, border changes, position nudges, icon swaps, underline reveals. Opacity changes are placeholder.

**26. Scroll-triggered reveals on every section.** If everything fades in on scroll, nothing does. Pick the one or two moments that deserve it.

**27. Button hover that adds a slight scale (1.05) and shadow.** Tailwind's default hover. Try: invert the colors, change the border, slide an underline in, swap the text.

## Background / detail slop

**28. Solid color backgrounds with no texture, no depth, nothing.** Even a tiny noise texture (SVG or 0.02 opacity) adds grit. Even a 1px hairline rule adds structure.

**29. The same screenshot/dashboard mockup that every SaaS uses.** A vague tilted dashboard with charts. If you're making a hero illustration, make something specific to the actual product.

**30. Stock-feeling photography or illustration.** If you can't get real photos, lean into typography + abstract shapes. Don't use a generic stock image and call it design.

## The detection test

After drafting, look at the page and ask: **could this be for any product?** If yes, you didn't design it for a specific product, you generated a frontend template. Add specificity: real headlines, real product details, choices that only make sense for this brand.

Generic = slop. Specific = designed.
