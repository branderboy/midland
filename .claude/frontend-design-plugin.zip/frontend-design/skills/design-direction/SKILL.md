---
name: design-direction
description: Use this skill at the START of any frontend build before writing a single line of code. Triggers on requests to build websites, landing pages, web apps, dashboards, marketing sites, portfolios, React components, HTML/CSS pages, or any web UI. Forces commitment to a specific aesthetic direction with named designer references, locked typography, and a real color system, instead of defaulting to AI slop (Inter on white with purple gradients, centered hero cards, generic everything). Also use whenever the user asks to "redesign," "make it look better," "make it feel premium," "less generic," or "more designed." This skill runs FIRST and the others (layout-composition, type-and-color, motion-and-detail) build on the direction it locks in.
---

# Design Direction

Most AI-generated frontends look the same because the AI never makes a real choice. It defaults to safe, average, generic. This skill forces a specific choice before any code gets written.

## The non-negotiable rule

Before you write any HTML, JSX, or CSS, you write a **Design Brief** in 5 lines. This is not optional. If the user pushes back on doing it, do it silently in your head but still do it.

```
AESTHETIC: [pick ONE from the archetypes below, name it]
REFERENCE: [name a real designer, studio, or product whose work this echoes]
TYPE PAIR: [display font + body font, both NAMED, neither is Inter/Roboto/Arial]
COLOR MOVE: [one dominant + one accent + neutrals, with hex values]
SIGNATURE DETAIL: [the one specific thing that makes this memorable]
```

Then build. The brief is the contract. Every styling decision after this either supports the brief or gets cut.

## Why this works

Generic AI design happens because the model tries to please everyone, so it averages. A real designer doesn't average. They commit. "This is a brutalist site for a record label" is a decision that closes off 90% of choices and that's the point. The constraints make the work.

## The 12 aesthetic archetypes

Pick one. Don't blend. Blending is how you end up with mush.

**1. Editorial / Magazine** — Think *The New York Times Magazine*, *Bloomberg Businessweek*, Pentagram. Heavy serif headlines, ragged left columns, oversized photography, hairline rules, asymmetric grids, footnotes, pull quotes. Feels read, not scrolled.

**2. Swiss Modernist** — Think Müller-Brockmann, Helvetica Now, Lars Müller Publishers. Strict grid, sans-serif only, generous whitespace, near-monochrome with one accent, mathematical rhythm, almost no decoration. Restraint as the point.

**3. Brutalist / Raw Web** — Think Bloomberg's old terminal, Kanye's Donda site, early Craigslist energy but intentional. Default browser styling weaponized, system fonts (but the GOOD ones — Times New Roman, Courier), exposed seams, harsh contrast, no rounded corners, ugly on purpose in a way that becomes beautiful.

**4. Neo-Vintage / Retro-Editorial** — Think Aesop, Frank Ocean's *Blonded* site, vintage Penguin paperbacks. Warm off-whites, oxblood, navy, mustard. Old-style serifs (Caslon, Garamond), letterpress textures, art deco geometric accents.

**5. Soft-Tech / Linear School** — Think Linear, Vercel, Arc Browser, Raycast. Dark backgrounds with subtle gradients (NOT purple), precise sans-serifs, glass morphism done well, sharp 1px borders that glow, motion that feels like physics, cool grays with one electric accent.

**6. Maximalist / Y2K Revival** — Think MSCHF, Telfar, Glossier's chaotic phase. Saturated color, stickers, badges, marquee scrolls, mixed typefaces, deliberate clutter, GIFs, low-fi imagery, asymmetry from chaos not from rules.

**7. Luxury / Restrained** — Think Hermès, Aesop, Bottega Veneta web. Ivory + black + one warm metallic. Didone serifs (Bodoni, Didot), enormous whitespace, slow motion, very few words on screen, photography over illustration.

**8. Industrial / Utilitarian** — Think Stripe Press, Linear's docs, technical manuals. Mono fonts, blueprint blue or graphite, dense data, schematics, system-level precision, feels like a technical document.

**9. Organic / Botanical** — Think Studio Ghibli sites, herbal brands, slow-living publications. Sage, terracotta, cream. Soft serifs, hand-drawn elements, natural photography, textures that feel like paper or linen.

**10. Cyberpunk / Terminal** — Think Hyperdimension, indie game devs, hacker aesthetic but tasteful. Black backgrounds, monospace everything, terminal greens or amber, scan lines, ASCII art, glitch effects used surgically.

**11. Soft-Pastel / Gen-Z** — Think Glossier early, Notion's marketing, friend.com. Pastels (NOT purple-blue gradients — think peach, butter, mint), rounded everything but with personality, playful sans-serifs, blob shapes, friendly motion.

**12. Mono / Anti-Brand** — Think A24, Off-White's web, Issey Miyake. Black and white with one tiny accent, one font in three weights, all type-driven, photography in 4:5 only, restraint that signals confidence.

## What "AI slop" looks like (don't do these)

- Inter, Roboto, or system-ui for headlines
- Purple-to-pink or blue-to-purple gradient backgrounds
- A centered hero with a tagline and two buttons (one filled, one outline)
- Three feature cards in a row with rounded corners and small icons at the top
- "Trusted by" logo bar in muted gray
- FAQ accordion at the bottom
- Pastel everything with no contrast
- That specific shade of neutral gray (#F4F4F5) as a background everywhere
- Soft drop shadows on everything (the "floating card" reflex)
- Lucide icons used as decoration instead of as function

If your draft has 3+ of these, scrap it and start over with a real direction.

## How to pick the archetype

Read the user's request and ask:

1. **What's the actual product?** A record label site is not a SaaS dashboard. A wedding photographer is not a developer tool. Match the archetype to the soul of the thing, not to web conventions.

2. **Who is the audience?** Designers and creatives reward boldness. Enterprise buyers reward precision. Consumers reward warmth or play.

3. **What's the era?** Some products are timeless (Editorial, Swiss). Some are of-the-moment (Soft-Tech, Y2K Revival). Pick on purpose.

4. **What does the user already imply?** "Make it feel premium" → Luxury or Editorial. "Make it feel like Linear" → Soft-Tech. "Make it weird" → Brutalist or Maximalist. Listen to the words they used.

When in doubt between two archetypes, pick the more specific one. Specificity > safety.

## After the brief, hand off to the other skills

Once the Design Brief is locked, the other three skills know what to do:

- **type-and-color** uses your TYPE PAIR and COLOR MOVE to build the token system
- **layout-composition** uses your AESTHETIC to pick a layout archetype that matches
- **motion-and-detail** uses your SIGNATURE DETAIL to know where to spend the motion budget

Read those skills' SKILL.md files when you reach those phases of the build. Don't try to remember everything from this skill; offload the specifics to them.

## Reference files

For deeper guidance on specific aesthetics:

- `references/archetypes-detailed.md` — Full breakdown of each of the 12 archetypes with code starter snippets, Google Fonts substitutes for premium fonts, and color hex values per archetype. Read this when the user picks an archetype and you need the specifics.
- `references/anti-patterns.md` — A long list of the specific AI-slop moves to avoid, with why they happen and what to do instead. Read this if you catch yourself defaulting to safe choices.

## Output format

After producing the Design Brief, briefly tell the user the direction in one sentence (e.g. "Going Editorial / Magazine on this — heavy serif headlines, ragged columns, oxblood accent on cream") then build. Don't lecture them about the brief. They want the site, not the syllabus.
