---
name: layout-composition
description: Use this skill when laying out any web page or component. Triggers on requests to build a hero, landing page, marketing page, portfolio, dashboard, blog, or any multi-section layout. Also triggers when the user says "the layout feels boring," "everything is centered," "it looks like a template," "needs more visual interest," "make the layout more interesting," or shows a draft that has the standard centered-hero / three-cards / FAQ-accordion structure. This skill provides specific layout archetypes with code patterns for hero sections, content blocks, and full pages, drawn from real designer playbooks (asymmetric grids, broken alignment, oversized type, intentional whitespace, magazine layouts), to replace the AI default of centered cards on white.
---

# Layout Composition

The fastest way to make a frontend look AI-generated is to center everything and stack three rounded cards. The fastest way to make it look designed is to break the symmetry on purpose. This skill provides the patterns to do that.

## The mindset shift

Before this skill: "What components do I need? Hero, features, testimonials, CTA, footer."

After this skill: "What does the eye do on this page? Where does it land first? Where does it travel? What's the rhythm? What's unexpected?"

Layout is choreography. The reader's eye is the dancer. You're the choreographer.

## The 8 layout archetypes

Each archetype is a complete layout system. Pick one. Stick with it across the page.

### 1. The Editorial Spread

**What it looks like:** Magazine page energy. Columns of running text. Hairline rules. Pull quotes that span columns. Footnote-style captions in margins. Drop caps. Photography sized like a magazine, not a card.

**When to use:** Editorial brands, longform content, premium positioning, anything wanting "thoughtful" or "considered."

**The code pattern:**
```html
<article class="editorial">
  <header class="editorial-header">
    <p class="kicker">DISPATCH NO. 04 — NOVEMBER 2025</p>
    <h1>The Last Days of the Open Web</h1>
    <p class="standfirst">Three reporters spend six weeks inside the protocols, the parlors, and the parties trying to save what's left.</p>
    <div class="byline">By <strong>Anna Lloyd</strong> · 24 min read</div>
  </header>

  <div class="editorial-body">
    <p class="dropcap">In the basement of a Brooklyn warehouse, twenty engineers...</p>
    <hr class="rule" />
    <blockquote class="pullquote">
      "We didn't build the web for this. The web was built for joy."
    </blockquote>
    <p>The conversation continued well past midnight...</p>
  </div>
</article>
```

```css
.editorial { max-width: 1280px; margin: 0 auto; padding: 96px 32px; }
.editorial-header { display: grid; grid-template-columns: repeat(12, 1fr); gap: 24px; margin-bottom: 96px; }
.kicker { grid-column: 1 / 4; font-size: 12px; letter-spacing: 0.2em; text-transform: uppercase; }
h1 { grid-column: 4 / 13; font-family: 'Fraunces', serif; font-size: clamp(48px, 8vw, 128px); line-height: 0.95; letter-spacing: -0.02em; margin: 0; }
.standfirst { grid-column: 4 / 11; font-size: 24px; line-height: 1.3; margin-top: 32px; }
.byline { grid-column: 4 / 13; margin-top: 48px; padding-top: 16px; border-top: 1px solid currentColor; font-size: 14px; }
.editorial-body { display: grid; grid-template-columns: repeat(12, 1fr); gap: 24px; }
.editorial-body p { grid-column: 4 / 10; font-size: 18px; line-height: 1.65; }
.editorial-body p:first-of-type { font-size: 20px; }
.pullquote { grid-column: 2 / 8; font-family: 'Fraunces', serif; font-size: 36px; line-height: 1.2; font-style: italic; padding: 48px 0; }
.dropcap::first-letter { float: left; font-family: 'Fraunces', serif; font-size: 5em; line-height: 0.85; padding: 0.05em 0.1em 0 0; }
.rule { grid-column: 1 / 13; border: none; border-top: 1px solid currentColor; margin: 64px 0; }
```

### 2. The Asymmetric Hero

**What it looks like:** Headline anchored to the left, oversized, sometimes bleeding off-canvas. Supporting content in a narrow column to the right. Big negative space below. No centered subtitle stack.

**When to use:** Modern brands, portfolios, anything that wants to feel current and confident.

**The code pattern:**
```html
<section class="hero-asymmetric">
  <div class="hero-meta">
    <span class="hero-num">01 / 04</span>
    <span class="hero-loc">Washington DC</span>
  </div>
  <h1 class="hero-title">
    Build websites<br/>
    that don't<br/>
    <em>look like</em><br/>
    websites.
  </h1>
  <div class="hero-side">
    <p>TaggleFish makes contractor marketing systems that actually convert. Lead capture, follow-up, growth tools.</p>
    <a href="#" class="hero-cta">See the work →</a>
  </div>
</section>
```

```css
.hero-asymmetric { min-height: 100vh; padding: 32px; display: grid; grid-template-columns: repeat(12, 1fr); grid-template-rows: auto 1fr auto; gap: 24px; }
.hero-meta { grid-column: 1 / 13; display: flex; justify-content: space-between; font-size: 12px; letter-spacing: 0.2em; text-transform: uppercase; }
.hero-title { grid-column: 1 / 11; align-self: end; font-family: 'Fraunces', serif; font-weight: 400; font-size: clamp(64px, 14vw, 240px); line-height: 0.92; letter-spacing: -0.04em; margin: 0; }
.hero-title em { font-style: italic; color: var(--accent); }
.hero-side { grid-column: 9 / 13; align-self: end; padding-bottom: 32px; }
.hero-side p { font-size: 16px; line-height: 1.5; max-width: 32ch; }
.hero-cta { display: inline-block; margin-top: 24px; padding: 16px 0; border-bottom: 1px solid currentColor; }
```

### 3. The Swiss Grid

**What it looks like:** Strict 12-column grid. Everything snaps. Generous whitespace. Type as the primary visual. One accent color, used twice per screen. Mathematical rhythm.

**When to use:** Tech docs, manifestos, brands wanting precision and seriousness.

**The code pattern:**
```html
<section class="swiss">
  <div class="swiss-num">01</div>
  <h2 class="swiss-h2">Principles</h2>
  <div class="swiss-content">
    <p>The work begins with constraint. Every project we take on is the result of saying no to nine others.</p>
  </div>
  <div class="swiss-rule"></div>
</section>
```

```css
.swiss { display: grid; grid-template-columns: repeat(12, 1fr); gap: 24px; padding: 96px 48px; }
.swiss-num { grid-column: 1 / 2; font-size: 14px; font-feature-settings: 'tnum'; }
.swiss-h2 { grid-column: 2 / 6; font-size: 14px; text-transform: uppercase; letter-spacing: 0.1em; margin: 0; }
.swiss-content { grid-column: 7 / 12; }
.swiss-content p { font-size: 32px; line-height: 1.3; margin: 0; }
.swiss-rule { grid-column: 1 / 13; border-top: 1px solid currentColor; margin-top: 96px; }
```

### 4. The Brutalist Stack

**What it looks like:** Hard left-aligned. Default fonts. Underlined links. Tables for data. Visible HTML structure. Sometimes single-column running text full-width like a Word document.

**When to use:** Indie brands, art projects, anything anti-corporate, manifesto sites.

**The code pattern:**
```html
<main class="brutalist">
  <h1>NOTES ON DESIGN, 2026</h1>
  <p>An ongoing list. Updated November 2026. Send corrections to anna@example.com.</p>
  <hr/>
  <ol>
    <li><a href="#a">If you can write the brief in one sentence, the design will be better.</a></li>
    <li><a href="#b">Every "trusted by" logo bar is a confession.</a></li>
    <li><a href="#c">Centered is a default, not a decision.</a></li>
  </ol>
  <hr/>
  <h2>1. If you can write the brief in one sentence...</h2>
  <p>The fastest way to make work that feels like nothing is to start without committing to anything in particular...</p>
</main>
```

```css
.brutalist { font-family: 'Times New Roman', serif; font-size: 18px; line-height: 1.5; padding: 24px; max-width: 100%; }
.brutalist h1 { font-size: 48px; font-weight: 400; margin: 0 0 16px; }
.brutalist h2 { font-size: 28px; font-weight: 400; margin: 48px 0 16px; }
.brutalist a { color: #0000EE; }
.brutalist a:visited { color: #551A8B; }
.brutalist hr { border: none; border-top: 2px solid currentColor; margin: 24px 0; }
.brutalist ol { padding-left: 24px; }
.brutalist li { margin-bottom: 8px; }
```

### 5. The Bento Grid

**What it looks like:** Apple-style bento boxes. Cards of varying sizes packed together like a Japanese lunch box. Each cell has its own purpose. Used well, it's structured but lively. Used badly, it's just chaos.

**When to use:** Feature showcases, dashboards, portfolios with multiple project tiles.

**The code pattern:**
```html
<section class="bento">
  <div class="bento-cell bento-large">
    <h3>Lead capture</h3>
    <p>Smart forms that convert 3x baseline.</p>
  </div>
  <div class="bento-cell bento-tall">
    <h3>Follow-up automation</h3>
  </div>
  <div class="bento-cell">
    <h3>Reviews</h3>
  </div>
  <div class="bento-cell bento-wide">
    <h3>SMS + email sequences</h3>
  </div>
  <div class="bento-cell">
    <h3>GMB sync</h3>
  </div>
</section>
```

```css
.bento { display: grid; grid-template-columns: repeat(4, 1fr); grid-auto-rows: 200px; gap: 16px; padding: 48px; }
.bento-cell { background: var(--bg-elev); border: 1px solid var(--border); border-radius: 8px; padding: 32px; }
.bento-large { grid-column: span 2; grid-row: span 2; }
.bento-tall { grid-row: span 2; }
.bento-wide { grid-column: span 2; }
```

Critical: vary the cell sizes meaningfully. If every cell is the same size you've made a regular grid, not a bento.

### 6. The Vertical Magazine

**What it looks like:** Single column, narrow (max-width 720px or so), but with full-bleed images breaking out, oversized pull quotes, photo captions in margins. Substack-meets-magazine.

**When to use:** Newsletters, longform articles, personal sites, Crowd Goes Wild-style content.

**The code pattern:**
```html
<article class="vmag">
  <h1>Why every label sounds the same in 2026</h1>
  <p class="vmag-meta">Kay · 12 min · November 2026</p>
  <p>The first track on the album doesn't have drums...</p>
  <figure class="vmag-bleed">
    <img src="..." alt=""/>
    <figcaption>The studio in Hyattsville, 3am.</figcaption>
  </figure>
  <p>Three years ago, this would have been a problem...</p>
  <blockquote class="vmag-pull">
    The producers who used to lead are now chasing.
  </blockquote>
</article>
```

```css
.vmag { max-width: 720px; margin: 0 auto; padding: 96px 24px; font-size: 19px; line-height: 1.65; }
.vmag h1 { font-family: 'Fraunces', serif; font-size: 56px; line-height: 1.05; margin: 0 0 16px; }
.vmag-meta { font-size: 14px; color: var(--ink-mute); margin-bottom: 48px; }
.vmag-bleed { margin: 64px calc(-50vw + 50%); /* breaks out of the column */ }
.vmag-bleed img { width: 100%; height: auto; }
.vmag-bleed figcaption { max-width: 720px; margin: 12px auto 0; font-size: 14px; color: var(--ink-mute); padding: 0 24px; }
.vmag-pull { font-family: 'Fraunces', serif; font-size: 36px; line-height: 1.2; font-style: italic; margin: 64px -32px; padding: 0 32px; border-left: 2px solid var(--accent); }
```

### 7. The Dashboard Density

**What it looks like:** High-density information. Tables, lists, multi-column data. Inspired by Linear, Stripe Press, terminal apps. Generous use of mono for figures. Tight spacing.

**When to use:** Tools, internal apps, anything for technical users.

**The code pattern:**
```html
<div class="dash">
  <header class="dash-top">
    <div>
      <p class="dash-eyebrow">Q4 2026</p>
      <h2>Revenue overview</h2>
    </div>
    <nav class="dash-nav">
      <a class="dash-nav-active">All</a>
      <a>Pipeline</a>
      <a>Closed</a>
    </nav>
  </header>
  <table class="dash-table">
    <thead>
      <tr><th>Project</th><th>Client</th><th class="num">Value</th><th class="num">Status</th></tr>
    </thead>
    <tbody>
      <tr><td>Capital One Bowie</td><td>D. Proctor</td><td class="num">$24,800</td><td class="num"><span class="dot ok"></span> Won</td></tr>
      <tr><td>Saks Tysons</td><td>D. Proctor</td><td class="num">$18,200</td><td class="num"><span class="dot pending"></span> Pending</td></tr>
    </tbody>
  </table>
</div>
```

```css
.dash { padding: 32px; }
.dash-top { display: flex; justify-content: space-between; align-items: end; padding-bottom: 24px; border-bottom: 1px solid var(--border); margin-bottom: 24px; }
.dash-eyebrow { font-size: 12px; letter-spacing: 0.1em; text-transform: uppercase; color: var(--ink-mute); margin: 0; }
.dash h2 { font-size: 28px; margin: 4px 0 0; }
.dash-nav { display: flex; gap: 16px; font-size: 14px; }
.dash-nav-active { font-weight: 500; }
.dash-nav a:not(.dash-nav-active) { color: var(--ink-mute); }
.dash-table { width: 100%; border-collapse: collapse; font-size: 14px; }
.dash-table th { text-align: left; padding: 12px 16px; font-weight: 500; color: var(--ink-mute); border-bottom: 1px solid var(--border); font-size: 12px; letter-spacing: 0.05em; text-transform: uppercase; }
.dash-table td { padding: 16px; border-bottom: 1px solid var(--border); }
.dash-table .num { font-family: 'JetBrains Mono', monospace; font-feature-settings: 'tnum'; text-align: right; }
.dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 8px; vertical-align: middle; }
.dot.ok { background: #00B82F; }
.dot.pending { background: #FFB000; }
```

### 8. The Off-Canvas

**What it looks like:** Elements that intentionally extend beyond the viewport. Headlines that bleed off the right edge. Images cropped by the window. Numbers that exit the screen. Used carefully, this signals confidence and scale.

**When to use:** Bold brand sites, portfolios, when you want to feel cinematic.

**The code pattern:**
```html
<section class="offcanvas">
  <h1 class="offcanvas-h1">EXTRAORDINARY<br/>WORK</h1>
  <p class="offcanvas-text">A small studio in Washington DC making large work for clients who care about every pixel.</p>
</section>
```

```css
.offcanvas { position: relative; min-height: 80vh; overflow: hidden; padding: 96px 0; }
.offcanvas-h1 { font-family: 'Fraunces', serif; font-weight: 700; font-size: clamp(120px, 22vw, 360px); line-height: 0.85; letter-spacing: -0.05em; margin: 0; padding-left: 32px; transform: translateX(-2%); /* bleeds slightly left */ white-space: nowrap; /* wide enough to bleed right */ }
.offcanvas-text { max-width: 480px; margin: 64px 32px 0 auto; padding-right: 32px; font-size: 20px; line-height: 1.5; text-align: right; }
```

## Rules that apply across all archetypes

**1. Vertical rhythm.** Sections shouldn't all have the same height. Mix 320px, 640px, 96px sections deliberately. Variable rhythm = designed. Equal rhythm = generated.

**2. The 12-column grid is your friend, but break it.** Set up the grid, then deliberately span weird ranges. `grid-column: 3 / 9` is more interesting than `grid-column: 1 / 13` for everything.

**3. One hero treatment per page.** The hero sets the tone. Don't make every section feel like another hero. Subsequent sections should feel like supporting players.

**4. Use clamp() for type that scales.** `font-size: clamp(48px, 8vw, 128px)` — minimum, preferred, maximum. Type stays beautiful at every viewport.

**5. Negative space is a design element.** A section with just one sentence and 320px of whitespace below it tells the reader "this matters." Equal spacing tells them "we filled the space."

## Hero variations cheat sheet

When the user asks for a hero, AVOID:
- Centered H1 + subtitle + two buttons
- Anything that fills exactly 80vh
- Background gradient with vague CTA over it

Try INSTEAD (paired with the right archetype):
- Asymmetric: Big left-anchored headline, content in narrow right column
- Editorial: Kicker label + huge serif headline + standfirst paragraph + byline + image at bottom
- Swiss: Tiny number "01" + medium label + huge type as the only thing on screen
- Brutalist: H1 then immediately content, no spacing tricks
- Off-canvas: Headline bleeds beyond viewport, only readable by horizontal flow
- Type-only: Headline so large it IS the design, no other elements above the fold
- Image-led: Full-bleed photograph, type small in corner

## Reference files

- `references/section-patterns.md` — Specific code patterns for testimonials, FAQ, pricing tables, footers, all reimagined to escape the AI defaults. Read when building those specific sections.
- `references/grid-systems.md` — How to set up real grid systems with CSS Grid, including baseline grids, modular scales, and how to break the grid intentionally. Read when starting any new layout.

## Output

When this skill triggers, pick ONE archetype based on the design direction already chosen. Don't blend archetypes. Generate the full layout in the chosen pattern. If the user asks for a feature that doesn't fit the chosen archetype, force-fit it to the archetype rather than abandoning the consistency.
