# Section Patterns That Aren't Generic

The standard SaaS page is: Hero → Logos → Features (3 cards) → Testimonial → Pricing → FAQ → CTA → Footer. Every section in that list has a generic version and a designed version. Here's the designed versions.

## Testimonials (instead of three quote cards)

**Generic:** Three cards in a row, each with a customer photo, quote, name, title.

**Designed alternatives:**

### Pattern A: Single huge quote, treated like editorial
```html
<section class="testimonial-editorial">
  <blockquote>
    "We replaced our entire marketing stack with this. Six months later, our pipeline is double and our team spends zero hours per week on lead chasing."
  </blockquote>
  <footer>
    <strong>Maya Chen</strong>, VP Operations at Capstone Construction
  </footer>
</section>
```
```css
.testimonial-editorial { max-width: 1200px; margin: 0 auto; padding: 160px 32px; }
.testimonial-editorial blockquote { font-family: 'Fraunces', serif; font-size: clamp(36px, 5vw, 72px); line-height: 1.15; letter-spacing: -0.02em; margin: 0; quotes: '"' '"' "'" "'"; }
.testimonial-editorial blockquote::before { content: open-quote; }
.testimonial-editorial blockquote::after { content: close-quote; }
.testimonial-editorial footer { margin-top: 48px; padding-top: 24px; border-top: 1px solid currentColor; font-size: 14px; max-width: 320px; }
```

### Pattern B: Marquee scroll of short quotes
Scrolling horizontally infinitely, short quotes, names underneath. Feels alive without being busy.

### Pattern C: List of full reviews, like Are.na
Numbered list, each review takes its own row, full quote, no truncation, no card chrome.

```html
<ol class="testimonial-list">
  <li>
    <span class="num">01</span>
    <p>The first project paid for the entire year of subscription. Then the second one happened a week later.</p>
    <span class="who">Diego Velasco · Velasco Drywall, MD</span>
  </li>
  <li>
    <span class="num">02</span>
    <p>I stopped sending PDF estimates. Win rate went from like 40% to over 70% just because the proposals look like a real company sent them.</p>
    <span class="who">Anna Park · Park Construction</span>
  </li>
</ol>
```

```css
.testimonial-list { list-style: none; padding: 0; max-width: 800px; margin: 0 auto; }
.testimonial-list li { display: grid; grid-template-columns: 48px 1fr; gap: 24px; padding: 32px 0; border-bottom: 1px solid var(--border); }
.testimonial-list li:last-child { border-bottom: none; }
.num { font-family: 'JetBrains Mono', monospace; font-size: 12px; padding-top: 8px; color: var(--ink-mute); }
.testimonial-list p { margin: 0; font-size: 22px; line-height: 1.4; }
.who { font-size: 13px; color: var(--ink-mute); margin-top: 12px; display: block; }
```

### Pattern D: One quote, one giant photo
Full-bleed photo of the customer with quote overlaid in the corner. Cinematic.

## FAQ (instead of accordion list)

**Generic:** Accordion with chevrons that expand on click.

**Designed alternatives:**

### Pattern A: Just show all the answers
For 5-8 questions, expanded list with full answers visible. Q in serif, A in sans, hairline rules between.

```html
<section class="faq-open">
  <h2>Common questions</h2>
  <dl>
    <dt>Do you take retainer clients?</dt>
    <dd>Yes, but only after a project. We don't start with retainers because they incentivize the wrong things.</dd>
    <dt>What does the process look like?</dt>
    <dd>Two-week discovery, four to eight weeks of build, two weeks of refinement after launch. We don't do anything faster, and rarely anything slower.</dd>
  </dl>
</section>
```

```css
.faq-open { max-width: 800px; margin: 0 auto; padding: 96px 32px; }
.faq-open dl { margin: 48px 0 0; }
.faq-open dt { font-family: 'Fraunces', serif; font-size: 28px; line-height: 1.2; margin-top: 48px; padding-top: 48px; border-top: 1px solid var(--border); }
.faq-open dt:first-child { padding-top: 0; border-top: none; }
.faq-open dd { font-size: 17px; line-height: 1.6; margin: 16px 0 0; max-width: 560px; }
```

### Pattern B: Two-column Q&A grid
Questions on the left, answers on the right. Like a printed FAQ document.

### Pattern C: Conversation-style
Looks like a transcript. "Q:" and "A:" labels, mono font, almost like a chat log.

## Pricing (instead of three centered tiers with checkmarks)

**Generic:** Three pricing cards, each with a tier name, price, list of features with checkmarks, "Get Started" button.

**Designed alternatives:**

### Pattern A: Single price, full page
Just the price. Big. What's included as a sentence. One CTA. Confident.

```html
<section class="price-single">
  <p class="price-eyebrow">FROM</p>
  <p class="price-amount">$2,400<span>/mo</span></p>
  <p class="price-detail">A complete contractor marketing system. Lead capture, follow-up automation, monthly content, and direct slack access for questions.</p>
  <a href="#" class="price-cta">Start a project →</a>
  <p class="price-fine">Six month minimum. Month-to-month after that.</p>
</section>
```

### Pattern B: Comparison table, dense
Real table, like B2B software in 2008 except actually well-typed. Mono numbers. Clear features. No marketing fluff.

```html
<table class="price-table">
  <thead>
    <tr><th></th><th>Starter</th><th>Standard</th><th>Pro</th></tr>
  </thead>
  <tbody>
    <tr><td>Monthly</td><td class="num">$800</td><td class="num">$1,800</td><td class="num">$3,200</td></tr>
    <tr><td>Lead capture</td><td>✓</td><td>✓</td><td>✓</td></tr>
    <tr><td>SMS automation</td><td>—</td><td>✓</td><td>✓</td></tr>
    <tr><td>Custom landing pages</td><td>—</td><td>—</td><td>✓</td></tr>
  </tbody>
</table>
```

### Pattern C: Build your own
A configurator. Pick services, the price calculates. Removes the artificial "tier" concept.

## Logos / Social Proof (instead of "Trusted by" gray bar)

**Generic:** "Trusted by" eyebrow + 5-6 logos in muted gray.

**Designed alternatives:**

### Pattern A: Inline mention
"Companies like **Patagonia**, **Stripe**, and **Allbirds** use this approach." Logos integrated into a sentence.

### Pattern B: Marquee scroll
Continuous horizontal scroll of logos. Feels alive.

### Pattern C: Massive logo wall
Twenty logos in a tight grid, treated like a constellation. Density signals scale.

### Pattern D: Just a quote
Skip logos entirely, lead with one specific customer story.

## Footer (instead of 4 columns)

**Generic:** 4 columns: Product / Company / Resources / Legal.

**Designed alternatives:**

### Pattern A: One huge logo + minimal links
The logo takes up half the footer. A single row of small links underneath. Done.

```html
<footer class="footer-mono">
  <h2 class="footer-mark">TaggleFish</h2>
  <nav>
    <a>Work</a><a>Studio</a><a>Writing</a><a>Contact</a>
  </nav>
  <p class="footer-fine">© 2026 · Made in Washington DC</p>
</footer>
```

```css
.footer-mono { padding: 96px 32px 48px; border-top: 1px solid var(--border); }
.footer-mark { font-family: 'Fraunces', serif; font-size: clamp(80px, 15vw, 240px); line-height: 0.9; letter-spacing: -0.04em; margin: 0; }
.footer-mono nav { display: flex; gap: 32px; margin: 48px 0 24px; padding-top: 24px; border-top: 1px solid var(--border); font-size: 14px; }
.footer-fine { font-size: 12px; color: var(--ink-mute); }
```

### Pattern B: Sitemap as poem
Links arranged like a poem or a manifesto, not a sitemap. "We're in **Washington**, **always reachable**, **never on weekends**."

### Pattern C: Newsletter takeover
The whole footer is a newsletter signup, treated like the most important moment on the site.

### Pattern D: Sign-off as a letter
"This site was made by Anna Lloyd in 2026 in Brooklyn over a span of three weeks. The fonts are Fraunces and Inter Tight. Built with React and stubbornness." Personal, signed.

## Navigation (instead of top bar with logo + 5 links + CTA)

### Pattern A: Vertical nav on the left
Site nav anchored to the left edge, vertical. Frees the top of every page.

### Pattern B: Hidden until scroll
No nav at first. Reveals after scroll. Forces the hero to do its job alone.

### Pattern C: Drawer
Just a hamburger that opens a full-screen drawer. Works for portfolios and brand sites.

### Pattern D: Inline with content
The nav is part of the first paragraph. "We do **work**, run a **studio**, publish **writing**, and answer **email**." Each link is inline.

## CTAs (instead of "Get Started" rounded button)

Specific copy beats generic copy:
- "Start a project" not "Get Started"
- "Book the call" not "Contact Us"
- "See the work" not "View Portfolio"
- "Send the brief" not "Submit Form"

Visual treatment ideas:
- Underlined text link instead of a button (feels editorial)
- Outlined button with the text underlined inside it (double signal)
- Filled button with sharp corners (Swiss/brutalist)
- Massive button that's almost a section of its own (Linear-style)
- Inline "→" that grows on hover (Vercel-style)
