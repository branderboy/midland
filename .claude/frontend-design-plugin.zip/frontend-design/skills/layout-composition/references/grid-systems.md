# Grid Systems

A real grid is invisible to the user but felt. AI grids tend to be either nonexistent (everything just stacks) or rigid (12 columns, every element snaps the same way). Neither feels designed.

## The 12-column grid (the standard)

```css
.grid {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  gap: 24px;
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 32px;
}
```

How to use it well:

**1. Span weird ranges.** `grid-column: 3 / 9` is more interesting than `grid-column: 1 / 7`. The eye doesn't expect content to start at column 3.

**2. Vary the spans within the same section.** A section can have a heading at `grid-column: 1 / 6`, body text at `grid-column: 7 / 12`, and a footnote at `grid-column: 1 / 4`. This creates rhythm.

**3. Break the grid for one element.** When you want something to feel important, let it span the full width or extend beyond. Used sparingly, this signals "look here."

```css
.full-bleed {
  grid-column: 1 / -1; /* spans the whole grid */
  margin: 0 calc(50% - 50vw); /* breaks out of the container too */
}
```

## The 6-column grid (for editorial)

Sometimes 12 is overkill. For editorial content where you want chunky columns:

```css
.editorial-grid {
  display: grid;
  grid-template-columns: repeat(6, 1fr);
  gap: 32px;
}
```

Body text at `grid-column: 2 / 5` reads beautifully. Headlines at `2 / 6`. Captions in the margin at `1 / 2` or `5 / 6`.

## Asymmetric custom grids

When you want something more unique than 12-column:

```css
/* Magazine-style: wide content, narrow sidebar */
.mag-grid {
  display: grid;
  grid-template-columns: minmax(0, 720px) minmax(0, 280px);
  gap: 96px;
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 32px;
}

/* Three-band: narrow / wide / narrow */
.three-band {
  display: grid;
  grid-template-columns: 1fr 3fr 1fr;
  gap: 48px;
}

/* Off-center: 2/3 and 1/3 split with whitespace on left */
.offcenter {
  display: grid;
  grid-template-columns: 1fr 8fr 4fr 1fr;
  gap: 32px;
}
```

## Baseline grids

In editorial design, type sits on a baseline grid — invisible horizontal lines spaced at the body line-height. All text aligns to these lines, creating mathematical rhythm.

```css
:root {
  --baseline: 8px;
}
body {
  font-size: 16px;
  line-height: 24px; /* 3x baseline */
}
h1 { font-size: 64px; line-height: 72px; /* 9x baseline */ margin-bottom: 24px; }
h2 { font-size: 32px; line-height: 40px; /* 5x baseline */ margin: 48px 0 16px; }
p { margin-bottom: 24px; }
```

Every margin and line-height is a multiple of 8px. The page feels orderly even though the type is visually varied.

## Modular type scales

Pick a ratio and stick with it for hierarchy:

```css
/* Major Third (1.25) — gentle */
--text-xs: 12px;
--text-sm: 14px;
--text-base: 16px;
--text-lg: 20px;
--text-xl: 25px;
--text-2xl: 31px;
--text-3xl: 39px;
--text-4xl: 49px;

/* Perfect Fourth (1.333) — moderate */
--text-base: 16px;
--text-lg: 21px;
--text-xl: 28px;
--text-2xl: 37px;
--text-3xl: 50px;
--text-4xl: 67px;

/* Golden Ratio (1.618) — dramatic */
--text-base: 16px;
--text-lg: 26px;
--text-xl: 42px;
--text-2xl: 67px;
--text-3xl: 109px;
```

For most editorial work, Perfect Fourth or Golden Ratio creates real drama. For tech UIs, Major Third is calmer and more functional.

## Spacing scale

A spacing scale that pairs with the type scale:

```css
--space-1: 4px;
--space-2: 8px;
--space-3: 12px;
--space-4: 16px;
--space-5: 24px;
--space-6: 32px;
--space-7: 48px;
--space-8: 64px;
--space-9: 96px;
--space-10: 128px;
--space-11: 192px;
--space-12: 256px;
```

Use only these values. No 22px margin. No 73px gap. The discipline pays off.

## When to break the grid

Once the grid is set, breaking it strategically creates emphasis. Three good reasons to break:

**1. To call out a key piece of content.** A pull quote that intrudes into adjacent columns. A photograph that bleeds full-width through a gridded section.

**2. To create momentum at the end of sections.** The last element of a section can break the grid to create a transition feeling. Like the closing line of a paragraph that runs longer than the rest.

**3. To establish hierarchy.** The most important element on the page can break every rule. The hero headline. The price. The single CTA.

Break the grid no more than once or twice per page. Otherwise you don't have a grid, you have chaos.

## Container-based responsive

Modern CSS lets us use container queries instead of just viewport queries. This means cards can respond to their own container's width, not the page's:

```css
.card-container {
  container-type: inline-size;
}

.card { /* default narrow layout */ }

@container (min-width: 480px) {
  .card { /* wider layout when container is bigger */ }
}
```

This is the future of component-driven layouts. Use it for cards, panels, anything that might appear in different contexts.

## Mobile-first grid setup

Always start mobile, then enhance:

```css
.section {
  display: grid;
  grid-template-columns: 1fr; /* stack on mobile */
  gap: 24px;
  padding: 32px 16px;
}

@media (min-width: 768px) {
  .section {
    grid-template-columns: repeat(12, 1fr);
    padding: 64px 32px;
  }
}

@media (min-width: 1280px) {
  .section {
    padding: 96px 48px;
  }
}
```

Three breakpoints is enough for most work. Don't over-engineer with five.
