# CSS-Only Motion Recipes

Copy-paste recipes for common motion patterns. All pure CSS — no JS, no library. Drop them in.

## 1. Letter-by-letter reveal

Wrap the headline in `<span>` per word or letter, then stagger.

```html
<h1 class="reveal-words">
  <span>Build</span>
  <span>websites</span>
  <span>that</span>
  <span>matter.</span>
</h1>
```

```css
.reveal-words { overflow: hidden; }
.reveal-words span {
  display: inline-block;
  margin-right: 0.25em;
  transform: translateY(110%);
  animation: word-reveal 0.9s cubic-bezier(0.19, 1, 0.22, 1) both;
}
.reveal-words span:nth-child(1) { animation-delay: 0.05s; }
.reveal-words span:nth-child(2) { animation-delay: 0.15s; }
.reveal-words span:nth-child(3) { animation-delay: 0.25s; }
.reveal-words span:nth-child(4) { animation-delay: 0.35s; }

@keyframes word-reveal {
  to { transform: translateY(0); }
}
```

## 2. Container reveal (one whole block)

```html
<section class="reveal-block">
  <h2>Section heading</h2>
  <p>Section content</p>
</section>
```

```css
.reveal-block {
  opacity: 0;
  transform: translateY(40px);
  animation: block-reveal 1s cubic-bezier(0.19, 1, 0.22, 1) 0.2s forwards;
}
@keyframes block-reveal {
  to { opacity: 1; transform: translateY(0); }
}
```

## 3. Curtain pull intro

A solid color slides up to reveal the page on first load.

```css
body::before {
  content: '';
  position: fixed;
  inset: 0;
  background: var(--ink);
  z-index: 9999;
  pointer-events: none;
  animation: curtain 1.2s cubic-bezier(0.76, 0, 0.24, 1) 0.3s forwards;
}
@keyframes curtain {
  to { transform: translateY(-100%); }
}
```

## 4. Marquee (infinite scroll text)

```html
<div class="marquee">
  <div class="marquee-track">
    <span>Available for projects · Available for projects · Available for projects · </span>
    <span>Available for projects · Available for projects · Available for projects · </span>
  </div>
</div>
```

```css
.marquee { overflow: hidden; }
.marquee-track {
  display: flex;
  white-space: nowrap;
  animation: marquee 30s linear infinite;
}
.marquee-track:hover { animation-play-state: paused; }
@keyframes marquee {
  to { transform: translateX(-50%); }
}
```

To reverse direction: `animation-direction: reverse`.

## 5. Underline slide-in (text links)

```css
.link-underline {
  position: relative;
  display: inline-block;
}
.link-underline::after {
  content: '';
  position: absolute;
  left: 0;
  bottom: -2px;
  width: 100%;
  height: 1px;
  background: currentColor;
  transform: scaleX(0);
  transform-origin: right;
  transition: transform 0.35s cubic-bezier(0.65, 0, 0.35, 1);
}
.link-underline:hover::after {
  transform: scaleX(1);
  transform-origin: left;
}
```

The trick: origin starts on the right, then flips to left on hover. Creates a "wipe" feel rather than a stretch.

## 6. Button fill from left

```css
.btn-fill {
  position: relative;
  display: inline-block;
  padding: 16px 32px;
  background: transparent;
  color: var(--ink);
  border: 1px solid var(--ink);
  overflow: hidden;
  transition: color 0.3s;
  z-index: 0;
}
.btn-fill::before {
  content: '';
  position: absolute;
  inset: 0;
  background: var(--ink);
  transform: translateX(-100%);
  transition: transform 0.4s cubic-bezier(0.65, 0, 0.35, 1);
  z-index: -1;
}
.btn-fill:hover {
  color: var(--bg);
}
.btn-fill:hover::before {
  transform: translateX(0);
}
```

## 7. Image zoom on hover (portfolio thumbnails)

```css
.thumb {
  overflow: hidden;
  display: block;
}
.thumb img {
  width: 100%;
  display: block;
  transform: scale(1);
  transition: transform 0.6s cubic-bezier(0.19, 1, 0.22, 1);
}
.thumb:hover img {
  transform: scale(1.04);
}
```

The container has `overflow: hidden` so the image scales within its frame.

## 8. Scroll indicator (down-arrow that pulses)

```html
<div class="scroll-indicator">
  <span>SCROLL</span>
  <div class="scroll-arrow"></div>
</div>
```

```css
.scroll-indicator {
  position: absolute;
  bottom: 32px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 11px;
  letter-spacing: 0.2em;
  text-align: center;
}
.scroll-arrow {
  width: 1px;
  height: 32px;
  margin: 16px auto 0;
  background: currentColor;
  position: relative;
  overflow: hidden;
}
.scroll-arrow::after {
  content: '';
  position: absolute;
  inset: 0;
  background: var(--bg);
  animation: scroll-arrow 2s ease-in-out infinite;
}
@keyframes scroll-arrow {
  0% { transform: translateY(-100%); }
  50% { transform: translateY(0); }
  100% { transform: translateY(100%); }
}
```

## 9. Blob morph background

For soft-pastel or organic aesthetics. SVG that morphs between shapes.

```css
.blob {
  position: absolute;
  width: 400px;
  height: 400px;
  border-radius: 50%;
  background: var(--accent);
  filter: blur(80px);
  opacity: 0.4;
  animation: blob-move 20s ease-in-out infinite;
}
@keyframes blob-move {
  0%, 100% { transform: translate(0, 0) scale(1); border-radius: 50%; }
  33% { transform: translate(60px, -40px) scale(1.1); border-radius: 60% 40% 30% 70%; }
  66% { transform: translate(-40px, 60px) scale(0.9); border-radius: 40% 60% 70% 30%; }
}
```

## 10. Number ticker (CSS-only on scroll, with a trick)

Pure CSS can't actually count up. But you can fake it with the new CSS animation timeline:

```css
@property --num {
  syntax: '<integer>';
  initial-value: 0;
  inherits: false;
}

.counter {
  counter-reset: num var(--num);
  animation: count-up 2s linear forwards;
  animation-timeline: view();
  animation-range: cover 0% cover 50%;
}
.counter::after {
  content: counter(num);
}
@keyframes count-up {
  to { --num: 1247; }
}
```

Browser support is improving but not universal. For broader support, a tiny JS Intersection Observer + counter is fine.

## 11. Glitch text effect (cyberpunk aesthetic)

```css
.glitch {
  position: relative;
  display: inline-block;
}
.glitch::before, .glitch::after {
  content: attr(data-text);
  position: absolute;
  top: 0; left: 0;
}
.glitch::before {
  color: #00FFFF;
  animation: glitch-1 2s infinite;
}
.glitch::after {
  color: #FF0040;
  animation: glitch-2 2s infinite;
}
@keyframes glitch-1 {
  0%, 100% { transform: translate(0); }
  20% { transform: translate(-2px, 2px); }
  40% { transform: translate(-2px, -2px); }
  60% { transform: translate(2px, 2px); }
  80% { transform: translate(2px, -2px); }
}
@keyframes glitch-2 {
  0%, 100% { transform: translate(0); }
  20% { transform: translate(2px, -2px); }
  40% { transform: translate(2px, 2px); }
  60% { transform: translate(-2px, -2px); }
  80% { transform: translate(-2px, 2px); }
}
```

```html
<h1 class="glitch" data-text="SYSTEM ONLINE">SYSTEM ONLINE</h1>
```

Use very sparingly. One element per page max.

## 12. Subtle pulse (for "live" indicators)

```css
.live-dot {
  display: inline-block;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #00FF41;
  position: relative;
}
.live-dot::after {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background: #00FF41;
  animation: pulse-out 2s ease-out infinite;
}
@keyframes pulse-out {
  0% { transform: scale(1); opacity: 0.7; }
  100% { transform: scale(3); opacity: 0; }
}
```

## 13. Reduced motion respect

Always wrap motion in a media query that respects user preferences:

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

This is the accessibility minimum. Some users get motion sickness from animations.
