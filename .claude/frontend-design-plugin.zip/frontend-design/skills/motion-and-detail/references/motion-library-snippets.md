# Motion Library Snippets

CSS handles 80% of motion. For the other 20% — layout animations, exit animations, complex scroll timelines, gesture interactions — you need Motion (formerly Framer Motion) or GSAP. Snippets below.

## When to use which

**Use Motion (Framer Motion) when:**
- You're in React
- You need exit animations (AnimatePresence)
- You need layout animations (cards reordering, modal opening from a click point)
- You need gesture interactions (drag, swipe)
- You want declarative motion that lives next to your components

**Use GSAP when:**
- You need complex scroll-triggered timelines (ScrollTrigger plugin)
- You need pixel-perfect choreography
- You're animating outside React or doing high-performance work
- You need precise control over playback (play, pause, reverse, seek)

**Use neither and stick to CSS when:**
- It's a hover state
- It's a single transition
- It's a basic enter animation
- The thing animates on load and never again

## Motion (Framer Motion) — install

```bash
npm install motion
```

```jsx
import { motion } from 'motion/react';
```

## Motion — basic enter animation

```jsx
<motion.div
  initial={{ opacity: 0, y: 40 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.8, ease: [0.19, 1, 0.22, 1] }}
>
  Content
</motion.div>
```

The `ease` array is the cubic-bezier — same as CSS. `[0.19, 1, 0.22, 1]` is `--ease-out-expo`.

## Motion — staggered children

```jsx
const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.08 }
  }
};

const item = {
  hidden: { opacity: 0, y: 30 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.19, 1, 0.22, 1] } }
};

<motion.ul variants={container} initial="hidden" animate="show">
  {items.map(i => (
    <motion.li key={i.id} variants={item}>{i.label}</motion.li>
  ))}
</motion.ul>
```

## Motion — scroll-triggered

```jsx
import { motion, useInView } from 'motion/react';
import { useRef } from 'react';

function Section() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <motion.section
      ref={ref}
      initial={{ opacity: 0, y: 60 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 1, ease: [0.19, 1, 0.22, 1] }}
    >
      Content
    </motion.section>
  );
}
```

`once: true` means the animation runs once, not every time the element re-enters view.

## Motion — exit animations

```jsx
import { AnimatePresence, motion } from 'motion/react';

<AnimatePresence>
  {isOpen && (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.2 }}
    >
      Modal content
    </motion.div>
  )}
</AnimatePresence>
```

Without AnimatePresence, exit animations don't run because React unmounts the component instantly.

## Motion — layout animations

When elements reorder or change size, Motion can animate the change automatically.

```jsx
<motion.div layout transition={{ duration: 0.4, ease: [0.19, 1, 0.22, 1] }}>
  {/* content that changes */}
</motion.div>
```

For lists that reorder:
```jsx
{items.map(item => (
  <motion.li key={item.id} layout>{item.label}</motion.li>
))}
```

## Motion — drag

```jsx
<motion.div
  drag
  dragConstraints={{ left: -100, right: 100, top: -100, bottom: 100 }}
  dragElastic={0.2}
  whileDrag={{ scale: 1.05 }}
>
  Drag me
</motion.div>
```

## Motion — scroll-driven progress bar

```jsx
import { motion, useScroll } from 'motion/react';

function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  return (
    <motion.div
      style={{
        position: 'fixed',
        top: 0, left: 0, right: 0,
        height: 2,
        background: 'var(--accent)',
        transformOrigin: 'left',
        scaleX: scrollYProgress,
        zIndex: 9999
      }}
    />
  );
}
```

A subtle progress bar at the top of the viewport. Better than scroll percentages.

## Motion — useTransform for parallax

```jsx
import { motion, useScroll, useTransform } from 'motion/react';

function ParallaxImage() {
  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, 1], [0, -100]);
  return <motion.img style={{ y }} src="..." />;
}
```

## GSAP — install

```bash
npm install gsap
```

```js
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
gsap.registerPlugin(ScrollTrigger);
```

GSAP is mostly free now (Webflow acquired it and made the core + ScrollTrigger free as of 2024).

## GSAP — basic timeline

```js
const tl = gsap.timeline({ defaults: { ease: 'power3.out', duration: 1 } });

tl.from('.hero h1', { y: 100, opacity: 0 })
  .from('.hero p', { y: 40, opacity: 0 }, '-=0.6') // overlap by 0.6s
  .from('.hero button', { y: 20, opacity: 0 }, '-=0.4');
```

The `-=0.6` means "start 0.6s before the previous animation ends." This is how you choreograph overlapping moments.

## GSAP — ScrollTrigger

```js
gsap.from('.feature-card', {
  y: 80,
  opacity: 0,
  duration: 1,
  stagger: 0.15,
  ease: 'power3.out',
  scrollTrigger: {
    trigger: '.features',
    start: 'top 70%',
    toggleActions: 'play none none none'
  }
});
```

`start: 'top 70%'` means: trigger when the top of `.features` reaches 70% down the viewport.

`toggleActions: 'play none none none'` means: play once, do nothing on leave/enterBack/leaveBack.

## GSAP — pinned scroll section

A section that stays in place while the user scrolls, then releases.

```js
gsap.to('.pinned-content', {
  xPercent: -100,
  ease: 'none',
  scrollTrigger: {
    trigger: '.pinned-section',
    start: 'top top',
    end: '+=2000', // pin for 2000px of scroll
    scrub: 1, // tie animation to scroll progress
    pin: true,
  }
});
```

Used for horizontal-scroll sections inside a vertical page. Apple-style.

## GSAP — text split + animate

```bash
npm install gsap
```

GSAP has a SplitText plugin for splitting text into chars/words, but it's now free with the GSAP free tier. Or use a small custom split:

```js
function splitText(el) {
  const text = el.textContent;
  el.innerHTML = '';
  text.split('').forEach(char => {
    const span = document.createElement('span');
    span.textContent = char === ' ' ? '\u00A0' : char;
    span.style.display = 'inline-block';
    el.appendChild(span);
  });
}

const h1 = document.querySelector('h1');
splitText(h1);
gsap.from(h1.children, { y: 100, opacity: 0, stagger: 0.03, duration: 0.8, ease: 'power3.out' });
```

## What NOT to do with these libraries

**1. Don't import GSAP just for fades.** A `.fade-in` CSS class is enough. GSAP is overkill.

**2. Don't animate every element on the page.** Pick the moments that matter.

**3. Don't use Motion's `whileHover` for things that could just be `:hover` in CSS.** CSS hover is faster and lighter.

**4. Don't animate things off-screen.** Wrap in IntersectionObserver / useInView so animations only run when visible.

**5. Don't ship animations without `prefers-reduced-motion` respect.** Include the CSS query and/or check `useReducedMotion()` in Motion.

```jsx
import { useReducedMotion } from 'motion/react';

function Component() {
  const shouldReduceMotion = useReducedMotion();
  const animationProps = shouldReduceMotion
    ? { initial: { opacity: 1 }, animate: { opacity: 1 } }
    : { initial: { opacity: 0, y: 40 }, animate: { opacity: 1, y: 0 } };

  return <motion.div {...animationProps}>Content</motion.div>;
}
```
