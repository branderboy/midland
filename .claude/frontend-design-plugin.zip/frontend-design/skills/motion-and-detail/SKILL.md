---
name: motion-and-detail
description: Use this skill for the final pass on any frontend build, after layout and styling are in place. Triggers on requests for animations, hover states, micro-interactions, scroll effects, page transitions, or "make it feel more polished," "add some life," "needs more interaction," "feels static," or "needs the little details." Also use when the user mentions Framer Motion, GSAP, scroll-triggered animations, custom cursors, grain/noise textures, or signature visual details. This skill replaces the AI-default reflexes (fadeInUp on every element, opacity hover, subtle scale on buttons) with intentional motion choices and the small textural details that separate "designed" from "generated."
---

# Motion and Detail

Motion and small details are the last 10% that takes a build from "this looks decent" to "this feels designed by someone who cares." Most AI motion is the same fadeInUp 0.4s ease, applied to everything, with stagger. Real motion is selective.

## The motion budget

Every page has a motion budget. You spend it on the moments that matter, not on every element.

A typical budget for a marketing page:
- **1 big choreographed moment** — the hero load, or one signature scroll-triggered reveal
- **3-5 micro-interactions** — hover states on buttons and links that have personality
- **1-2 atmospheric effects** — grain texture, subtle background motion, or a custom cursor
- **0 vanity animations** — nothing that animates just because animation is possible

If you've animated 20 things, you've over-spent. Most of it should be cut.

## What good motion looks like (vs. what AI ships)

| AI default | Better choice |
|---|---|
| `fadeInUp` on every element with 0.1s stagger | One element does something dramatic on load (a headline reveals letter-by-letter, an image scales from 0.9 to 1, a list slides up as a unit) |
| Hover: opacity 0.8 | Hover: invert background and text colors |
| Hover: scale 1.05 + soft shadow | Hover: underline slides in from left, or text shifts up 2px and reveals secondary text below |
| Page transition: fade | Page transition: section slides up from bottom, or image stays put while text crossfades |
| Button click: nothing | Button click: brief inversion or scale-down (active state matters) |
| Scroll: every section fades in | Scroll: one moment of choreography (maybe a number counts up, or text reveals as a stripe sweeps) |

## Hover states with personality

The default `transition: opacity 0.2s` is the laziest choice. Real hover states:

### For text links
```css
/* The slide-in underline */
.link {
  position: relative;
  display: inline-block;
}
.link::after {
  content: '';
  position: absolute;
  left: 0;
  bottom: -2px;
  width: 100%;
  height: 1px;
  background: currentColor;
  transform: scaleX(0);
  transform-origin: right;
  transition: transform 0.3s cubic-bezier(0.65, 0, 0.35, 1);
}
.link:hover::after {
  transform: scaleX(1);
  transform-origin: left;
}
```

```css
/* The shift-and-arrow */
.link-arrow::after {
  content: '→';
  display: inline-block;
  margin-left: 4px;
  transition: transform 0.2s;
}
.link-arrow:hover::after {
  transform: translateX(4px);
}
```

### For buttons
```css
/* The invert */
.btn {
  background: var(--ink);
  color: var(--bg);
  padding: 16px 32px;
  border: 1px solid var(--ink);
  transition: background 0.2s, color 0.2s;
}
.btn:hover {
  background: transparent;
  color: var(--ink);
}
```

```css
/* The fill-from-left */
.btn-fill {
  position: relative;
  background: transparent;
  color: var(--ink);
  border: 1px solid var(--ink);
  padding: 16px 32px;
  overflow: hidden;
  z-index: 0;
}
.btn-fill::before {
  content: '';
  position: absolute;
  inset: 0;
  background: var(--ink);
  transform: translateX(-100%);
  transition: transform 0.3s cubic-bezier(0.65, 0, 0.35, 1);
  z-index: -1;
}
.btn-fill:hover {
  color: var(--bg);
}
.btn-fill:hover::before {
  transform: translateX(0);
}
```

### For cards
```css
/* The border glow (Linear-style) */
.card {
  border: 1px solid var(--border);
  transition: border-color 0.2s;
}
.card:hover {
  border-color: var(--ink-mute);
}
```

```css
/* The lift (used sparingly — this IS the AI default but with the right easing it works) */
.card {
  transform: translateY(0);
  transition: transform 0.3s cubic-bezier(0.65, 0, 0.35, 1);
}
.card:hover {
  transform: translateY(-4px);
}
```

```css
/* The slide-reveal */
.card .card-cta {
  transform: translateY(8px);
  opacity: 0;
  transition: transform 0.3s, opacity 0.3s;
}
.card:hover .card-cta {
  transform: translateY(0);
  opacity: 1;
}
```

### For images
```css
/* The slow zoom on hover (good for portfolio thumbnails) */
.thumb {
  overflow: hidden;
}
.thumb img {
  transform: scale(1);
  transition: transform 0.6s cubic-bezier(0.65, 0, 0.35, 1);
}
.thumb:hover img {
  transform: scale(1.04);
}
```

## Easing curves that don't feel default

Stop using `ease`, `ease-in-out`, or unspecified transitions. These are the lazy curves. Use these instead:

```css
/* Cubic bezier presets */
--ease-out-expo: cubic-bezier(0.19, 1, 0.22, 1);   /* dramatic deceleration, great for entrances */
--ease-out-quint: cubic-bezier(0.22, 1, 0.36, 1);  /* less aggressive than expo */
--ease-in-out-quart: cubic-bezier(0.76, 0, 0.24, 1); /* strong both ways */
--ease-out-back: cubic-bezier(0.34, 1.56, 0.64, 1); /* slight overshoot, playful */
--ease-spring: cubic-bezier(0.43, 0.13, 0.23, 0.96); /* feels like a soft spring */
```

For interactive moments (hovers, clicks), favor `--ease-out-quint` or `--ease-out-expo`. For load animations, `--ease-out-expo` or `--ease-spring`. For playful brands, `--ease-out-back` adds personality.

## The signature page-load

Pick ONE thing for the first paint. Make it count.

### Option A: Headline reveal (CSS-only)
```html
<h1 class="reveal-headline">
  <span>Build</span>
  <span>websites</span>
  <span>that</span>
  <span>matter.</span>
</h1>
```
```css
.reveal-headline { overflow: hidden; }
.reveal-headline span {
  display: inline-block;
  transform: translateY(100%);
  animation: reveal 0.8s cubic-bezier(0.19, 1, 0.22, 1) forwards;
}
.reveal-headline span:nth-child(1) { animation-delay: 0.1s; }
.reveal-headline span:nth-child(2) { animation-delay: 0.2s; }
.reveal-headline span:nth-child(3) { animation-delay: 0.3s; }
.reveal-headline span:nth-child(4) { animation-delay: 0.4s; }
@keyframes reveal {
  to { transform: translateY(0); }
}
```

### Option B: Curtain pull (one full-screen color slides up to reveal page)
```css
body::before {
  content: '';
  position: fixed;
  inset: 0;
  background: var(--ink);
  z-index: 9999;
  animation: curtain 1s cubic-bezier(0.76, 0, 0.24, 1) 0.2s forwards;
}
@keyframes curtain {
  to { transform: translateY(-100%); }
}
```

### Option C: Stagger from one anchor
Page loads with everything at opacity 0. Then one element (the headline) appears, then content cascades from it like ripples. ONE choreographed moment.

## Scroll-triggered animation (used surgically)

Don't fade in every section on scroll. Pick the one or two moments that matter. Use the Intersection Observer API or a library:

```js
// Plain JS — no library
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('in-view');
    }
  });
}, { threshold: 0.2 });

document.querySelectorAll('[data-reveal]').forEach(el => observer.observe(el));
```

```css
[data-reveal] { opacity: 0; transform: translateY(40px); transition: opacity 1s cubic-bezier(0.19, 1, 0.22, 1), transform 1s cubic-bezier(0.19, 1, 0.22, 1); }
[data-reveal].in-view { opacity: 1; transform: translateY(0); }
```

Mark only 3-4 elements per page with `data-reveal`. Not every section.

## The textural details

These are the small things that separate good from great:

### Grain / noise overlay
A subtle noise texture on top of the page makes flat colors feel less flat. Often on dark pages.

```css
body::after {
  content: '';
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: 9999;
  opacity: 0.04;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' /%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' /%3E%3C/svg%3E");
}
```

Tweak opacity from 0.02 (barely there) to 0.08 (visible). 0.04 is a good default.

### Custom cursor (used carefully)
```css
* { cursor: none; }
.cursor {
  position: fixed;
  width: 16px;
  height: 16px;
  border: 1px solid var(--ink);
  border-radius: 50%;
  pointer-events: none;
  z-index: 9999;
  transition: transform 0.1s ease-out, width 0.2s, height 0.2s;
  transform: translate(-50%, -50%);
  mix-blend-mode: difference;
}
.cursor.hover { width: 48px; height: 48px; }
```

```js
const cursor = document.querySelector('.cursor');
document.addEventListener('mousemove', (e) => {
  cursor.style.left = e.clientX + 'px';
  cursor.style.top = e.clientY + 'px';
});
document.querySelectorAll('a, button').forEach(el => {
  el.addEventListener('mouseenter', () => cursor.classList.add('hover'));
  el.addEventListener('mouseleave', () => cursor.classList.remove('hover'));
});
```

Custom cursors only work for design-forward sites (portfolios, agencies, brand sites). Skip for SaaS/products where users need a normal cursor.

### Hairline rules with weight
```css
.rule {
  border: none;
  height: 1px;
  background: linear-gradient(to right, transparent, var(--ink) 20%, var(--ink) 80%, transparent);
}
```

A 1px line that fades at the edges feels more designed than a hard line.

### Subtle background gradients (NOT purple)
```css
.bg-glow {
  background:
    radial-gradient(ellipse at 50% 0%, rgba(94, 106, 210, 0.12), transparent 60%),
    radial-gradient(ellipse at 0% 100%, rgba(0, 212, 170, 0.08), transparent 50%);
  background-color: var(--bg);
}
```

Two off-center radial gradients in muted accent colors create atmosphere without screaming "AI gradient hero."

### Marquee scroll
```html
<div class="marquee">
  <div class="marquee-track">
    <span>Available for new work · Available for new work · Available for new work · </span>
    <span>Available for new work · Available for new work · Available for new work · </span>
  </div>
</div>
```
```css
.marquee { overflow: hidden; padding: 16px 0; border-top: 1px solid var(--border); border-bottom: 1px solid var(--border); }
.marquee-track { display: flex; white-space: nowrap; animation: marquee 30s linear infinite; }
.marquee-track span { flex-shrink: 0; padding-right: 1em; font-size: 14px; letter-spacing: 0.05em; text-transform: uppercase; }
@keyframes marquee { to { transform: translateX(-50%); } }
```

### Number count-up on scroll
For dashboards, stats, anything with figures. Numbers feel more impactful when they animate up.

## Motion library choices

**Pure CSS** — Use this for 80% of motion. Hover states, simple reveals, transitions. No library needed.

**Motion (formerly Framer Motion)** — When you need React-driven motion: layout animations, gesture interactions, AnimatePresence for exit animations. The standard for React.

**GSAP** — When you need advanced scroll-triggered timelines, complex sequences, or work that has to be pixel-perfect. The pro tool.

**View Transitions API** — Modern browsers support this natively for cross-page animations in MPAs. Use when you control the whole site.

Don't reach for a library when CSS will do. Don't reach for GSAP when Motion will do. Match the tool to the need.

## What to skip

- Parallax scrolling on hero images. Mostly looks dated in 2026 unless done with real care.
- Cursor trails (the 90s revival). Specific aesthetic only.
- Confetti on form submission. Dated.
- "Wow" loading screens. Just load fast.
- Smooth scroll libraries on every page. Native is fine for most.

## Reference files

- `references/css-only-recipes.md` — Copy-paste CSS for common motion patterns: stagger reveals, marquees, blob morphs, scroll indicators, count-up effects. Read when you need a specific pattern.
- `references/motion-library-snippets.md` — Code snippets for Motion (Framer Motion) and GSAP for the cases where CSS isn't enough. Read when you actually need a JS motion library.

## Output

When this skill triggers, identify ONE big motion moment for the page and 3-5 micro-interactions. Don't add motion to elements just because you can. Every animation needs a reason. If you can't articulate why an element animates, cut it.
