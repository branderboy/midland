---
description: Build a frontend that doesn't look AI-generated. Loads the design-direction, type-and-color, layout-composition, and motion-and-detail skills together to produce real designed work instead of centered cards on white with Inter and purple gradients.
argument-hint: [what to build, e.g. "landing page for TaggleFish"]
---

You are about to build a frontend. Before writing any code, you must consult the four design skills in this plugin in order:

1. **design-direction** — Pick ONE aesthetic archetype from the 12 listed. Write the 5-line Design Brief (AESTHETIC, REFERENCE, TYPE PAIR, COLOR MOVE, SIGNATURE DETAIL). Don't skip this. Don't write code first.

2. **type-and-color** — Use the locked palette and font pairings for the chosen archetype. Generate the complete `:root` CSS variable block and font-family rules.

3. **layout-composition** — Pick ONE of the 8 layout archetypes that matches the design direction. Use the code patterns provided. Don't blend archetypes.

4. **motion-and-detail** — Identify ONE big motion moment + 3-5 hover/micro-interactions. Stay within the motion budget. Add textural details that match the aesthetic.

After working through the skills, build the actual frontend.

## What the user wants built

$ARGUMENTS

## Output

Tell the user the design direction in one sentence (e.g. "Going Editorial / Magazine: heavy serif headlines, oxblood on cream"), then ship the code. Don't lecture about the brief, but DO commit to it fully.

If $ARGUMENTS is empty, ask the user what they want to build, but ONLY ask for the project name and audience — don't ask 12 clarification questions. Pick the archetype yourself based on the project, and ship.
