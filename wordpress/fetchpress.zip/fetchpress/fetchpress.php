<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://fetch.press
 * @since             1.0.0
 * @package           FetchPress
 *
 * @wordpress-plugin
 * Plugin Name:       FetchPress
 * Plugin URI:        http://fetch.press
 * Description:       Easy, seamless, and automated continuous deployment for themes and plugins.
 * Version:           1.4.0
 * Author:            FetchPress
 * Author URI:        https://fetch.press
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       fetchpress
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

// Prevent running if Lite version is already loaded
if ( defined( 'FETCHPRESS_LITE_VERSION' ) ) {
	return;
}

use FetchPress\FetchPress;

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'FETCHPRESS_VERSION', '1.4.0' );

/**
 * Deactivate FetchPress Lite if it's active (runtime fallback)
 */
function fetchpress_deactivate_lite_version() {
	if ( is_admin() && current_user_can( 'activate_plugins' ) ) {
		include_once ABSPATH . 'wp-admin/includes/plugin.php';
		if ( is_plugin_active( 'fetchpress-lite/fetchpress-lite.php' ) ) {
			deactivate_plugins( 'fetchpress-lite/fetchpress-lite.php' );
			add_action( 'admin_notices', 'fetchpress_lite_deactivated_notice' );
		}
	}
}
add_action( 'admin_init', 'fetchpress_deactivate_lite_version' );

/**
 * Show notice when Lite version is auto-deactivated
 */
function fetchpress_lite_deactivated_notice() {
	echo '<div class="notice notice-info is-dismissible">';
	echo '<p>' . esc_html__( 'FetchPress Lite has been deactivated. You are now using FetchPress Pro.', 'fetchpress' ) . '</p>';
	echo '</div>';
}

/**
 * The code that runs during plugin activation.
 * This action is documented in fetchpress/class-fetchpress-activator.php
 */
function activate_fetchpress() {
	require_once plugin_dir_path( __FILE__ ) . 'fetchpress/Activator.php';
	FetchPress_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in fetchpress/class-fetchpress-deactivator.php
 */
function deactivate_fetchpress() {
	require_once plugin_dir_path( __FILE__ ) . 'fetchpress/Deactivator.php';
	FetchPress_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_fetchpress' );
register_deactivation_hook( __FILE__, 'deactivate_fetchpress' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'fetchpress/FetchPress.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_fetchpress() {

	$plugin = new FetchPress();
	$plugin->run();

}
run_fetchpress();
