=== FetchPress ===
Contributors: teustice
Tags: deployment, github, bitbucket, gitlab, cicd
Requires at least: 4.8
Tested up to: 6.9
Stable tag: 1.2.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easy, seamless, and automated continuous deployment for themes and plugins.

== Description ==

## Work Faster not harder.

FetchPress is a powerful WordPress plugin that enables you to streamline your development workflow by automating the deployment process. With FetchPress, you can easily hook into your remote git repository and deploy your code automatically whenever you push your changes or merge a pull request. This can save you a lot of time and effort, as you no longer have to rely on manual deployment methods like FTP or similar tools.

One of the key benefits of FetchPress is that it seamlessly integrates with your existing version control workflow. This means that you can continue to use your preferred version control system, whether it's Git, SVN, or another tool, while still taking advantage of the powerful automation features that FetchPress provides. This makes it easier than ever to manage your codebase, collaborate with team members, and deploy changes with confidence.

If you're building custom themes or plugins for WordPress, then version control is an essential part of your development process. With FetchPress, you can take your workflow to the next level by automating deployment and simplifying your development process. Whether you're a solo developer or part of a larger team, FetchPress is a valuable tool that can help you work more efficiently and effectively.

## Key Features
- Automatically pull theme/plugin data into WordPress when you push code to GitHub.
- Designed to work with public or private repositories.
- Pull code from a subdirectory within a repository.
- Select what branch should trigger deployment, allowing you to push your code to staging confidently.


## For Help and Support, Please see:
- Our documentation and installation guide, here: [https://fetch.press/docs](https://fetch.press/docs)
