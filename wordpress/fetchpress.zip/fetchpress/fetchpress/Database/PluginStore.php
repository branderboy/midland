<?php

namespace FetchPress\Database;

if ( ! defined( 'ABSPATH' ) ) exit;

include_once(ABSPATH . 'wp-admin/includes/plugin.php');
include_once(ABSPATH . 'wp-admin/includes/file.php');
include_once(ABSPATH . 'wp-admin/includes/class-wp-upgrader.php');
include_once(ABSPATH . 'wp-admin/includes/misc.php');

use \WPTRT\AdminNotices\Notices;
use FetchPress\Models\Plugin;
use FetchPress\Repo\GithubHandler;
use FetchPress\Repo\BitbucketHandler;
use FetchPress\Repo\GitLabHandler;
use Plugin_Upgrader;

use stdClass;

class PluginStore
{

    /**
     * responsible for storing the theme in the db and downloading the code from vc
     *
     * @since    1.0.0
     * @access   protected
     * @var      AddPlugin    $theme    Repo info from AddPlugin event
     */

    public $plugin;
    public $notice_handler;
    public $github_handler;
    public $bitbucket_handler;
    public $gitlab_handler;

    public function __construct()
    {
        $this->notice_handler = new Notices();
        $this->github_handler = new GithubHandler();
        $this->bitbucket_handler = new BitbucketHandler();
        $this->gitlab_handler = new GitLabHandler();
    }

    public function save($plugin)
    {
        $this->plugin = $plugin;
        if (!$this->plugin->linktoexisting) {
            $install_result = $this->download_plugin($this->plugin);
            if (!$install_result || is_wp_error($install_result)) {
                $error_message = is_wp_error($install_result) ? $install_result->get_error_message() : 'This plugin might already be installed. Otherwise, check your repository path and subfolder.';
                $this->notice_handler->add('plugin_install_failure', 'There was a problem installing your plugin', $error_message, array('type' => 'error'));
                $this->notice_handler->boot();
                return false;
            }
        }

        global $wpdb;

        $table_title = $wpdb->prefix . 'fetchpress';

        //map plugin file and other meta to object
        $plugin = $this->from_slug($this->get_slug($plugin));

        $plugin = array(
            'title' => $plugin->file,
            'repository' => $this->plugin->repository,
            'privaterepo' => $this->plugin->privaterepo,
            'branch' => $this->plugin->branch,
            'deployonpush' => $this->plugin->deployonpush,
            'vcservice' => $this->plugin->vcservice,
            'subdirectory' => $this->plugin->subdirectory,
            'isplugin' => 1,
        );

        //Set webhook for specified version control
        $this->webhook_selector($plugin);

        $db_success = $wpdb->insert(
            $table_title,
            $plugin
        );

        if ($db_success) {
            $this->notice_handler->add('add_plugin_success', 'Your plugin "' . $this->plugin->repository . '" was installed successfully', 'Go ahead and <a href="' . get_site_url() . '/wp-admin/plugins.php">activate</a> it!', array('type' => 'success'));
        } else {
            $this->notice_handler->add('add_plugin_failure', 'There was an issue installing your plugin', 'This plugin might already be installed.', array('type' => 'error'));
        }

        $this->notice_handler->boot();
    }

    public function edit($plugin)
    {
        $this->plugin = $plugin;

        $plugin = $this->from_slug($this->get_slug($plugin));

        global $wpdb;

        $table_title = $wpdb->prefix . 'fetchpress';

        $plugin = array(
            'title' => $plugin->file,
            'repository' => $this->plugin->repository,
            'privaterepo' => $this->plugin->privaterepo,
            'branch' => $this->plugin->branch,
            'deployonpush' => $this->plugin->deployonpush,
            'vcservice' => $this->plugin->vcservice,
            'subdirectory' => $this->plugin->subdirectory,
            'isplugin' => 1,
        );

        //Set webhook for specified version control
        $this->webhook_selector($plugin);

        $db_success = $wpdb->update(
            $table_title,
            $plugin,
            array('title' => $plugin['title'])
        );

        if ($db_success) {
            $this->notice_handler->add('edit_plugin_success', 'Your plugin "' . $this->plugin->repository . '" was updated successfully', '<a href="' . get_site_url() . '/wp-admin/admin.php?page=fetchpress-plugins">Back to plugins</a>', array('type' => 'success'));
        } else {
            $this->notice_handler->add('edit_plugin_failure', 'There was an issue updating your plugin', 'Check your updated repository path', array('type' => 'error'));
        }

        $this->notice_handler->boot();
    }

    public function update($file, $triggered_by = 'manual')
    {
        $plugin = $this->get_plugin_from_file($file);

        // Initialize deployment logging
        $logger = new DeploymentLogger();
        $artifact_manager = new ArtifactManager();

        // Get current version before upgrade
        $version_before = $plugin->version ?? null;

        // Get FetchPress ID
        $fetchpress_id = $logger->get_fetchpress_id($file, 'plugin');

        // Log deployment start
        $deployment_id = $logger->log_deployment(array(
            'fetchpress_id' => $fetchpress_id,
            'type' => 'plugin',
            'identifier' => $file,
            'status' => 'pending',
            'version_before' => $version_before,
            'triggered_by' => $triggered_by,
        ));

        // Store artifact for potential rollback
        if ($deployment_id) {
            $artifact_path = $artifact_manager->store_artifact($file, 'plugin', $deployment_id);
            if ($artifact_path) {
                $logger->update_artifact_path($deployment_id, $artifact_path);
            }
        }

        // Perform the upgrade
        $result = $this->upgrade_plugin($plugin);

        // Get new version after upgrade
        $plugin_meta = get_plugin_data(WP_PLUGIN_DIR . "/" . $file);
        $version_after = $plugin_meta['Version'] ?? null;

        // Update deployment status
        if ($result === true || !is_wp_error($result)) {
            if ($deployment_id) {
                $logger->update_status($deployment_id, 'success', null, $version_after);
            }
            $this->notice_handler->add('update_plugin_success', 'Your plugin "' . $plugin->name . '" was upgraded successfully', ' ', array('type' => 'success'));
        } else {
            $error_message = is_wp_error($result) ? $result->get_error_message() : 'Unknown error occurred';
            if ($deployment_id) {
                $logger->update_status($deployment_id, 'failed', $error_message, $version_after);
            }
            $this->notice_handler->add('update_plugin_fail', 'Your plugin "' . $plugin->name . '" could not be updated.', 'Error: ' . $error_message, array('type' => 'error'));
            $this->notice_handler->boot();
        }

        $this->notice_handler->boot();
    }

    public function download_plugin($plugin)
    {
        //returns true/WP_Error if installation was successful/failed

        $skin = new PluginSkin();
        $upgrader = new Plugin_Upgrader($skin);
        $this->plugin = $plugin;

        //add filter to assign correct plugin folder name
        add_filter('upgrader_source_selection', array($this, 'upgrade_source_selection_callback'), 10, 3);
        $result = $upgrader->install($this->git_service_zip_selector($plugin));

        //Check for errors from the skin
        if ($skin->get_error() && is_wp_error($skin->get_error())) {
            return $skin->get_error();
        }

        return $result;
    }

    public function upgrade_plugin($plugin)
    {
        //returns true/WP_Error if installation was successful/failed
        //Uses direct package installation with overwrite to avoid WordPress update transients

        $skin = new PluginSkin();
        $upgrader = new Plugin_Upgrader($skin);
        $this->plugin = $plugin;

        $is_plugin_active = is_plugin_active($plugin->file);
        $is_plugin_active_network_wide = is_plugin_active_for_network($plugin->file);

        //add filter to assign correct plugin folder name
        add_filter('upgrader_source_selection', array($this, 'upgrade_source_selection_callback'), 10, 3);

        //Install with overwrite flag to replace existing plugin
        $result = $upgrader->install($this->git_service_zip_selector($plugin), array('overwrite_package' => true));

        //Check for errors from the skin
        if ($skin->get_error() && is_wp_error($skin->get_error())) {
            return $skin->get_error();
        }

        if ($is_plugin_active) {
            if (!is_plugin_active($plugin->file))
                activate_plugin($plugin->file, null, $network_wide = $is_plugin_active_network_wide, $silent = true);
        }

        return $result;
    }

    public function delete($id)
    {
        global $wpdb;

        $table_name = $wpdb->prefix . 'fetchpress';

        $wpdb->delete($table_name, array('id' => sanitize_text_field($id)));
    }

    public function delete_plugin($file)
    {
        global $wpdb;
        $table_title = $wpdb->prefix . 'fetchpress';
        $wpdb->delete($table_title, array('title' => sanitize_text_field($file)));

        $this->notice_handler->add('delete_theme_success', 'Your theme "' . $file . '" has been unlinked', 'If you would like to remove the plugin code, delete it <a href="' . get_site_url() . '/wp-admin/plugins.php">here</a>.', array('type' => 'success'));
        $this->notice_handler->boot();
    }

    public function get_slug($plugin)
    {
        if (!$plugin->subdirectory) {
            return $plugin->get_slug_from_repo();
        }

        $parts = explode('/', $plugin->subdirectory);

        return end($parts);
    }

    public function from_slug($slug)
    {
        $plugins = get_plugins();

        foreach ($plugins as $file => $pluginInfo) {
            $tmp = explode('/', $file);
            $currentSlug = $tmp[0];

            if ($currentSlug === $slug) break;

            $file = null;
        }

        return Plugin::map_from_wp_plugin_object($file, $pluginInfo);
    }

    public function upgrade_source_selection_callback($source, $remote_source, $upgrader)
    {
        if (isset($this->plugin->subdirectory)) {
            $source = trailingslashit($source) . trailingslashit($this->plugin->subdirectory);
        }

        $newSource = trailingslashit($remote_source) . trailingslashit($this->plugin->get_slug());

        global $wp_filesystem;

        if (!$wp_filesystem->move($source, $newSource, true))
            return new \WP_Error('fetchpress_subdirectory', "We couldn't find subdirectory in repository.");

        return $newSource;
    }

    public function set_transient_for_update($transient)
    {
        $options = array('package' => $this->git_service_zip_selector($this->plugin));

        if (!$transient) {
            $transient = new stdClass;
        };

        $transient->response[$this->plugin->file] = (object) $options;

        return $transient;
    }

    public function get_all_plugins()
    {

        include_once(ABSPATH . 'wp-admin/includes/plugin.php');

        global $wpdb;

        $table_name = $wpdb->prefix . 'fetchpress';

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Table name is constructed from trusted $wpdb->prefix, isplugin is a literal value
        $rows = $wpdb->get_results("SELECT * FROM $table_name WHERE isplugin = 1");

        $plugins = array();

        foreach ($rows as $row) {
            // This is our time to do some cleaning up
            if (!file_exists(WP_PLUGIN_DIR . "/" . $row->title)) {
                $this->delete($row->id);
                continue;
            }

            $object = get_plugin_data(WP_PLUGIN_DIR . "/" . $row->title);
            $plugins[$row->title] = Plugin::map_from_wp_plugin_object($row, $object);
            $plugins[$row->title]->branch = $row->branch;
            $plugins[$row->title]->repository = $row->repository;
            $plugins[$row->title]->deployonpush = $row->deployonpush;
            $plugins[$row->title]->privaterepo = $row->privaterepo;
            $plugins[$row->title]->vcservice = $row->vcservice;
            $plugins[$row->title]->subdirectory = $row->subdirectory;
        }

        return $plugins;
    }

    public function get_plugin_from_file($plugin_file)
    {
        include_once(ABSPATH . 'wp-admin/includes/plugin.php');

        global $wpdb;

        $table_name = $wpdb->prefix . 'fetchpress';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE isplugin = 1 AND title = %s", $plugin_file));

        if (!$row or !file_exists(WP_PLUGIN_DIR . "/" . $plugin_file)) {
            $this->notice_handler->add('get_plugin_from_file_error', '', array('type' => 'error'));
            $this->notice_handler->boot();
        }

        $plugin_meta = get_plugin_data(WP_PLUGIN_DIR . "/" . $plugin_file);
        $plugin = Plugin::map_from_wp_plugin_object($plugin_file, $plugin_meta);

        $plugin->branch = $row->branch;
        $plugin->repository = $row->repository;
        $plugin->deployonpush = $row->deployonpush;
        $plugin->vcservice = $row->vcservice;
        $plugin->subdirectory = $row->subdirectory;
        $plugin->privaterepo = $row->privaterepo;

        return $plugin;
    }

    public function git_service_zip_selector($plugin)
    {
        switch ($plugin->vcservice) {
            case 'github':
                return $this->github_handler->get_zip_data_url($plugin);
            case 'bitbucket':
                return $this->bitbucket_handler->get_zip_data_url($plugin);
            case 'gitlab':
                return $this->gitlab_handler->get_zip_data_url($plugin);
        }
    }

    public function webhook_selector($plugin)
    {
        switch ($plugin['vcservice']) {
            case 'github':
                return $this->github_handler->set_webhook($plugin, true);
            case 'bitbucket':
                return $this->bitbucket_handler->set_webhook($plugin, true);
            case 'gitlab':
                // return $this->gitlab_handler->set_webhook($plugin);
        }
    }
}
