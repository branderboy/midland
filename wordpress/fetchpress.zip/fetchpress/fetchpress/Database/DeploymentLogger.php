<?php

namespace FetchPress\Database;

if (!defined('ABSPATH')) exit;

class DeploymentLogger
{
    /**
     * Log a new deployment
     *
     * @param array $data Deployment data
     * @return int|false Deployment ID or false on failure
     */
    public function log_deployment($data)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'fetchpress_deployments';

        $defaults = array(
            'fetchpress_id' => 0,
            'type' => 'plugin',
            'identifier' => '',
            'status' => 'pending',
            'commit_ref' => null,
            'version_before' => null,
            'version_after' => null,
            'artifact_path' => null,
            'error_message' => null,
            'triggered_by' => 'manual',
        );

        $data = wp_parse_args($data, $defaults);

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $result = $wpdb->insert(
            $table_name,
            array(
                'fetchpress_id' => absint($data['fetchpress_id']),
                'type' => sanitize_text_field($data['type']),
                'identifier' => sanitize_text_field($data['identifier']),
                'status' => sanitize_text_field($data['status']),
                'commit_ref' => $data['commit_ref'] ? sanitize_text_field($data['commit_ref']) : null,
                'version_before' => $data['version_before'] ? sanitize_text_field($data['version_before']) : null,
                'version_after' => $data['version_after'] ? sanitize_text_field($data['version_after']) : null,
                'artifact_path' => $data['artifact_path'] ? sanitize_text_field($data['artifact_path']) : null,
                'error_message' => $data['error_message'],
                'triggered_by' => sanitize_text_field($data['triggered_by']),
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );

        if ($result === false) {
            return false;
        }

        return $wpdb->insert_id;
    }

    /**
     * Update deployment status
     *
     * @param int $id Deployment ID
     * @param string $status New status
     * @param string|null $error Error message if failed
     * @param string|null $version_after Version after deployment
     * @return bool Success
     */
    public function update_status($id, $status, $error = null, $version_after = null)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'fetchpress_deployments';

        $data = array('status' => sanitize_text_field($status));
        $format = array('%s');

        if ($error !== null) {
            $data['error_message'] = $error;
            $format[] = '%s';
        }

        if ($version_after !== null) {
            $data['version_after'] = sanitize_text_field($version_after);
            $format[] = '%s';
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->update(
            $table_name,
            $data,
            array('id' => absint($id)),
            $format,
            array('%d')
        );

        return $result !== false;
    }

    /**
     * Update artifact path for a deployment
     *
     * @param int $id Deployment ID
     * @param string $artifact_path Path to artifact
     * @return bool Success
     */
    public function update_artifact_path($id, $artifact_path)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'fetchpress_deployments';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->update(
            $table_name,
            array('artifact_path' => sanitize_text_field($artifact_path)),
            array('id' => absint($id)),
            array('%s'),
            array('%d')
        );

        return $result !== false;
    }

    /**
     * Get deployment history for an identifier
     *
     * @param string $identifier Plugin file or theme stylesheet
     * @param string $type 'plugin' or 'theme'
     * @param string $tier Subscription tier for retention filtering
     * @param int $limit Max records to return
     * @return array Deployment records
     */
    public function get_history($identifier, $type, $tier = 'free', $limit = 50)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'fetchpress_deployments';

        $retention_days = $this->get_retention_days($tier);

        $query = "SELECT * FROM $table_name WHERE identifier = %s AND type = %s";
        $params = array($identifier, $type);

        // Apply retention filter if not unlimited
        if ($retention_days > 0) {
            $query .= " AND deployed_at >= DATE_SUB(NOW(), INTERVAL %d DAY)";
            $params[] = $retention_days;
        }

        $query .= " ORDER BY deployed_at DESC LIMIT %d";
        $params[] = $limit;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
        return $wpdb->get_results($wpdb->prepare($query, $params));
    }

    /**
     * Get all deployment history (for history page)
     *
     * @param string $tier Subscription tier for retention filtering
     * @param int $limit Max records to return
     * @return array Deployment records
     */
    public function get_all_history($tier = 'free', $limit = 100)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'fetchpress_deployments';

        $retention_days = $this->get_retention_days($tier);

        $query = "SELECT * FROM $table_name WHERE 1=1";
        $params = array();

        // Apply retention filter if not unlimited
        if ($retention_days > 0) {
            $query .= " AND deployed_at >= DATE_SUB(NOW(), INTERVAL %d DAY)";
            $params[] = $retention_days;
        }

        $query .= " ORDER BY deployed_at DESC LIMIT %d";
        $params[] = $limit;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
        return $wpdb->get_results($wpdb->prepare($query, $params));
    }

    /**
     * Get a single deployment record
     *
     * @param int $id Deployment ID
     * @return object|null Deployment record
     */
    public function get_deployment($id)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'fetchpress_deployments';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", absint($id)));
    }

    /**
     * Delete old deployments based on tier retention
     *
     * @param string $tier Subscription tier
     * @return int Number of deleted records
     */
    public function cleanup_old_deployments($tier)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'fetchpress_deployments';

        $retention_days = $this->get_retention_days($tier);

        // Don't cleanup if unlimited retention
        if ($retention_days < 0) {
            return 0;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->query($wpdb->prepare(
            "DELETE FROM $table_name WHERE deployed_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $retention_days
        ));

        return $result !== false ? $result : 0;
    }

    /**
     * Get retention days based on tier
     *
     * @param string $tier Subscription tier
     * @return int Days to retain (-1 for unlimited)
     */
    public function get_retention_days($tier)
    {
        if ($tier === 'pro' || $tier === 'starter' || $tier === 'legacy' || $tier === 'agency') {
            return -1; // Unlimited — all paid plans
        }
        return 7;
    }

    /**
     * Get FetchPress ID for a plugin or theme
     *
     * @param string $identifier Plugin file or theme stylesheet
     * @param string $type 'plugin' or 'theme'
     * @return int FetchPress ID or 0
     */
    public function get_fetchpress_id($identifier, $type)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'fetchpress';
        $isplugin = $type === 'plugin' ? 1 : 0;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM $table_name WHERE title = %s AND isplugin = %d",
            $identifier,
            $isplugin
        ));

        return $row ? (int) $row->id : 0;
    }
}
