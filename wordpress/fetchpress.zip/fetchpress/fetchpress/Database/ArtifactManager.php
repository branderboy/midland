<?php

namespace FetchPress\Database;

if (!defined('ABSPATH')) exit;

class ArtifactManager
{
    /**
     * Get the base artifacts directory path
     *
     * @return string
     */
    public function get_artifacts_base_dir()
    {
        $upload_dir = wp_upload_dir();
        return trailingslashit($upload_dir['basedir']) . 'fetchpress-artifacts';
    }

    /**
     * Ensure the artifacts directory exists with proper protection
     *
     * @return bool Success
     */
    public function ensure_artifacts_directory()
    {
        $base_dir = $this->get_artifacts_base_dir();

        // Create directories if they don't exist
        $dirs = array(
            $base_dir,
            $base_dir . '/plugins',
            $base_dir . '/themes',
        );

        foreach ($dirs as $dir) {
            if (!file_exists($dir)) {
                if (!wp_mkdir_p($dir)) {
                    return false;
                }
            }
        }

        // Create .htaccess for security
        $htaccess_path = $base_dir . '/.htaccess';
        if (!file_exists($htaccess_path)) {
            $htaccess_content = "Order Deny,Allow\nDeny from all\n";
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
            file_put_contents($htaccess_path, $htaccess_content);
        }

        // Create index.php for additional security
        $index_path = $base_dir . '/index.php';
        if (!file_exists($index_path)) {
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
            file_put_contents($index_path, '<?php // Silence is golden');
        }

        return true;
    }

    /**
     * Get slug from identifier
     *
     * @param string $identifier Plugin file or theme stylesheet
     * @param string $type 'plugin' or 'theme'
     * @return string Slug
     */
    private function get_slug_from_identifier($identifier, $type)
    {
        if ($type === 'plugin') {
            // Plugin identifier is like "plugin-folder/plugin-file.php"
            $parts = explode('/', $identifier);
            return sanitize_file_name($parts[0]);
        }
        // Theme identifier is the stylesheet/folder name
        return sanitize_file_name($identifier);
    }

    /**
     * Get the source directory for a plugin or theme
     *
     * @param string $identifier Plugin file or theme stylesheet
     * @param string $type 'plugin' or 'theme'
     * @return string|false Source directory path or false if not found
     */
    private function get_source_directory($identifier, $type)
    {
        if ($type === 'plugin') {
            $parts = explode('/', $identifier);
            $plugin_dir = WP_PLUGIN_DIR . '/' . $parts[0];
            if (is_dir($plugin_dir)) {
                return $plugin_dir;
            }
        } else {
            $theme_dir = get_theme_root() . '/' . $identifier;
            if (is_dir($theme_dir)) {
                return $theme_dir;
            }
        }
        return false;
    }

    /**
     * Store an artifact (zip) of the current plugin/theme state
     *
     * @param string $identifier Plugin file or theme stylesheet
     * @param string $type 'plugin' or 'theme'
     * @param int $deployment_id Deployment ID for filename
     * @return string|false Artifact path or false on failure
     */
    public function store_artifact($identifier, $type, $deployment_id)
    {
        if (!$this->ensure_artifacts_directory()) {
            return false;
        }

        $slug = $this->get_slug_from_identifier($identifier, $type);
        $type_dir = $type === 'plugin' ? 'plugins' : 'themes';
        $artifact_dir = $this->get_artifacts_base_dir() . '/' . $type_dir . '/' . $slug;

        // Create slug directory if needed
        if (!file_exists($artifact_dir)) {
            if (!wp_mkdir_p($artifact_dir)) {
                return false;
            }
        }

        $source_dir = $this->get_source_directory($identifier, $type);
        if (!$source_dir) {
            return false;
        }

        $artifact_path = $artifact_dir . '/' . $deployment_id . '.zip';

        // Create zip file
        if (!$this->create_zip($source_dir, $artifact_path)) {
            return false;
        }

        return $artifact_path;
    }

    /**
     * Create a zip file from a directory
     *
     * @param string $source_dir Source directory
     * @param string $destination_path Zip file destination
     * @return bool Success
     */
    private function create_zip($source_dir, $destination_path)
    {
        if (!class_exists('ZipArchive')) {
            return false;
        }

        $zip = new \ZipArchive();
        if ($zip->open($destination_path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            return false;
        }

        $source_dir = realpath($source_dir);
        $base_name = basename($source_dir);

        $files = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($source_dir, \RecursiveDirectoryIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($files as $file) {
            $file_path = realpath($file);
            $relative_path = $base_name . '/' . substr($file_path, strlen($source_dir) + 1);

            if (is_dir($file_path)) {
                $zip->addEmptyDir($relative_path);
            } else {
                $zip->addFile($file_path, $relative_path);
            }
        }

        return $zip->close();
    }

    /**
     * Get the artifact path for a deployment
     *
     * @param int $deployment_id Deployment ID
     * @return string|null Artifact path or null if not found
     */
    public function get_artifact_path($deployment_id)
    {
        $logger = new DeploymentLogger();
        $deployment = $logger->get_deployment($deployment_id);

        if (!$deployment || empty($deployment->artifact_path)) {
            return null;
        }

        if (!file_exists($deployment->artifact_path)) {
            return null;
        }

        return $deployment->artifact_path;
    }

    /**
     * Extract an artifact to restore files
     *
     * @param string $artifact_path Path to zip file
     * @param string $destination Directory to extract to
     * @return bool Success
     */
    public function extract_artifact($artifact_path, $destination)
    {
        if (!class_exists('ZipArchive')) {
            return false;
        }

        if (!file_exists($artifact_path)) {
            return false;
        }

        $zip = new \ZipArchive();
        if ($zip->open($artifact_path) !== true) {
            return false;
        }

        // Extract to parent directory since zip contains the folder
        $result = $zip->extractTo(dirname($destination));
        $zip->close();

        return $result;
    }

    /**
     * Delete an artifact file
     *
     * @param int $deployment_id Deployment ID
     * @return bool Success
     */
    public function delete_artifact($deployment_id)
    {
        $artifact_path = $this->get_artifact_path($deployment_id);

        if ($artifact_path && file_exists($artifact_path)) {
            return wp_delete_file($artifact_path);
        }

        return true;
    }

    /**
     * Cleanup old artifacts based on tier retention
     *
     * @param string $tier Subscription tier
     * @return int Number of deleted files
     */
    public function cleanup_old_artifacts($tier)
    {
        $logger = new DeploymentLogger();
        $retention_days = $logger->get_retention_days($tier);

        // Don't cleanup if unlimited retention
        if ($retention_days < 0) {
            return 0;
        }

        $deleted = 0;
        $cutoff_date = gmdate('Y-m-d H:i:s', strtotime("-{$retention_days} days"));

        global $wpdb;
        $table_name = $wpdb->prefix . 'fetchpress_deployments';

        // Get old deployments with artifacts
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $old_deployments = $wpdb->get_results($wpdb->prepare(
            "SELECT id, artifact_path FROM $table_name WHERE deployed_at < %s AND artifact_path IS NOT NULL",
            $cutoff_date
        ));

        foreach ($old_deployments as $deployment) {
            if (!empty($deployment->artifact_path) && file_exists($deployment->artifact_path)) {
                if (wp_delete_file($deployment->artifact_path)) {
                    $deleted++;
                }
            }
        }

        return $deleted;
    }
}
