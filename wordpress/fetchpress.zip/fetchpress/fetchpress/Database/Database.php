<?php

namespace FetchPress\Database;

class Database
{

    public static $fetchpress_db_version = '2.0';

    public function install()
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        // Main fetchpress table
        $table_title = $wpdb->prefix . 'fetchpress';
        $sql = "CREATE TABLE $table_title (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        title varchar(255) NOT NULL,
        repository varchar(255) NOT NULL,
        privaterepo int NOT NULL,
        branch varchar(255) NOT NULL DEFAULT 'master',
        isplugin int NOT NULL,
        deployonpush int NOT NULL,
        vcservice varchar(10) NOT NULL,
        subdirectory VARCHAR(255),
        UNIQUE KEY id (id)
    ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        // Deployments history table (new in 2.0)
        $deployments_table = $wpdb->prefix . 'fetchpress_deployments';
        $deployments_sql = "CREATE TABLE $deployments_table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            fetchpress_id mediumint(9) NOT NULL,
            type varchar(10) NOT NULL,
            identifier varchar(255) NOT NULL,
            deployed_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            status varchar(20) NOT NULL,
            commit_ref varchar(255) DEFAULT NULL,
            version_before varchar(50) DEFAULT NULL,
            version_after varchar(50) DEFAULT NULL,
            artifact_path varchar(500) DEFAULT NULL,
            error_message text DEFAULT NULL,
            triggered_by varchar(50) NOT NULL,
            PRIMARY KEY (id),
            KEY fetchpress_id (fetchpress_id),
            KEY identifier (identifier),
            KEY deployed_at (deployed_at)
        ) $charset_collate;";

        dbDelta($deployments_sql);

        // Update version option
        update_option('fetchpress_db_version', self::$fetchpress_db_version);
    }

    public function uninstall()
    {
        global $wpdb;
        $table_title = $wpdb->prefix . 'fetchpress';
        $deployments_table = $wpdb->prefix . 'fetchpress_deployments';
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names are constructed from trusted $wpdb->prefix
        $wpdb->query("DROP TABLE IF EXISTS $deployments_table;");
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names are constructed from trusted $wpdb->prefix
        $wpdb->query("DROP TABLE IF EXISTS $table_title;");
        delete_option('fetchpress_db_version');
    }

    public function delete($id)
    {
        global $wpdb;
        $table_title = $wpdb->prefix . 'fetchpress';
        $wpdb->delete($table_title, array('id' => sanitize_text_field($id)));
    }

    public function cleanup()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'fetchpress';
        $rows = $wpdb->get_results("SELECT * FROM {$table_name}");
        foreach ($rows as $row) {
            if ($row->isplugin === '1' && !file_exists(WP_PLUGIN_DIR . "/" . $row->title)) {
                $this->delete($row->id);
                continue;
            }
            if ($row->isplugin === '0' && !file_exists(get_theme_root() . "/" . $row->title)) {
                $this->delete($row->id);
                continue;
            }
        }
    }
}
