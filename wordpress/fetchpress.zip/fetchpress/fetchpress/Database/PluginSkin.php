<?php

namespace FetchPress\Database;

use Plugin_Upgrader_Skin;
use WP_Error;

class PluginSkin extends Plugin_Upgrader_Skin
{
    protected $error;
    protected $feedback;

    public function after()
    {
        // WP doesn't sent all errors as actual error objects
        if ($this->error === 'up_to_date') {
            $this->error = new WP_Error('fetchpress_error', 'Plugin is up-to-date.');
        }

        if ( ! is_null($this->error)) {
            //handle theme update fail here

            // do_action('fetchpress_theme_update_failed', new ThemeUpdateFailed(
            //     $this->error->get_error_message()
            // ));

            // throw new InstallFailed($this->error->get_error_message());
        }
    }

    public function before()
    {
        // ...
    }

    public function error($error)
    {
        $this->error = $error;
    }

    public function get_error()
    {
        return $this->error;
    }

    public function header()
    {
        // ...
    }

    public function feedback($string, ...$args)
    {
        $this->feedback[$string] = true;
    }

    public function footer()
    {
        // ...
    }
}
