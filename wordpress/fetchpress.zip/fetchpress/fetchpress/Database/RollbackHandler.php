<?php

namespace FetchPress\Database;

if (!defined('ABSPATH')) exit;

use \WPTRT\AdminNotices\Notices;

class RollbackHandler
{
    private $notice_handler;
    private $logger;
    private $artifact_manager;

    public function __construct()
    {
        $this->notice_handler = new Notices();
        $this->logger = new DeploymentLogger();
        $this->artifact_manager = new ArtifactManager();
    }

    /**
     * Check if rollback is possible for a deployment
     *
     * @param int $deployment_id Deployment ID
     * @param array $features Feature flags from subscription (unused, kept for compatibility)
     * @return array ['can_rollback' => bool, 'reason' => string]
     */
    public function can_rollback($deployment_id, $features = array())
    {
        // Get deployment record
        $deployment = $this->logger->get_deployment($deployment_id);
        if (!$deployment) {
            return array(
                'can_rollback' => false,
                'reason' => 'Deployment record not found.'
            );
        }

        // Check if deployment was successful (can only rollback successful deployments)
        if ($deployment->status !== 'success') {
            return array(
                'can_rollback' => false,
                'reason' => 'Can only rollback successful deployments.'
            );
        }

        // Check if artifact exists
        if (empty($deployment->artifact_path) || !file_exists($deployment->artifact_path)) {
            return array(
                'can_rollback' => false,
                'reason' => 'Rollback artifact not found. It may have been cleaned up.'
            );
        }

        return array(
            'can_rollback' => true,
            'reason' => ''
        );
    }

    /**
     * Execute rollback for a deployment
     *
     * @param int $deployment_id Deployment ID
     * @param array $features Feature flags from subscription
     * @return bool Success
     */
    public function rollback($deployment_id, $features = array())
    {
        // Verify rollback is possible
        $check = $this->can_rollback($deployment_id, $features);
        if (!$check['can_rollback']) {
            $this->notice_handler->add(
                'rollback_failed',
                'Rollback Failed',
                $check['reason'],
                array('type' => 'error')
            );
            $this->notice_handler->boot();
            return false;
        }

        $deployment = $this->logger->get_deployment($deployment_id);
        $artifact_path = $deployment->artifact_path;

        // Determine destination directory
        if ($deployment->type === 'plugin') {
            $parts = explode('/', $deployment->identifier);
            $destination = WP_PLUGIN_DIR . '/' . $parts[0];
        } else {
            $destination = get_theme_root() . '/' . $deployment->identifier;
        }

        // Log the rollback as a new deployment
        $rollback_deployment_id = $this->logger->log_deployment(array(
            'fetchpress_id' => $deployment->fetchpress_id,
            'type' => $deployment->type,
            'identifier' => $deployment->identifier,
            'status' => 'pending',
            'version_before' => $deployment->version_after, // Current version becomes "before"
            'version_after' => $deployment->version_before, // Rolling back to previous version
            'triggered_by' => 'rollback',
        ));

        // Store current state as artifact before rollback
        $new_artifact_path = $this->artifact_manager->store_artifact(
            $deployment->identifier,
            $deployment->type,
            $rollback_deployment_id
        );

        if ($new_artifact_path) {
            $this->logger->update_artifact_path($rollback_deployment_id, $new_artifact_path);
        }

        // For plugins, deactivate first if active
        $was_active = false;
        $was_network_active = false;
        if ($deployment->type === 'plugin') {
            include_once(ABSPATH . 'wp-admin/includes/plugin.php');
            $was_active = is_plugin_active($deployment->identifier);
            $was_network_active = is_plugin_active_for_network($deployment->identifier);
            if ($was_active) {
                deactivate_plugins($deployment->identifier, true);
            }
        }

        // Delete current files
        if (is_dir($destination)) {
            $this->delete_directory($destination);
        }

        // Extract artifact
        if (!$this->artifact_manager->extract_artifact($artifact_path, $destination)) {
            $this->logger->update_status($rollback_deployment_id, 'failed', 'Failed to extract artifact.');

            $this->notice_handler->add(
                'rollback_extract_failed',
                'Rollback Failed',
                'Failed to extract the rollback artifact.',
                array('type' => 'error')
            );
            $this->notice_handler->boot();
            return false;
        }

        // Reactivate plugin if it was active
        if ($deployment->type === 'plugin' && $was_active) {
            activate_plugin($deployment->identifier, null, $was_network_active, true);
        }

        // Update original deployment status
        $this->logger->update_status($deployment_id, 'rolled_back');

        // Update rollback deployment status
        $this->logger->update_status($rollback_deployment_id, 'success');

        $item_name = $deployment->type === 'plugin' ? 'plugin' : 'theme';
        $this->notice_handler->add(
            'rollback_success',
            'Rollback Successful',
            sprintf('Your %s has been rolled back to version %s.', $item_name, $deployment->version_before ?: 'previous'),
            array('type' => 'success')
        );
        $this->notice_handler->boot();

        return true;
    }

    /**
     * Recursively delete a directory
     *
     * @param string $dir Directory path
     * @return bool Success
     */
    private function delete_directory($dir)
    {
        if (!is_dir($dir)) {
            return false;
        }

        $files = array_diff(scandir($dir), array('.', '..'));

        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            if (is_dir($path)) {
                $this->delete_directory($path);
            } else {
                wp_delete_file($path);
            }
        }

        return rmdir($dir);
    }
}
