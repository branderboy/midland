<?php

namespace FetchPress\Database;

if ( ! defined( 'ABSPATH' ) ) exit;

include_once(ABSPATH . 'wp-admin/includes/theme.php');
include_once(ABSPATH . 'wp-admin/includes/file.php');
include_once(ABSPATH . 'wp-admin/includes/class-wp-upgrader.php');
include_once(ABSPATH . 'wp-admin/includes/misc.php');

use \WPTRT\AdminNotices\Notices;
use FetchPress\Models\Theme;
use FetchPress\Repo\GithubHandler;
use FetchPress\Repo\BitbucketHandler;
use FetchPress\Repo\GitLabHandler;
use Theme_Upgrader;
use FetchPress\Database\ThemeSkin;
use stdClass;

class ThemeStore extends Theme_Upgrader
{

    /**
     * responsible for storing the theme in the db and downloading the code from vc
     *
     * @since    1.0.0
     * @access   protected
     * @var      AddTheme    $theme    Repo info from AddTheme event
     */

    public $theme;

    public function __construct()
    {
        $this->notice_handler = new Notices();
        $this->github_handler = new GithubHandler();
        $this->bitbucket_handler = new BitbucketHandler();
        $this->gitlab_handler = new GitLabHandler();
    }

    public function save($theme)
    {
        $this->theme = $theme;

        //skip download if theme already installed
        if (!$this->theme->linktoexisting) {
            $install_result = $this->download_theme($this->theme);
            if (!$install_result || is_wp_error($install_result)) {
                $error_message = is_wp_error($install_result) ? $install_result->get_error_message() : 'This theme might already be installed. Otherwise, check your repository path and subfolder.';
                $this->notice_handler->add('theme_install_failure', 'There was a problem installing your theme', $error_message, array('type' => 'error'));
                $this->notice_handler->boot();
                return false;
            }
        }

        $split_theme_title = explode('/', $this->theme->repository);
        $theme_title = end($split_theme_title);
        if ($this->theme->subdirectory) {
            $split_theme_title = explode('/', $this->theme->subdirectory);
            $theme_title = end($split_theme_title);
        }


        global $wpdb;

        $table_title = $wpdb->prefix . 'fetchpress';

        $theme = array(
            'title' => $theme_title,
            'repository' => $this->theme->repository,
            'privaterepo' => $this->theme->privaterepo,
            'branch' => $this->theme->branch,
            'deployonpush' => $this->theme->deployonpush,
            'vcservice' => $this->theme->vcservice,
            'subdirectory' => $this->theme->subdirectory,
        );

        //Set webhook for specified version control
        $this->webhook_selector($theme);

        $db_success = $wpdb->insert(
            $table_title,
            $theme
        );

        if ($db_success) {
            $this->notice_handler->add('add_theme_success', 'Your theme "' . $this->theme->repository . '" was installed successfully', 'Go ahead and <a href="' . get_site_url() . '/wp-admin/themes.php">activate</a> it!', array('type' => 'success'));
        } else {
            $this->notice_handler->add('add_theme_failure', 'There was an issue installing your theme', 'This theme might already be installed.', array('type' => 'error'));
        }

        $this->notice_handler->boot();
    }

    public function edit($theme)
    {
        $this->theme = $theme;

        $split_theme_title = explode('/', $this->theme->repository);
        $theme_title = end($split_theme_title);
        if ($this->theme->subdirectory) {
            $split_theme_title = explode('/', $this->theme->subdirectory);
            $theme_title = end($split_theme_title);
        }

        //Set github webhook

        global $wpdb;

        $table_title = $wpdb->prefix . 'fetchpress';

        $theme = array(
            'title' => $theme_title,
            'repository' => $this->theme->repository,
            'privaterepo' => $this->theme->privaterepo,
            'branch' => $this->theme->branch,
            'deployonpush' => $this->theme->deployonpush,
            'vcservice' => $this->theme->vcservice,
            'subdirectory' => $this->theme->subdirectory,
        );

        //Set webhook for specified version control
        $this->webhook_selector($theme);

        $db_success = $wpdb->update(
            $table_title,
            $theme,
            array('title' => $theme_title)
        );

        if ($db_success) {
            $this->notice_handler->add('edit_theme_success', 'Your theme "' . $this->theme->repository . '" was updated successfully', '<a href="' . get_site_url() . '/wp-admin/admin.php?page=fetchpress-themes">Back to themes</a>', array('type' => 'success'));
        } else {
            $this->notice_handler->add('edit_theme_failure', 'There was an issue updating your theme', 'Check your updated repository path', array('type' => 'error'));
        }

        $this->notice_handler->boot();
    }

    public function update($stylesheet, $triggered_by = 'manual')
    {
        $theme = $this->get_theme_from_stylesheet($stylesheet);

        // Initialize deployment logging
        $logger = new DeploymentLogger();
        $artifact_manager = new ArtifactManager();

        // Get current version before upgrade
        $version_before = $theme->version ?? null;

        // Get FetchPress ID
        $fetchpress_id = $logger->get_fetchpress_id($stylesheet, 'theme');

        // Log deployment start
        $deployment_id = $logger->log_deployment(array(
            'fetchpress_id' => $fetchpress_id,
            'type' => 'theme',
            'identifier' => $stylesheet,
            'status' => 'pending',
            'version_before' => $version_before,
            'triggered_by' => $triggered_by,
        ));

        // Store artifact for potential rollback
        if ($deployment_id) {
            $artifact_path = $artifact_manager->store_artifact($stylesheet, 'theme', $deployment_id);
            if ($artifact_path) {
                $logger->update_artifact_path($deployment_id, $artifact_path);
            }
        }

        // Perform the upgrade
        $result = $this->upgrade_theme($theme);

        // Get new version after upgrade
        $theme_data = wp_get_theme($stylesheet);
        $version_after = $theme_data->get('Version') ?? null;

        // Update deployment status
        if ($result === true || !is_wp_error($result)) {
            if ($deployment_id) {
                $logger->update_status($deployment_id, 'success', null, $version_after);
            }
            $this->notice_handler->add('update_theme_success', 'Your theme "' . $theme->stylesheet . '" was upgraded successfully', ' ', array('type' => 'success'));
        } else {
            $error_message = is_wp_error($result) ? $result->get_error_message() : 'Unknown error occurred';
            if ($deployment_id) {
                $logger->update_status($deployment_id, 'failed', $error_message, $version_after);
            }
            $this->notice_handler->add('update_theme_fail', 'Your theme "' . $theme->stylesheet . '" could not be updated.', 'Error: ' . $error_message, array('type' => 'error'));
            $this->notice_handler->boot();
        }

        $this->notice_handler->boot();
    }

    public function download_theme($theme)
    {
        //returns true/WP_Error if installation was successful/failed

        $skin = new ThemeSkin();
        $upgrader = new Theme_Upgrader($skin);
        $this->theme = $theme;

        //add filter to assign correct theme folder name
        add_filter('upgrader_source_selection', array($this, 'upgrade_source_selection_callback'), 10, 3);
        $result = $upgrader->install($this->git_service_zip_selector($theme));

        //Check for errors from the skin
        if ($skin->get_error() && is_wp_error($skin->get_error())) {
            return $skin->get_error();
        }

        return $result;
    }

    public function upgrade_theme($theme)
    {
        //returns true/WP_Error if installation was successful/failed
        //Uses direct package installation with overwrite to avoid WordPress update transients

        $skin = new ThemeSkin();
        $upgrader = new Theme_Upgrader($skin);
        $this->theme = $theme;

        //add filter to assign correct theme folder name
        add_filter('upgrader_source_selection', array($this, 'upgrade_source_selection_callback'), 10, 3);

        //Install with overwrite flag to replace existing theme
        $result = $upgrader->install($this->git_service_zip_selector($theme), array('overwrite_package' => true));

        //Check for errors from the skin
        if ($skin->get_error() && is_wp_error($skin->get_error())) {
            return $skin->get_error();
        }

        return $result;
    }

    public function delete($id)
    {
        global $wpdb;

        $table_name = $wpdb->prefix . 'fetchpress';

        $wpdb->delete($table_name, array('id' => sanitize_text_field($id)));
    }

    public function delete_theme($stylesheet)
    {
        global $wpdb;
        $table_title = $wpdb->prefix . 'fetchpress';
        $wpdb->delete($table_title, array('title' => sanitize_text_field($stylesheet)));

        $this->notice_handler->add('delete_theme_success', 'Your theme "' . $stylesheet . '" has been unlinked', 'If you would like to remove the theme code, delete it <a href="' . get_site_url() . '/wp-admin/themes.php">here</a>.', array('type' => 'success'));
        $this->notice_handler->boot();
    }

    public function upgrade_source_selection_callback($source, $remote_source, $upgrader)
    {
        if (isset($this->theme->subdirectory)) {
            $source = trailingslashit($source) . trailingslashit($this->theme->subdirectory);
        }

        $newSource = trailingslashit($remote_source) . trailingslashit($this->theme->get_slug());

        global $wp_filesystem;

        if (!$wp_filesystem->move($source, $newSource, true))
            return new \WP_Error('fetchpress_subdirectory', "We couldn't find subdirectory in repository.");

        return $newSource;
    }

    public function set_transient_for_update($transient)
    {
        $options = array('package' => $this->git_service_zip_selector($this->theme));

        // If $transient doesn't exist - create it
        if (!$transient) {
            $transient = new stdClass;
        };

        $transient->response[$this->theme->stylesheet] = $options;

        return $transient;
    }

    public function get_all_themes()
    {
        global $wpdb;

        $table_name = $wpdb->prefix . 'fetchpress';

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Table name is constructed from trusted $wpdb->prefix, isplugin is a literal value
        $rows = $wpdb->get_results("SELECT * FROM $table_name WHERE isplugin = 0");

        $themes = array();

        foreach ($rows as $row) {

            // This is our time to do some cleaning up
            if (!file_exists(get_theme_root() . "/" . $row->title)) {
                $this->delete($row->id);
                continue;
            }

            $object = wp_get_theme($row->title);
            $themes[$row->title] = Theme::map_from_wp_theme_object($object);
            $themes[$row->title]->branch = $row->branch;
            $themes[$row->title]->repository = $row->repository;
            $themes[$row->title]->deployonpush = $row->deployonpush;
            $themes[$row->title]->privaterepo = $row->privaterepo;
            $themes[$row->title]->vcservice = $row->vcservice;
            $themes[$row->title]->subdirectory = $row->subdirectory;
        }

        return $themes;
    }

    public function get_theme_from_stylesheet($stylesheet)
    {
        global $wpdb;

        $table_name = $wpdb->prefix . 'fetchpress';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE isplugin = 0 AND title = %s", $stylesheet));

        if (!$row or !file_exists(get_theme_root() . "/" . $stylesheet)) {
            $this->notice_handler->add('theme_fromstylesheet_failure', 'The theme could not be found.', '', array('type' => 'error'));
            $this->notice_handler->boot();
        }

        $data = wp_get_theme($stylesheet);

        $theme = Theme::map_from_wp_theme_object($data);
        $theme->branch = $row->branch;
        $theme->repository = $row->repository;
        $theme->vcservice = $row->vcservice;
        $theme->deployonpush = $row->deployonpush;
        $theme->subdirectory = $row->subdirectory;
        $theme->privaterepo = $row->privaterepo;

        return $theme;
    }

    public function git_service_zip_selector($theme)
    {
        switch ($theme->vcservice) {
            case 'github':
                return $this->github_handler->get_zip_data_url($theme);
            case 'bitbucket':
                return $this->bitbucket_handler->get_zip_data_url($theme);
            case 'gitlab':
                return $this->gitlab_handler->get_zip_data_url($theme);
        }
    }

    public function webhook_selector($theme)
    {
        switch ($theme['vcservice']) {
            case 'github':
                return $this->github_handler->set_webhook($theme, false);
            case 'bitbucket':
                return $this->bitbucket_handler->set_webhook($theme, false);
            case 'gitlab':
                // return $this->gitlab_handler->set_webhook($theme);
        }
    }
}
