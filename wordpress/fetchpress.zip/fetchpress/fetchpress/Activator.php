<?php

/**
 * Fired during plugin activation
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    FetchPress
 * @subpackage FetchPress/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    FetchPress
 * @subpackage FetchPress/includes
 * @author     Your Name <email@example.com>
 */
class FetchPress_Activator {

	/**
	 * Runs on plugin activation.
	 *
	 * Deactivates Lite version if present, generates webhook secret, and sets up activation notice.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		// Deactivate Lite version if active
		include_once ABSPATH . 'wp-admin/includes/plugin.php';
		if ( is_plugin_active( 'fetchpress-lite/fetchpress-lite.php' ) ) {
			deactivate_plugins( 'fetchpress-lite/fetchpress-lite.php' );
			add_option( 'fetchpress_upgraded_from_lite', true );
		}

		// Generate webhook secret if it doesn't exist
		if (!get_option('fetchpress_webhook_secret')) {
			add_option('fetchpress_webhook_secret', wp_generate_password(32, false));
		}

		// Add activation notice flag
		add_option('fetchpress_activation_notice', true);

		// Add version option for future migrations
		add_option('fetchpress_version', FETCHPRESS_VERSION);
		add_option('fetchpress_installed', time());
	}

}
