<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    FetchPress
 * @subpackage FetchPress/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    FetchPress
 * @subpackage FetchPress/includes
 * @author     Your Name <email@example.com>
 */

namespace FetchPress;

use FetchPress\Database\Database;
use FetchPress\Database\DeploymentLogger;
use FetchPress\Database\ArtifactManager;

class FetchPress
{

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      FetchPress_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $fetchpress    The string used to uniquely identify this plugin.
	 */
	protected $fetchpress;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct()
	{
		if (defined('FETCHPRESS_VERSION')) {
			$this->version = FETCHPRESS_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->fetchpress = 'fetchpress';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_setup_hooks();
		$this->define_cron_hooks();
	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - FetchPress_Loader. Orchestrates the hooks of the plugin.
	 * - FetchPress_i18n. Defines internationalization functionality.
	 * - FetchPress_Admin. Defines all hooks for the admin area.
	 * - FetchPress_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies()
	{
		// Load Composer’s autoloader
		require_once  plugin_dir_path(dirname(__FILE__)) . 'vendor/autoload.php';

		// Load PSR-4 autoloader for class importing
		require  plugin_dir_path(dirname(__FILE__)) . 'autoload.php';

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'fetchpress/Loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'fetchpress/Internationalization.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'fetchpress/Admin/fetchpress-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'fetchpress/Public/fetchpress-public.php';



		$this->loader = new FetchPress_Loader();
	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the FetchPress_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale()
	{

		$plugin_i18n = new FetchPress_i18n();

		$this->loader->add_action('plugins_loaded', $plugin_i18n, 'load_plugin_textdomain');
	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks()
	{

		$plugin_admin = new FetchPress_Admin($this->get_fetchpress(), $this->get_version());

		//enqueue admin settings page
		$this->loader->add_action('admin_init', $plugin_admin, 'register_admin_settings');

		$this->loader->add_action('admin_menu', $plugin_admin, 'register_admin_page');

		//enqueue scripts and styles
		$this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
		$this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts');

		//init plugin updater
		$this->loader->add_filter('site_transient_update_plugins', $plugin_admin, 'push_plugin_update');
		$this->loader->add_filter('plugins_api', $plugin_admin, 'register_plugin_info', 10, 3);

		// Add FetchPress badge to plugins list
		$this->loader->add_filter('plugin_row_meta', $plugin_admin, 'add_fetchpress_badge_to_plugin_row', 10, 4);

		// Clear subscription cache when activation key is added or updated
		$this->loader->add_action('add_option_fetchpress_token', $plugin_admin, 'clear_subscription_cache');
		$this->loader->add_action('update_option_fetchpress_token', $plugin_admin, 'clear_subscription_cache');
	}

	/**
	 * Setup DB, request handler
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_setup_hooks()
	{
		$db = new Database();
		$request_handler = new RequestHandler();
		$this->loader->add_action('admin_init', $db, 'install');
		$this->loader->add_action('admin_init', $request_handler, 'handle_request');
		$this->loader->add_action('init', $request_handler, 'handle_webhook');
	}

	/**
	 * Setup cron hooks for cleanup tasks
	 *
	 * @since    2.0.0
	 * @access   private
	 */
	private function define_cron_hooks()
	{
		// Schedule daily cleanup if not already scheduled
		$this->loader->add_action('init', $this, 'schedule_cleanup_cron');

		// Register the cleanup action
		$this->loader->add_action('fetchpress_daily_cleanup', $this, 'run_daily_cleanup');
	}

	/**
	 * Schedule the daily cleanup cron job
	 *
	 * @since    2.0.0
	 */
	public function schedule_cleanup_cron()
	{
		if (!wp_next_scheduled('fetchpress_daily_cleanup')) {
			wp_schedule_event(time(), 'daily', 'fetchpress_daily_cleanup');
		}
	}

	/**
	 * Run daily cleanup of old deployments and artifacts
	 *
	 * @since    2.0.0
	 */
	public function run_daily_cleanup()
	{
		// Get current subscription tier
		$admin = new FetchPress_Admin($this->get_fetchpress(), $this->get_version());
		$subscription = $admin->verify_subscription();
		$tier = $subscription['tier'] ?? 'free';

		// Clean up old deployment records
		$logger = new DeploymentLogger();
		$logger->cleanup_old_deployments($tier);

		// Clean up old artifact files
		$artifact_manager = new ArtifactManager();
		$artifact_manager->cleanup_old_artifacts($tier);
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run()
	{
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_fetchpress()
	{
		return $this->fetchpress;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    FetchPress_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader()
	{
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version()
	{
		return $this->version;
	}
}
