<?php

namespace FetchPress;

use FetchPress\Models\Theme;
use FetchPress\Database\ThemeStore;
use FetchPress\Models\Plugin;
use FetchPress\Database\PluginStore;
use FetchPress\Database\RollbackHandler;

class RequestHandler
{
  public function handle_request()
  {

    if (!isset($_POST['fetchpress'])) return; //early return if event param is missing

    if (!current_user_can('update_plugins') || !current_user_can('update_themes')) {
      wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'fetchpress'));
    }

    $request = wp_unslash($_POST['fetchpress']); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitization handled in individual cases

    switch ($request['event']) {
      case 'add-theme':
        check_admin_referer('add-theme');
        if (!$this->is_licensed()) {
          $theme_store = new ThemeStore();
          if (count($theme_store->get_all_themes()) >= 1) {
            wp_die(esc_html__('Free plan is limited to 1 theme. Purchase a license at fetch.press to add more.', 'fetchpress'));
          }
        }
        $theme = new Theme($request);
        $theme_store = new ThemeStore();
        $theme_store->save($theme);
        break;

      case 'edit-theme':
        check_admin_referer('edit-theme');
        $theme = new Theme($request);
        $theme_store = new ThemeStore();
        $theme_store->edit($theme);
        break;

      case 'update-theme':
        check_admin_referer('update-theme');
        $theme_store = new ThemeStore();
        $theme_store->update($request['stylesheet']);
        break;

      case 'delete-theme':
        check_admin_referer('delete-theme');
        $theme_store = new ThemeStore();
        $theme_store->delete_theme($request['stylesheet']);
        break;

      case 'add-plugin':
        check_admin_referer('add-plugin');
        if (!$this->is_licensed()) {
          $plugin_store = new PluginStore();
          if (count($plugin_store->get_all_plugins()) >= 1) {
            wp_die(esc_html__('Free plan is limited to 1 plugin. Purchase a license at fetch.press to add more.', 'fetchpress'));
          }
        }
        $plugin = new Plugin($request);
        $plugin_store = new PluginStore();
        $plugin_store->save($plugin);
        break;

      case 'update-plugin':
        check_admin_referer('update-plugin');
        $plugin_store = new PluginStore();
        $plugin_store->update($request['file']);
        break;

      case 'edit-plugin':
        $plugin = new Plugin($request);
        $plugin_store = new PluginStore();
        $plugin_store->edit($plugin);
        break;

      case 'delete-plugin':
        check_admin_referer('delete-plugin');
        $plugin_store = new PluginStore();
        $plugin_store->delete_plugin($request['file']);
        break;

      case 'rollback-plugin':
        check_admin_referer('rollback-plugin');
        $features = $this->get_subscription_features();
        $rollback_handler = new RollbackHandler();
        $rollback_handler->rollback(absint($request['deployment_id']), $features);
        break;

      case 'rollback-theme':
        check_admin_referer('rollback-theme');
        $features = $this->get_subscription_features();
        $rollback_handler = new RollbackHandler();
        $rollback_handler->rollback(absint($request['deployment_id']), $features);
        break;

      default:
        break;
    }
  }

  private function is_licensed()
  {
    $admin = new FetchPress_Admin('fetchpress', FETCHPRESS_VERSION);
    $subscription = $admin->verify_subscription();
    return $subscription['active'] ?? false;
  }

  /**
   * Get subscription features for rollback checks
   *
   * @return array Features array
   */
  private function get_subscription_features()
  {
    $admin = new FetchPress_Admin('fetchpress', FETCHPRESS_VERSION);
    $subscription = $admin->verify_subscription();
    return $subscription['features'] ?? array();
  }

  public function handle_webhook()
  {
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Webhook from external source, nonce not applicable
    if (!isset($_GET['fetchpress-hook']))
      return;

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Webhook from external source, nonce not applicable
    if (isset($_GET['package'])) {
      // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Base64 encoded data, validated after decode
      $package = base64_decode(wp_unslash($_GET['package']));
      // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Webhook from external source
      $isplugin = isset($_GET['isplugin']) ? sanitize_text_field(wp_unslash($_GET['isplugin'])) : false;

      //check payload to see if it's a plugin or a theme
      if ($isplugin) {
        $plugin_store = new PluginStore();
        $plugin = $plugin_store->get_plugin_from_file($package);
        //only update if deployonpush is enabled
        if ($plugin->deployonpush) {
          $plugin_store->update($package, 'webhook');
        }
      } else {
        $theme_store = new ThemeStore();
        $theme = $theme_store->get_theme_from_stylesheet($package);
        //only update if deployonpush is enabled
        if ($theme->deployonpush) {
          $theme_store->update($package, 'webhook');
        }
      }
    }
  }
}
