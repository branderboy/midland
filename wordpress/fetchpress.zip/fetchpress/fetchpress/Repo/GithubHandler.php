<?php

namespace FetchPress\Repo;

use \WPTRT\AdminNotices\Notices;

class GithubHandler
{
  public $notice_handler;

  public function __construct()
  {
    $this->notice_handler = new Notices();
  }

  public function get_zip_data_url($theme)
  {
    $link = 'https://api.github.com/repos/' . $theme->repository . '/zipball/' . urlencode($theme->branch) . '?dir=/fetchpress';

    if (!$theme->privaterepo) {
      return  $link;
    }

    add_filter('http_request_args', array($this, 'get_auth_token'), 10, 2);
    return $link;
  }

  public function get_auth_token($args)
  {
    $token = get_option('github_token');

    if (is_string($token) && $token === '') {
      $this->notice_handler->add('private_repo_failure', 'No Github token set', 'Please add your github token to request private repositories/', array('type' => 'error'));
      $this->notice_handler->boot();
    }

    $args['headers']['Authorization'] = "token {$token}";

    return $args;
  }

  public function get_deploy_on_push_url($theme_title, $isplugin)
  {
    $theme_title = base64_encode($theme_title);

    $url = sprintf(
      "%s?fetchpress-hook&token=%s&package=%s&isplugin=%s",
      trailingslashit(get_site_url()),
      get_option('fetchpress_token'),
      $theme_title,
      $isplugin
    );

    return esc_attr($url);
  }

  public function set_webhook($theme, $isplugin)
  {

    if (!$theme['deployonpush']) {
      return null;
    }

    $webhook_url = $this->get_deploy_on_push_url($theme['title'], $isplugin);

    $gh_token = get_option('github_token');

    $payload = json_encode(array(
      'name' => 'web',
      'active' => true,
      'config' => array(
        'url' => html_entity_decode($webhook_url),
      ),
    ));


    $url = "https://api.github.com/repos/{$theme['repository']}/hooks";

    $response = wp_remote_post($url, array(
      'body' => $payload,
      'headers' => array(
        'Content-Type' => 'application/json',
        'Authorization' => "token {$gh_token}",
      ),
    ));


    if ($response instanceof \WP_Error) {
      $this->notice_handler->add('webhook_setup_failure', 'The webhook could not be updated', 'Make sure a valid token for your version control is present.', array('type' => 'error'));
      $this->notice_handler->boot();
    }
  }
}
