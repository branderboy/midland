<?php

namespace FetchPress\Repo;

use \WPTRT\AdminNotices\Notices;

class GitLabHandler
{
  public $notice_handler;

  public function __construct()
  {
    $this->notice_handler = new Notices();
  }

  public function get_zip_data_url($theme)
  {
    //set default base url if empty
    $base = get_option('gl_base_url');
    if ($base === '') {
      $base = 'https://gitlab.com';
    }

    //If private checked use gitlab basic auth!
    if ($theme->privaterepo) {
      add_filter('http_request_args', array($this, 'gitlab_basic'), 10, 2);
    }
    $url = trailingslashit($base) . 'api/v4/projects/' . urlencode($theme->repository) . '/repository/archive.zip?sha=' . $theme->branch . '&dir=/fetchpress';

    return $url;
  }

  public function gitlab_basic($data)
  {
    //set default base url if empty
    $base = get_option('gl_base_url');
    if ($base === '') {
      $base = 'https://gitlab.com';
    }

    $token = get_option('gitlab_token');

    if ($token === '') {
      $this->notice_handler->add('gitlab_private_failure', 'The theme could not be installed', 'There is no GitLab Personal Access token set.', array('type' => 'error'));
      $this->notice_handler->boot();
    }

    $data['headers']['PRIVATE-TOKEN'] = $token;

    return $data;
  }
}
