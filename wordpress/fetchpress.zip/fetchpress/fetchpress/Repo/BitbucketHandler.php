<?php

namespace FetchPress\Repo;

use \WPTRT\AdminNotices\Notices;

class BitbucketHandler
{
  public $notice_handler;

  public function __construct()
  {
    $this->notice_handler = new Notices();
  }

  public function get_zip_data_url($theme)
  {
    $link = 'https://bitbucket.org/' . $theme->repository . '/get/' . urlencode($theme->branch) . '.zip?dir=/fetchpress';

    if (!$theme->privaterepo) {
      return  $link;
    }

    $token = get_option('bitbucket_token');

    // If token is present, use that to get the actual token ...
    if (is_string($token) and $token !== '') {
      $access_token = $this->refresh_access_token($token);

      return $link . '&access_token=' . $access_token;
    }
  }

  public function refresh_access_token($token)
  {
    $response = wp_remote_get("https://fetch.press/api/refreshBitbucketToken?token={$token}");

    if (is_wp_error($response) or empty($response)) {
      // Something went wrong
      return '';
    }

    $json = json_decode($response['body'], true);

    //if data doesn't exist early return
    if (!isset($json['data'])) {
      return '';
    }

    return $json['data'];
  }

  public function get_deploy_on_push_url($theme_title, $isplugin)
  {
    $theme_title = base64_encode($theme_title);

    $url = sprintf(
      "%s?fetchpress-hook&token=%s&package=%s&isplugin=%s",
      trailingslashit(get_site_url()),
      get_option('fetchpress_token'),
      $theme_title,
      $isplugin
    );

    return esc_attr($url);
  }

  public function set_webhook($theme, $isplugin)
  {

    if (!$theme['deployonpush']) {
      return null;
    }

    $hook_title = 'FetchPress:' . get_site_url();

    $webhook_url = $this->get_deploy_on_push_url($theme['title'], $isplugin);

    $token = get_option('bitbucket_token');

    //get refresh token from bitbucket token
    $refreshed_token = $this->refresh_access_token($token);

    // verify hook doesn't already exist
    $url = "https://api.bitbucket.org/2.0/repositories/{$theme['repository']}/hooks?access_token={$refreshed_token}";

    $response = wp_remote_get($url);

    if ($response instanceof \WP_Error) {
      $this->notice_handler->add('webhook_setup_failure', 'The webhook could not be updated', 'Make sure a valid token for your version control is present.', array('type' => 'error'));
      $this->notice_handler->boot();
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);

    // If hook exists early return
    foreach ($data['values'] as $webhook_value) {
      if ($webhook_value['description'] === $hook_title) {
        return null;
      }
    }

    // Proceed to set up a new webhook
    $payload = json_encode(array(
      'description' => $hook_title,
      'url' => html_entity_decode($webhook_url),
      'active' => true,
      'events' => array(
        'repo:push',
      ),
    ));

    $url = "https://api.bitbucket.org/2.0/repositories/{$theme['repository']}/hooks?access_token={$refreshed_token}";

    $response = wp_remote_post($url, array(
      'body' => $payload,
      'headers' => array(
        'Content-Type' => 'application/json',
      ),
    ));

    $http_code = wp_remote_retrieve_response_code($response);

    if ($http_code === 400) {
      $this->notice_handler->add('webhook_setup_failure', 'The webhook could not be updated (error 400)', 'Make sure a valid token for your version control is present.', array('type' => 'error'));
      $this->notice_handler->boot();
    }

    if ($response instanceof \WP_Error) {
      $this->notice_handler->add('webhook_setup_failure', 'The webhook could not be updated', 'Make sure a valid token for your version control is present.', array('type' => 'error'));
      $this->notice_handler->boot();
    }
  }
}
