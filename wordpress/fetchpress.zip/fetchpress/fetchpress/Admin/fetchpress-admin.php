<?php
namespace FetchPress;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    FetchPress
 * @subpackage FetchPress/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    FetchPress
 * @subpackage FetchPress/admin
 * @author     Your Name <email@example.com>
 */


use FetchPress\Database\ThemeStore;
use FetchPress\Database\PluginStore;
use \stdClass;

class FetchPress_Admin
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $fetchpress    The ID of this plugin.
	 */
	private $fetchpress;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $fetchpress       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */

	public function __construct($fetchpress, $version)
	{

		$this->fetchpress = $fetchpress;
		$this->version = $version;

		// $this->wp_deployer = new WP_Deployer();
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in FetchPress_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The FetchPress_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style($this->fetchpress, plugin_dir_url(__FILE__) . 'css/fetchpress-admin.css', array(), $this->version, 'all');
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in FetchPress_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The FetchPress_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script($this->fetchpress, plugin_dir_url(__FILE__) . 'js/fetchpress-admin.js', array('jquery'), $this->version, false);
	}

	function register_admin_page()
	{

		add_menu_page('FetchPress', 'FetchPress', 'manage_options', 'fetchpress', fn () => $this->render_admin_content('/partials/fetchpress-admin-display.php'), 'dashicons-arrow-down-alt');

		add_submenu_page('fetchpress', 'Add Theme', 'Add Theme', 'manage_options', 'fetchpress-add-theme', fn () => $this->render_admin_content('/partials/fetchpress-add-theme-display.php'));

		add_submenu_page('fetchpress', 'Themes', 'Themes', 'manage_options', 'fetchpress-themes', fn () => $this->render_admin_content('/partials/fetchpress-themes-display.php'));

		add_submenu_page('fetchpress', 'Add Plugin', 'Add Plugin', 'manage_options', 'fetchpress-add-plugin', fn () => $this->render_admin_content('/partials/fetchpress-add-plugin-display.php'));

		add_submenu_page('fetchpress', 'Plugins', 'Plugins', 'manage_options', 'fetchpress-plugins', fn () => $this->render_admin_content('/partials/fetchpress-plugins-display.php'));

		add_submenu_page('fetchpress', 'Deployment History', 'History', 'manage_options', 'fetchpress-history', fn () => $this->render_admin_content('/partials/fetchpress-history-display.php'));
	}

	function verify_subscription()
	{
		$token = get_option('fetchpress_token');
		if (empty($token)) {
			return $this->get_inactive_subscription();
		}

		// Check cache first
		$cached = get_transient('fetchpress_subscription_data');
		if ($cached !== false) {
			return $cached;
		}

		$site_url = get_site_url();
		$url = 'https://fetch.press/api/verifyFetchpressToken';
		$data = array(
			'token' => $token,
			'site_url' => $site_url,
			'plugin_version' => FETCHPRESS_VERSION,
			'action' => 'activate'
		);

		$response = wp_remote_post($url, array(
			'headers' => array('Content-Type' => 'application/json'),
			'body' => wp_json_encode($data),
			'timeout' => 15
		));

		if (is_wp_error($response)) {
			return $this->get_inactive_subscription();
		}

		$body = wp_remote_retrieve_body($response);
		$result = json_decode($body, true);

		// Handle legacy boolean response
		if (is_bool($result) || $result === 'true' || $result === 'false') {
			$is_active = ($result === true || $result === 'true');
			$result = array(
				'active' => $is_active,
				'tier' => $is_active ? 'pro' : null,
				'features' => $this->get_legacy_features($is_active),
				'siteLimit' => array('allowed' => $is_active, 'current' => 0, 'limit' => -1)
			);
		}

		// Cache for 1 hour
		set_transient('fetchpress_subscription_data', $result, HOUR_IN_SECONDS);

		return $result;
	}

	function get_inactive_subscription()
	{
		return array(
			'active' => false,
			'tier' => null,
			'features' => array(
				'privateRepos' => false,
				'whiteLabelMode' => false
			),
			'siteLimit' => array('allowed' => false, 'current' => 0, 'limit' => 0)
		);
	}

	function get_legacy_features($is_active)
	{
		if (!$is_active) {
			return array('privateRepos' => false, 'whiteLabelMode' => false);
		}
		return array('privateRepos' => true, 'whiteLabelMode' => false);
	}

	function clear_subscription_cache()
	{
		delete_transient('fetchpress_subscription_data');
	}

	function render_admin_content($template_path)
	{
		// this function initializes admin settings page

		//pass theme data to admin pages
		$data = array();
		$theme_instance = new ThemeStore();
		$plugin_instance = new PluginStore();
		$data['themes'] = $theme_instance->get_all_themes();
		$data['plugins'] = $plugin_instance->get_all_plugins();

		// Enhanced subscription data
		$subscription = $this->verify_subscription();
		$data['subscription'] = $subscription;
		$is_active = $subscription['active'] ?? false;
		$data['subscription_active'] = $is_active ? 'true' : 'false';

		// Normalize all paid tiers to 'pro' — starter/agency/legacy were previous paid plans
		$raw_tier = $subscription['tier'] ?? null;
		$paid_tiers = array('pro', 'starter', 'agency', 'legacy');
		$data['tier'] = ($is_active && in_array($raw_tier, $paid_tiers, true)) ? 'pro' : $raw_tier;

		$data['features'] = $subscription['features'] ?? array();

		// Pro has unlimited sites; normalize any legacy site limit
		$site_limit = $subscription['siteLimit'] ?? array('allowed' => false, 'current' => 0, 'limit' => 0);
		if ($is_active) {
			$site_limit['limit'] = -1;
		}
		$data['site_limit'] = $site_limit;

		extract($data);
		return include __DIR__ . $template_path;
	}


	function register_admin_settings()
	{
		// this function initializes admin settings fields
		add_option('fetchpress_token', '');
		register_setting('fetchpress_settings', 'fetchpress_token', 'admin_ui_callback');

		add_option('github_token', '');
		register_setting('github_settings', 'github_token', 'admin_ui_callback');

		add_option('bitbucket_token', '');
		register_setting('bitbucket_settings', 'bitbucket_token', 'admin_ui_callback');

		add_option('gitlab_base_url', '');
		register_setting('gitlab_settings', 'gitlab_base_url', 'admin_ui_callback');

		add_option('gitlab_token', '');
		register_setting('gitlab_settings', 'gitlab_token', 'admin_ui_callback');
	}

	function register_plugin_info($res, $action, $args)
	{
		// do nothing if this is not about getting plugin information
		if ('plugin_information' !== $action) {
			return $res;
		}

		// do nothing if it is not our plugin
		if ('fetchpress' !== $args->slug) {
			return $res;
		}

		// info.json is the file with the actual plugin information on your server
		$remote = wp_remote_get(
			'https://fetch.press/plugin-dist/info.json',
			array(
				'timeout' => 10,
				'headers' => array(
					'Accept' => 'application/json'
				)
			)
		);

		// do nothing if we don't get the correct response from the server
		if (is_wp_error($remote) || 200 !== wp_remote_retrieve_response_code($remote) || empty(wp_remote_retrieve_body($remote))) {
			return $res;
		}

		$remote = json_decode(wp_remote_retrieve_body($remote));
		$res = new stdClass();
		$res->name = $remote->name;
		$res->slug = $remote->slug;
		$res->author = $remote->author;
		$res->author_profile = $remote->author_profile;
		$res->version = $remote->version;
		$res->tested = $remote->tested;
		$res->requires = $remote->requires;
		$res->requires_php = $remote->requires_php;
		$res->download_link = $remote->download_url;
		$res->trunk = $remote->download_url;
		$res->last_updated = $remote->last_updated;
		$res->sections = array(
			'description' => $remote->sections->description,
			'installation' => $remote->sections->installation,
			'changelog' => $remote->sections->changelog
			// you can add your custom sections (tabs) here
		);
		// in case you want the screenshots tab, use the following HTML format for its content:
		// <ol><li><a href="IMG_URL" target="_blank"><img src="IMG_URL" alt="CAPTION" /></a><p>CAPTION</p></li></ol>
		if (!empty($remote->sections->screenshots)) {
			$res->sections['screenshots'] = $remote->sections->screenshots;
		}

		$res->banners = array(
			'low' => $remote->banners->low,
			'high' => $remote->banners->high
		);

		return $res;
	}

	function add_fetchpress_badge_to_plugin_row($plugin_meta, $plugin_file, $plugin_data, $status)
	{
		$plugin_store = new PluginStore();
		$fetchpress_plugins = $plugin_store->get_all_plugins();

		// Check if this plugin was downloaded with FetchPress (key is the plugin file path)
		if (isset($fetchpress_plugins[$plugin_file])) {
			$badge_url = esc_url(plugin_dir_url(__FILE__) . 'assets/badge.svg');
			$manage_url = esc_url(admin_url('admin.php?page=fetchpress-plugins'));

			$plugin_meta[] = '<a href="' . $manage_url . '" class="fetchpress-plugin-badge"><img src="' . $badge_url . '" alt="FetchPress" style="width: 14px; height: 14px; vertical-align: middle; margin-right: 3px;">Manage in FetchPress</a>';
		}

		return $plugin_meta;
	}

	function push_plugin_update($transient)
	{

		if (empty($transient->checked)) {
			return $transient;
		}

		$remote = wp_remote_get(
			'https://fetch.press/plugin-dist/info.json',
			array(
				'timeout' => 10,
				'headers' => array(
					'Accept' => 'application/json'
				)
			)
		);

		if (
			is_wp_error($remote)
			|| 200 !== wp_remote_retrieve_response_code($remote)
			|| empty(wp_remote_retrieve_body($remote))
		) {
			return $transient;
		}

		$remote = json_decode(wp_remote_retrieve_body($remote));

		// your installed plugin version should be on the line below! You can obtain it dynamically of course
		if (
			$remote
			&& version_compare($this->version, $remote->version, '<')
			&& version_compare($remote->requires, get_bloginfo('version'), '<')
			&& version_compare($remote->requires_php, PHP_VERSION, '<')
		) {
			$res = new stdClass();
			$res->slug = $remote->slug;
			$res->plugin = 'fetchpress/fetchpress.php'; // it could be just YOUR_PLUGIN_SLUG.php if your plugin doesn't have its own directory
			$res->new_version = $remote->version;
			$res->tested = $remote->tested;
			$res->package = $remote->download_url;
			$transient->response[$res->plugin] = $res;

			$transient->checked[$res->plugin] = $remote->version;
		}


		return $transient;
	}
}
