<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    FetchPress
 * @subpackage FetchPress/admin/partials
 */

if (!defined('ABSPATH')) exit; // Exit if accessed directly
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<?php settings_errors(); ?>

<div class="fetchpress-add-theme fetchpress-themes">
  <div class="hero" style="background-image: url(<?php echo esc_url(plugin_dir_url(__FILE__) . '../assets/global-bg.png'); ?>);">
    <img class="logo" src="<?php echo esc_url(plugin_dir_url(__FILE__) . '../assets/logo.svg'); ?>" alt="">
    <hr>
    <h3>Welcome to FetchPress!</h3>
    <p>Please add your keys for Github, Bitbucket, or Gitlab below depending on your needs.</p>
  </div>

  <?php
  $default_tab = null;
  $tab = isset($_GET['tab']) ? preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['tab']) : $default_tab;
  ?>
  <nav class="nav-tab-wrapper">
    <a href="?page=fetchpress" class="nav-tab <?php if ($tab === null) : ?>nav-tab-active<?php endif; ?>">Activation</a>
    <a href="?page=fetchpress&tab=github" class="nav-tab <?php if ($tab === 'github') : ?>nav-tab-active<?php endif; ?>">GitHub</a>
    <a href="?page=fetchpress&tab=bitbucket" class="nav-tab <?php if ($tab === 'bitbucket') : ?>nav-tab-active<?php endif; ?>">BitBucket</a>
    <a href="?page=fetchpress&tab=gitlab" class="nav-tab <?php if ($tab === 'gitlab') : ?>nav-tab-active<?php endif; ?>">GitLab</a>
  </nav>

  <?php switch ($tab):
    case 'github':
  ?>
      <form method="post" action="options.php">
        <?php wp_nonce_field('update-tokens'); ?>
        <input type="hidden" name="fetchpress[event]" value="update-tokens">
        <?php settings_fields('github_settings'); ?>
        <label for="github_token">Github Token</label>
        <input type="password" id="github_token" name="github_token" value="<?php echo esc_attr(get_option('github_token')); ?>" />
        <button class="button" onclick="window.open('https://github.com/login/oauth/authorize?client_id=19cd8da89f0c49a3efd0&redirect_uri=https://fetch.press/auth/callback&scope=repo&allow_signup=true', 'newwindow', 'width=800,height=800'); return false;">Get Github Token</button>
        <?php submit_button(); ?>
      </form>
    <?php
      break;
    case 'bitbucket':
    ?>
      <form method="post" action="options.php">
        <?php wp_nonce_field('update-tokens'); ?>
        <input type="hidden" name="fetchpress[event]" value="update-tokens">
        <?php settings_fields('bitbucket_settings'); ?>
        <label for="bitbucket_token">Bitbucket Token</label>
        <input type="password" id="bitbucket_token" name="bitbucket_token" value="<?php echo esc_attr(get_option('bitbucket_token')); ?>" />
        <button class="button" onclick="window.open('https://bitbucket.org/site/oauth2/authorize?client_id=gVeDmKM8ULEdtdd2vM&response_type=code', 'newwindow', 'width=800,height=800'); return false;">Get Bitbucket Token</button>
        <?php submit_button(); ?>
      </form>
    <?php
      break;
    case 'gitlab':
    ?>
      <form method="post" action="options.php">
        <?php wp_nonce_field('update-tokens'); ?>
        <input type="hidden" name="fetchpress[event]" value="update-tokens">
        <?php settings_fields('gitlab_settings'); ?>
        <label for="gitlab_token">GitLab</label>
        <div class="fetchpress__input-group">
          <label for="gitlab_token">GitLab Base Url (Defaults to https://gitlab.com)</label>
          <input type="text" placeholder="GitLab Base Url" id="gitlab_base_url" name="gitlab_base_url" value="<?php echo esc_attr(get_option('gitlab_base_url')); ?>" />
          <label for="gitlab_token">GitLab Personal Access Token</label>
          <input type="password" placeholder="GitLab Personal Access Token" id="gitlab_token" name="gitlab_token" value="<?php echo esc_attr(get_option('gitlab_token')); ?>" />
        </div>
        <?php submit_button(); ?>
      </form>
    <?php
      break;
    default:
    ?>
      <form method="post" action="options.php">
        <?php wp_nonce_field('update-tokens'); ?>
        <input type="hidden" name="fetchpress[event]" value="update-tokens">
        <?php settings_fields('fetchpress_settings'); ?>
        <label for="fetchpress_token">FetchPress Activation Key</label>
        <input type="password" id="fetchpress_token" name="fetchpress_token" value="<?php echo esc_attr(get_option('fetchpress_token')); ?>" />
        <?php if ($subscription_active === 'true') : ?>
          <div class="fetchpress-tier-info">
            <h3><?php echo esc_html(ucfirst($tier ?? 'Active')); ?> Plan</h3>
            <?php if (isset($site_limit['limit']) && $site_limit['limit'] !== -1) : ?>
              <p class="site-usage">
                <strong>Sites:</strong>
                <?php echo esc_html($site_limit['current']); ?> / <?php echo esc_html($site_limit['limit']); ?> activated
              </p>
              <div class="fetchpress-usage-bar">
                <?php
                $percent = $site_limit['limit'] > 0 ? ($site_limit['current'] / $site_limit['limit']) * 100 : 0;
                $bar_class = $percent >= 90 ? 'critical' : ($percent >= 70 ? 'warning' : '');
                ?>
                <div class="fetchpress-usage-bar-fill <?php echo esc_attr($bar_class); ?>" style="width: <?php echo esc_attr(min(100, $percent)); ?>%"></div>
              </div>
            <?php elseif (isset($site_limit['limit']) && $site_limit['limit'] === -1) : ?>
              <p class="site-usage"><strong>Sites:</strong> Unlimited</p>
            <?php endif; ?>

            <!-- <ul class="fetchpress-feature-list">
              <li class="<?php echo ($features['privateRepos'] ?? false) ? 'enabled' : 'disabled'; ?>">
                Private Repositories
              </li>
              <li class="<?php echo ($features['rollback'] ?? false) ? 'enabled' : 'disabled'; ?>">
                Deployment Rollback
              </li>
              <li class="<?php echo ($features['buildProcess'] ?? false) ? 'enabled' : 'disabled'; ?>">
                Build Process Support
              </li>
              <li class="<?php echo ($features['whiteLabelMode'] ?? false) ? 'enabled' : 'disabled'; ?>">
                White-Label Mode
              </li>
            </ul> -->

            <p><a href="https://fetch.press/account" target="_blank">Manage Subscription</a></p>
          </div>
        <?php else : ?>
          <p><strong>Need a license?</strong> Purchase one at <a href="https://fetch.press/" target="_blank">fetch.press</a></p>
        <?php endif ?>
        <?php submit_button(); ?>
      </form>
  <?php
      break;
  endswitch; ?>
</div>

<?php if (!($features['whiteLabelMode'] ?? false)) : ?>
<div class="fetchpress-footer">
  <img class="badge" src="<?php echo esc_url(plugin_dir_url(__FILE__) . '../assets/badge.svg'); ?>" alt="">
  <p>Copyright © <?php echo esc_html(date('Y')); ?> <a href="https://fetch.press" target="_blank">FetchPress</a></p>
</div>
<?php endif; ?>