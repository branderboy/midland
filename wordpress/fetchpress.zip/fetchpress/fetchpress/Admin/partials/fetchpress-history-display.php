<?php

/**
 * Deployment History display
 *
 * @link       http://example.com
 * @since      2.0.0
 *
 * @package    FetchPress
 * @subpackage FetchPress/admin/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

use FetchPress\Database\DeploymentLogger;
use FetchPress\Database\RollbackHandler;

// Check if user has a valid license
$has_license = ($subscription_active === 'true');
?>

<div class="fetchpress-themes fetchpress-history">
    <h1>Deployment History</h1>

    <?php if (!$has_license) : ?>
        <div class="fetchpress-upgrade-prompt">
            <div class="fetchpress-upgrade-icon">
                <span class="dashicons dashicons-backup"></span>
            </div>
            <h2>Deployment History & Rollback</h2>
            <p>Track all your deployments and easily rollback to previous versions if something goes wrong.</p>
            <ul>
                <li><span class="dashicons dashicons-yes"></span> Full deployment history</li>
                <li><span class="dashicons dashicons-yes"></span> One-click rollback</li>
                <li><span class="dashicons dashicons-yes"></span> Version tracking</li>
            </ul>
            <a style="line-height: normal;" href="https://fetch.press#pricing" target="_blank" class="button button-primary button-hero">Get a License Key</a>
        </div>
    <?php else :
        $logger = new DeploymentLogger();
        $rollback_handler = new RollbackHandler();

        // Get filter parameters
        $filter_type = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';
        $filter_identifier = isset($_GET['identifier']) ? sanitize_text_field($_GET['identifier']) : '';

        // Get deployment history based on filters
        if ($filter_identifier && $filter_type) {
            $deployments = $logger->get_history($filter_identifier, $filter_type, $tier ?? 'free');
        } else {
            $deployments = $logger->get_all_history($tier ?? 'free');
        }

        // Get retention info for display
        $retention_days = $logger->get_retention_days($tier ?? 'free');
        $retention_text = $retention_days < 0 ? 'unlimited' : $retention_days . ' days';

        // Rollback is available to all licensed users
        $rollback_enabled = true;
    ?>

        <div class="fetchpress-history-info">
            <p>
                <strong>History Retention:</strong> <?php echo esc_html($retention_text); ?>
            </p>
        </div>

        <?php if ($filter_identifier) : ?>
            <div class="fetchpress-history-filter">
                <p>
                    Showing history for: <strong><?php echo esc_html($filter_identifier); ?></strong>
                    (<a href="<?php echo esc_url(admin_url('admin.php?page=fetchpress-history')); ?>">View all</a>)
                </p>
            </div>
        <?php endif; ?>

        <?php if (empty($deployments)) : ?>
            <div class="fetchpress-empty-state">
                <p>No deployment history found.</p>
                <p>Deployment history will appear here after you update plugins or themes via FetchPress.</p>
            </div>
        <?php else : ?>
            <table class="fetchpress-history-table wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th class="column-date">Date</th>
                        <th class="column-item">Plugin/Theme</th>
                        <th class="column-version">Version</th>
                        <th class="column-status">Status</th>
                        <th class="column-trigger">Triggered By</th>
                        <th class="column-actions">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($deployments as $deployment) : ?>
                        <?php
                        $can_rollback = $rollback_handler->can_rollback($deployment->id, $features);
                        $status_class = 'status-' . sanitize_html_class($deployment->status);
                        $version_change = '';
                        if ($deployment->version_before && $deployment->version_after) {
                            $version_change = $deployment->version_before . ' → ' . $deployment->version_after;
                        } elseif ($deployment->version_after) {
                            $version_change = '→ ' . $deployment->version_after;
                        } elseif ($deployment->version_before) {
                            $version_change = $deployment->version_before . ' →';
                        }
                        ?>
                        <tr>
                            <td class="column-date">
                                <?php echo esc_html(wp_date('M j, Y g:i a', strtotime($deployment->deployed_at))); ?>
                            </td>
                            <td class="column-item">
                                <strong><?php echo esc_html($deployment->identifier); ?></strong>
                                <span class="item-type"><?php echo esc_html(ucfirst($deployment->type)); ?></span>
                            </td>
                            <td class="column-version">
                                <?php echo esc_html($version_change ?: '-'); ?>
                            </td>
                            <td class="column-status">
                                <span class="fetchpress-status <?php echo esc_attr($status_class); ?>">
                                    <?php echo esc_html(ucfirst(str_replace('_', ' ', $deployment->status))); ?>
                                </span>
                                <?php if ($deployment->error_message) : ?>
                                    <span class="error-tooltip" title="<?php echo esc_attr($deployment->error_message); ?>">
                                        <span class="dashicons dashicons-warning"></span>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="column-trigger">
                                <?php echo esc_html(ucfirst($deployment->triggered_by)); ?>
                            </td>
                            <td class="column-actions">
                                <?php if ($rollback_enabled && $can_rollback['can_rollback']) : ?>
                                    <form action="" method="POST" class="rollback-form" onsubmit="return confirm('Are you sure you want to rollback to version <?php echo esc_attr($deployment->version_before ?: 'previous'); ?>?');">
                                        <?php wp_nonce_field('rollback-' . $deployment->type); ?>
                                        <input type="hidden" name="fetchpress[event]" value="rollback-<?php echo esc_attr($deployment->type); ?>">
                                        <input type="hidden" name="fetchpress[deployment_id]" value="<?php echo esc_attr($deployment->id); ?>">
                                        <button type="submit" class="button button-small fetchpress-rollback-btn">
                                            <span class="dashicons dashicons-undo"></span> Rollback
                                        </button>
                                    </form>
                                <?php elseif ($rollback_enabled && $deployment->status === 'success') : ?>
                                    <span class="rollback-unavailable" title="<?php echo esc_attr($can_rollback['reason']); ?>">
                                        <span class="dashicons dashicons-no"></span>
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php if (!($features['whiteLabelMode'] ?? false)) : ?>
    <div class="fetchpress-footer">
        <img class="badge" src="<?php echo esc_url(plugin_dir_url(__FILE__) . '../assets/badge.svg'); ?>" alt="">
        <p>Copyright &copy; <?php echo esc_html(date('Y')); ?> <a href="https://fetch.press" target="_blank">FetchPress</a></p>
    </div>
<?php endif; ?>