<?php

/**
 * Add theme form HTML
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    FetchPress
 * @subpackage FetchPress/admin/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
  die;
}

function get_theme_from_param($themes)
{
  if (!isset($_GET['title'])) {
    return false;
  }

  foreach ($themes as $theme) {
    if ($theme->stylesheet === $_GET['title']) {
      return $theme;
    }
  }
}

function is_theme_active($theme)
{
  $current_theme = wp_get_theme(); // gets the current theme
  return ($theme->name == $current_theme->name || $theme->stylesheet == $current_theme->parent_theme);
}
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<!-- Check if theme param exists. If so show edit form, otherwise list themes -->
<?php if (!isset($_GET['title']) && !get_theme_from_param($themes)) : ?>
  <div class="fetchpress-themes">
    <h1>Themes</h1>
    <div class="fetchpress__theme-list">
      <?php foreach ($themes as $theme) : ?>
        <div class="fetchpress__theme-card <?php echo is_theme_active($theme) ? 'fetchpress__theme-card--active' : '' ?>">
          <h3><?php echo esc_html($theme->name); ?></h3>
          <p><?php echo esc_html($theme->repository); ?></p>
          <ul>
            <li><strong>Version Control:</strong> <?php echo esc_html($theme->vcservice); ?></li>
            <li><strong>Branch:</strong> <?php echo esc_html($theme->branch); ?></li>
            <li><strong>Deploy on push:</strong> <span class="<?php echo esc_attr($theme->deployonpush === '1' ? 'green' : 'red'); ?>"><?php echo esc_html($theme->deployonpush === '1' ? 'Enabled' : 'Disabled'); ?></span></li>
          </ul>
          <div class="fetchpress__button-row">
            <form action="" method="POST">
              <?php wp_nonce_field('update-theme'); ?>
              <input type="hidden" name="fetchpress[event]" value="update-theme">
              <input type="hidden" name="fetchpress[repository]" value="<?php echo esc_attr($theme->repository); ?>">
              <input type="hidden" name="fetchpress[stylesheet]" value="<?php echo esc_attr($theme->stylesheet); ?>">
              <?php submit_button('Update Theme'); ?>
            </form>
            <a href="<?php echo esc_url(home_url() . '/wp-admin/admin.php?page=fetchpress-themes&title=' . urlencode($theme->stylesheet)); ?>" class="button">Edit Theme</a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=fetchpress-history&type=theme&identifier=' . urlencode($theme->stylesheet))); ?>" class="button button-secondary fetchpress-history-link" title="View deployment history">
              <span class="dashicons dashicons-backup"></span>
            </a>
            <form action="" method="POST" class="trash-button-wrapper" onsubmit="return validateDelete(this)">
              <?php wp_nonce_field('delete-theme'); ?>
              <input type="hidden" name="fetchpress[event]" value="delete-theme">
              <input type="hidden" name="fetchpress[stylesheet]" value="<?php echo esc_attr($theme->stylesheet); ?>">
              <button type="submit" class="trash-button">
                <img class="trash-icon" src="<?php echo esc_url(plugin_dir_url(__FILE__) . '../assets/unlink.svg'); ?>" alt="">
              </button>
              <script>
                function validateDelete(form) {
                  return confirm('Are you sure you want to unlink <?php echo esc_html($theme->stylesheet); ?>?');
                }
              </script>
              </script>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
      <?php if ($subscription_active === 'true' || count($themes) < 1) : ?>
        <a href="<?php echo esc_url(home_url() . '/wp-admin/admin.php?page=fetchpress-add-theme'); ?>" class="fetchpress__theme-card fetchpress__theme-card--add-theme">
          <img class="plus-icon" src="<?php echo esc_url(plugin_dir_url(__FILE__) . '../assets/plus.svg'); ?>" alt="">
          <p>ADD THEME</p>
        </a>
      <?php else : ?>
        <div class="fetchpress__theme-card fetchpress__theme-card--add-theme fetchpress__theme-card--locked">
          <img class="plus-icon" src="<?php echo esc_url(plugin_dir_url(__FILE__) . '../assets/plus.svg'); ?>" alt="">
          <p>ADD THEME</p>
          <p class="fetchpress-limit-notice">Free plan limited to 1 theme. <a href="https://fetch.press" target="_blank">Upgrade</a></p>
        </div>
      <?php endif; ?>
    </div>
  </div>
<?php else : ?>
  <?php $theme = get_theme_from_param($themes); ?>
  <div class="fetchpress-themes fetchpress-add-theme">
    <h1>Edit Theme</h1>
    <form action="" method="POST">
      <?php wp_nonce_field('edit-theme'); ?>
      <input type="hidden" name="fetchpress[event]" value="edit-theme">

      <input class="input" type="text" name="fetchpress[repository]" placeholder="Repository" value="<?php echo esc_attr($theme->repository); ?>" required>
      <p class="form-desc">Example: username/your-project-name</p>
      <input class="input" type="text" name="fetchpress[branch]" placeholder="Branch" value="<?php echo esc_attr($theme->branch); ?>">
      <p class="form-desc">Defaults to main if empty</p>
      <input class="input" type="text" name="fetchpress[subdirectory]" value="<?php echo esc_attr($theme->subdirectory); ?>" placeholder="Repository subdirectory (Optional)">
      <p class="form-desc">Only required if your theme or plugin resides in a subdirectory within the repository.</p>
      <label class="top-label bold">Version Control</label>
      <label for="vcservice">
        <div class="radio-item">
          <input class="input" type="radio" name="fetchpress[vcservice]" value="github" <?php echo esc_attr($theme->vcservice === 'github' ? 'checked' : ''); ?>>
          Github
        </div>
        <div class="radio-item">
          <input class="input" type="radio" name="fetchpress[vcservice]" value="bitbucket" <?php echo esc_attr($theme->vcservice === 'bitbucket' ? 'checked' : ''); ?>>
          Bitbucket
        </div>
        <div class="radio-item">
          <input class="input" type="radio" name="fetchpress[vcservice]" value="gitlab" <?php echo esc_attr($theme->vcservice === 'gitlab' ? 'checked' : ''); ?>>
          Gitlab
        </div>
      </label>
      <?php if ($subscription_active === 'true') : ?>
        <label for="privaterepo" class="top-label">
          <input class="input" type="checkbox" name="fetchpress[privaterepo]" <?php echo esc_attr($theme->privaterepo ? 'checked' : ''); ?>>
          Private Repository
        </label>
      <?php else : ?>
        <div class="disabled-wrapper">
          <label for="privaterepo" class="top-label">
            <input disabled class="input" type="checkbox" name="fetchpress[privaterepo]" <?php echo esc_attr($theme->privaterepo ? 'checked' : ''); ?>>
            Private Repository
          </label>
          <p>You need to purchase a license to use this feature. Get one at <a href="https://fetch.press" target="_blank">fetch.press</a></p>
        </div>
      <?php endif; ?>
      <label for="deployonpush">
        <input class="input" type="checkbox" name="fetchpress[deployonpush]" <?php echo esc_attr($theme->deployonpush ? 'checked' : ''); ?>>
        Deploy on push
      </label>
      <?php submit_button('Update theme'); ?>
      <a href="<?php echo esc_url(home_url() . '/wp-admin/admin.php?page=fetchpress-themes'); ?>">Back to themes</a>
    </form>
  </div>
<?php endif; ?>

<?php if (!($features['whiteLabelMode'] ?? false)) : ?>
<div class="fetchpress-footer">
  <img class="badge" src="<?php echo esc_url(plugin_dir_url(__FILE__) . '../assets/badge.svg'); ?>" alt="">
  <p>Copyright © <?php echo esc_html(date('Y')); ?> <a href="https://fetch.press" target="_blank">FetchPress</a></p>
</div>
<?php endif; ?>