<?php

/**
 * Add theme form HTML
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    FetchPress
 * @subpackage FetchPress/admin/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
  die;
}
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div>
  <div class="fetchpress-add-theme fetchpress-themes">
    <h1>Add Theme</h1>
    <?php if ($subscription_active !== 'true' && count($themes) >= 1) : ?>
      <div class="notice notice-warning">
        <p><strong>Free plan limit reached.</strong> You already have 1 theme. <a href="https://fetch.press" target="_blank">Purchase a license</a> to add more.</p>
      </div>
    <?php endif; ?>
    <form action="" method="POST">
      <?php wp_nonce_field('add-theme'); ?>
      <input type="hidden" name="fetchpress[event]" value="add-theme">

      <input class="input" type="text" name="fetchpress[repository]" placeholder="Repository" required>
      <p class="form-desc">Example: username/your-project-name</p>
      <input class="input" type="text" name="fetchpress[branch]" placeholder="Branch">
      <p class="form-desc">Defaults to main if empty</p>
      <input class="input" type="text" name="fetchpress[subdirectory]" placeholder="Repository subdirectory (Optional)">
      <p class="form-desc">Only required if your theme or plugin resides in a subdirectory within the repository.</p>
      <label class="top-label bold">Version Control</label>
      <label for="vcservice">
        <div class="radio-item">
          <input class="input" type="radio" name="fetchpress[vcservice]" value="github" checked>
          Github
        </div>
        <div class="radio-item">
          <input class="input" type="radio" name="fetchpress[vcservice]" value="bitbucket">
          Bitbucket
        </div>
        <div class="radio-item">
          <input class="input" type="radio" name="fetchpress[vcservice]" value="gitlab">
          Gitlab
        </div>
      </label>
      <?php if ($subscription_active === 'true') : ?>
        <label for="privaterepo" class="top-label">
          <input class="input" type="checkbox" name="fetchpress[privaterepo]">
          Private Repository
        </label>
      <?php else : ?>
        <div class="disabled-wrapper">
          <label for="privaterepo" class="top-label">
            <input class="input" type="checkbox" name="fetchpress[privaterepo]" disabled>
            Private Repository
          </label>
          <p>You need to purchase a license to use this feature. Get one at <a href="https://fetch.press" target="_blank">fetch.press</a></p>
        </div>
      <?php endif; ?>
      <label for="deployonpush">
        <input class="input" type="checkbox" name="fetchpress[deployonpush]">
        Deploy on push
      </label>
      <label for="linktoexisting">
        <input class="input" type="checkbox" name="fetchpress[linktoexisting]">
        Link to existing theme (Folder name must be the same as git repository)
      </label>
      <?php submit_button('Add Theme'); ?>
    </form>
    <a href="<?php echo esc_url(home_url() . '/wp-admin/admin.php?page=fetchpress-themes'); ?>">Back to themes</a>
  </div>
</div>

<?php if (!($features['whiteLabelMode'] ?? false)) : ?>
<div class="fetchpress-footer">
  <img class="badge" src="<?php echo esc_url(plugin_dir_url(__FILE__) . '../assets/badge.svg'); ?>" alt="">
  <p>Copyright © <?php echo esc_html(date('Y')); ?> <a href="https://fetch.press" target="_blank">FetchPress</a></p>
</div>
<?php endif; ?>