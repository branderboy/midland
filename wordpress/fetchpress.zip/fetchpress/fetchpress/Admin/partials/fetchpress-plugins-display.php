<?php

/**
 * Add theme form HTML
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    FetchPress
 * @subpackage FetchPress/admin/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
  die;
}

function get_plugin_from_param($plugins)
{
  if (!isset($_GET['title'])) {
    return false;
  }

  foreach ($plugins as $plugin) {
    if ($plugin->file->title === $_GET['title']) {
      return $plugin;
    }
  }
}
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<!-- Check if theme param exists. If so show edit form, otherwise list plugins -->
<?php if (!isset($_GET['title']) && !get_plugin_from_param($plugins)) : ?>
  <div class="fetchpress-themes">
    <h1>Plugins</h1>
    <div class="fetchpress__theme-list">
      <?php foreach ($plugins as $plugin) : ?>
        <div class="fetchpress__theme-card">
          <h3><?php echo esc_html($plugin->name); ?></h3>
          <p><?php echo esc_html($plugin->repository); ?></p>
          <ul>
            <li><strong>Version Control:</strong> <?php echo esc_html($plugin->vcservice); ?></li>
            <li><strong>Branch:</strong> <?php echo esc_html($plugin->branch); ?></li>
            <li><strong>Deploy on push:</strong> <span class="<?php echo esc_attr($plugin->deployonpush === '1' ? 'green' : 'red'); ?>"><?php echo esc_html($plugin->deployonpush === '1' ? 'Enabled' : 'Disabled'); ?></span></li>
          </ul>
          <div class="fetchpress__button-row">
            <form action="" method="POST">
              <?php wp_nonce_field('update-plugin'); ?>
              <input type="hidden" name="fetchpress[event]" value="update-plugin">
              <input type="hidden" name="fetchpress[repository]" value="<?php echo esc_attr($plugin->repository); ?>">
              <input type="hidden" name="fetchpress[file]" value="<?php echo esc_attr($plugin->file->title); ?>">
              <?php submit_button('Update plugin'); ?>
            </form>
            <a href="<?php echo esc_url(home_url() . '/wp-admin/admin.php?page=fetchpress-plugins&title=' . urlencode($plugin->file->title)); ?>" class="button">Edit Plugin</a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=fetchpress-history&type=plugin&identifier=' . urlencode($plugin->file->title))); ?>" class="button button-secondary fetchpress-history-link" title="View deployment history">
              <span class="dashicons dashicons-backup"></span>
            </a>
            <form action="" method="POST" class="trash-button-wrapper" onsubmit="return validateDelete(this)">
              <?php wp_nonce_field('delete-plugin'); ?>
              <input type="hidden" name="fetchpress[event]" value="delete-plugin">
              <input type="hidden" name="fetchpress[file]" value="<?php echo esc_attr($plugin->file->title); ?>">
              <button type="submit" class="trash-button">
                <img class="trash-icon" src="<?php echo esc_url(plugin_dir_url(__FILE__) . '../assets/unlink.svg'); ?>" alt="">
              </button>
              <script>
                function validateDelete(form) {
                  return confirm('Are you sure you want to unlink <?php echo esc_html($plugin->file->title); ?>?');
                }
              </script>
              </script>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
      <?php if ($subscription_active === 'true' || count($plugins) < 1) : ?>
        <a href="<?php echo esc_url(home_url() . '/wp-admin/admin.php?page=fetchpress-add-plugin'); ?>" class="fetchpress__theme-card fetchpress__theme-card--add-theme">
          <img class="plus-icon" src="<?php echo esc_url(plugin_dir_url(__FILE__) . '../assets/plus.svg'); ?>" alt="">
          <p>ADD PLUGIN</p>
        </a>
      <?php else : ?>
        <div class="fetchpress__theme-card fetchpress__theme-card--add-theme fetchpress__theme-card--locked">
          <img class="plus-icon" src="<?php echo esc_url(plugin_dir_url(__FILE__) . '../assets/plus.svg'); ?>" alt="">
          <p>ADD PLUGIN</p>
          <p class="fetchpress-limit-notice">Free plan limited to 1 plugin. <a href="https://fetch.press" target="_blank">Upgrade</a></p>
        </div>
      <?php endif; ?>
    </div>
  </div>
<?php else : ?>
  <?php $plugin = get_plugin_from_param($plugins); ?>
  <div class="fetchpress-themes fetchpress-add-theme">
    <h1>Edit Plugin</h1>
    <form action="" method="POST">
      <?php wp_nonce_field('edit-plugin'); ?>
      <input type="hidden" name="fetchpress[event]" value="edit-plugin">

      <input class="input" type="text" name="fetchpress[repository]" placeholder="Repository" value="<?php echo esc_attr($plugin->repository); ?>" required>
      <p class="form-desc">Example: username/your-project-name</p>
      <input class="input" type="text" name="fetchpress[branch]" placeholder="Branch" value="<?php echo esc_attr($plugin->branch); ?>">
      <p class="form-desc">Defaults to main if empty</p>
      <input class="input" type="text" name="fetchpress[subdirectory]" value="<?php echo esc_attr($plugin->subdirectory); ?>" placeholder="Repository subdirectory (Optional)">
      <p class="form-desc">Only required if your theme or plugin resides in a subdirectory within the repository.</p>
      <label class="top-label bold">Version Control</label>
      <label for="vcservice">
        <div class="radio-item">
          <input class="input" type="radio" name="fetchpress[vcservice]" value="github" <?php echo esc_attr($plugin->vcservice === 'github' ? 'checked' : ''); ?>>
          Github
        </div>
        <div class="radio-item">
          <input class="input" type="radio" name="fetchpress[vcservice]" value="bitbucket" <?php echo esc_attr($plugin->vcservice === 'bitbucket' ? 'checked' : ''); ?>>
          Bitbucket
        </div>
        <div class="radio-item">
          <input class="input" type="radio" name="fetchpress[vcservice]" value="gitlab" <?php echo esc_attr($plugin->vcservice === 'gitlab' ? 'checked' : ''); ?>>
          Gitlab
        </div>
      </label>
      <?php if ($subscription_active === 'true') : ?>
        <label for="privaterepo" class="top-label">
          <input class="input" type="checkbox" name="fetchpress[privaterepo]" <?php echo esc_attr($plugin->privaterepo ? 'checked' : ''); ?> >
          Private Repository
        </label>
      <?php else : ?>
        <div class="disabled-wrapper">
          <label for="privaterepo" class="top-label">
            <input disabled class="input" type="checkbox" name="fetchpress[privaterepo]" <?php echo esc_attr($plugin->privaterepo ? 'checked' : ''); ?> >
            Private Repository
          </label>
          <p>You need to purchase a license to use this feature. Get one at <a href="https://fetch.press" target="_blank">fetch.press</a></p>
        </div>
      <?php endif; ?>
      <label for="deployonpush">
        <input class="input" type="checkbox" name="fetchpress[deployonpush]" <?php echo esc_attr($plugin->deployonpush ? 'checked' : ''); ?>>
        Deploy on push
      </label>
      <?php submit_button('Update plugin'); ?>
      <a href="<?php echo esc_url(home_url() . '/wp-admin/admin.php?page=fetchpress-plugins'); ?>">Back to plugins</a>
    </form>
  </div>
<?php endif; ?>

<?php if (!($features['whiteLabelMode'] ?? false)) : ?>
<div class="fetchpress-footer">
  <img class="badge" src="<?php echo esc_url(plugin_dir_url(__FILE__) . '../assets/badge.svg'); ?>" alt="">
  <p>Copyright © <?php echo esc_html(date('Y')); ?> <a href="https://fetch.press" target="_blank">FetchPress</a></p>
</div>
<?php endif; ?>