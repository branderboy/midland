<?php

namespace FetchPress\Models;

use WP_Theme;

class Theme
{
    public $repository;
    public $name;
    public $theme_URI;
    public $description;
    public $author;
    public $author_URI;
    public $version;
    public $template;
    public $status;
    public $tags;
    public $text_domain;
    public $domain_path;
    public $branch;
    public $vcservice;
    public $privaterepo;
    public $deployonpush;
    public $subdirectory;
    public $linktoexisting;
    public $stylesheet;

    public function __construct($input)
    {
        $this->repository = (isset($input['repository'])) ? $input['repository'] : '';
        $this->branch = (!empty($input['branch'])) ? $input['branch'] : 'main';
        $this->vcservice = (isset($input['vcservice'])) ? $input['vcservice'] : 'github';
        $this->privaterepo = (isset($input['privaterepo'])) ? '1' : '0';
        $this->deployonpush = (isset($input['deployonpush'])) ? '1' : '0';
        $this->linktoexisting = (isset($input['linktoexisting'])) ? '1' : '0';
        $this->subdirectory = (isset($input['subdirectory'])) ? $input['subdirectory'] : null;
    }

    public static function map_from_wp_theme_object(WP_Theme $wp_theme_data)
    {
        $theme = new static(null);

        $theme->stylesheet = $wp_theme_data->get_stylesheet();
        $theme->name = $wp_theme_data['Name'];
        $theme->theme_URI = $wp_theme_data['PluginURI'];
        $theme->description = $wp_theme_data['Description'];
        $theme->author = $wp_theme_data['Author'];
        $theme->author_URI = $wp_theme_data['AuthorURI'];
        $theme->version = $wp_theme_data['Version'];
        $theme->template = $wp_theme_data['Template'];
        $theme->status = $wp_theme_data['status'];
        $theme->tags = $wp_theme_data['tags'];
        $theme->text_domain = $wp_theme_data['TextDomain'];
        $theme->domain_path = $wp_theme_data['DomainPath'];

        return $theme;
    }

    public function from_slug($slug)
    {
        $wp_theme_data = wp_get_theme($slug);

        return $this->map_from_wp_theme_object($wp_theme_data);
    }

    public function get_slug_from_repo() {
        $elements = preg_split('/\//', $this->repository);

        if ( ! isset($elements[1])){
            return ;
        }

        return $elements[1];
    }

    public function get_slug()
    {
        if (!$this->subdirectory) {
            return $this->get_slug_from_repo();
        }

        $parts = explode('/', $this->subdirectory);

        return end($parts);
    }

    public function hasSubdirectory()
    {
        return !(is_null($this->subdirectory) or $this->subdirectory === '');
    }
}
