<?php

namespace FetchPress\Models;

class Plugin
{
    public $file;
    public $repository;
    public $name;
    public $plugin_URI;
    public $description;
    public $author;
    public $author_URI;
    public $version;
    public $template;
    public $status;
    public $tags;
    public $text_domain;
    public $domain_path;
    public $branch;
    public $vcservice;
    public $privaterepo;
    public $deployonpush;
    public $linktoexisting;
    public $subdirectory;
    public $plugin_data;

    public function __construct($input)
    {
        $this->repository = (isset($input['repository'])) ? $input['repository'] : '';
        $this->branch = (!empty($input['branch'])) ? $input['branch'] : 'main';
        $this->vcservice = (isset($input['vcservice'])) ? $input['vcservice'] : 'github';
        $this->privaterepo = (isset($input['privaterepo'])) ? '1' : '0';
        $this->deployonpush = (isset($input['deployonpush'])) ? '1' : '0';
        $this->linktoexisting = (isset($input['linktoexisting'])) ? '1' : '0';
        $this->subdirectory = (isset($input['subdirectory'])) ? $input['subdirectory'] : null;
    }

    public static function map_from_wp_plugin_object($plugin_file, $plugin_meta)
    {
        $plugin = new static(null);

        $plugin->file = $plugin_file;
        $plugin->name = $plugin_meta['Name'];
        $plugin->plugin_URI = $plugin_meta['PluginURI'];
        $plugin->description = $plugin_meta['Description'];
        $plugin->author = $plugin_meta['Author'];
        $plugin->author_URI = $plugin_meta['AuthorURI'];
        $plugin->version = $plugin_meta['Version'];
        $plugin->text_domain = $plugin_meta['TextDomain'];
        $plugin->domain_path = $plugin_meta['DomainPath'];

        return $plugin;
    }

    public function get_slug_from_repo()
    {
        $elements = preg_split('/\//', $this->repository);

        if (!isset($elements[1])) {
            return;
        }

        return $elements[1];
    }

    public function get_slug()
    {
        if (!$this->subdirectory) {
            return $this->get_slug_from_repo();
        }

        $parts = explode('/', $this->subdirectory);

        return end($parts);
    }

    public function hasSubdirectory()
    {
        return !(is_null($this->subdirectory) or $this->subdirectory === '');
    }
}
