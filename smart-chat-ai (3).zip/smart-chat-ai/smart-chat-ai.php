<?php
/**
 * Plugin Name: Midland Chat
 * Description: Midland-branded AI chat widget. Leverages site content (sitemap + pages) to answer 24/7, captures quote info, and offers a one-tap WhatsApp button so visitors can switch to a live conversation on the contractor's phone.
 * Version: 1.9.9
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: smart-chat-ai
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('SCAI_VERSION', '1.9.9');
define('SCAI_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SCAI_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Main Smart Chat AI Class
 */
class SCAI_Plugin {
    
    /**
     * Instance of this class
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->init_hooks();
        $this->load_dependencies();
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Activation/Deactivation
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Admin hooks
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // Frontend hooks
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_footer', array($this, 'render_chat_widget'));
        
        // AJAX hooks
        add_action('wp_ajax_scai_send_message', array($this, 'ajax_send_message'));
        add_action('wp_ajax_nopriv_scai_send_message', array($this, 'ajax_send_message'));
    }
    
    /**
     * Load dependencies
     */
    private function load_dependencies() {
        require_once SCAI_PLUGIN_DIR . 'includes/class-ai-handler.php';
        require_once SCAI_PLUGIN_DIR . 'includes/class-analytics.php';
        require_once SCAI_PLUGIN_DIR . 'includes/class-content-context.php';
        SCAI_Content_Context::get_instance();

        // WhatsApp is now click-to-chat only (wa.me link inside the widget). The
        // old Cloud API + Smart Messages admin layer was removed in 1.9.0 — clients
        // weren't getting through Meta's developer-app onboarding.
    }
    
    /**
     * Activation
     */
    public function activate() {
        // Create database tables
        $this->create_tables();

        // Set default options
        $defaults = array(
            'chat_enabled' => true,
            'chat_position' => 'bottom-right',
            'chat_color' => '#43A94B',
            'chat_title' => 'Chat with us!',
            'chat_subtitle' => 'We typically reply in a few minutes',
            'ai_provider' => 'perplexity',
            'openai_api_key' => '',
            'ai_model' => 'sonar',
            'ai_temperature' => 0.7,
            'business_name' => get_bloginfo('name'),
            'business_type' => 'contractor',
            'ai_personality' => 'helpful',
            'notify_email' => get_option('admin_email'),
            'enable_email_notifications' => true,
        );

        foreach ($defaults as $key => $value) {
            if (false === get_option('smart_chat_' . $key)) {
                add_option('smart_chat_' . $key, $value);
            }
        }

        // Sitemap ingestion — enabled by default, kick off an immediate crawl
        // so the AI has real site content on day one instead of waiting on the
        // first daily cron run.
        if ( class_exists( 'SCAI_Content_Context' ) ) {
            if ( false === get_option( SCAI_Content_Context::OPT_ENABLED ) ) {
                add_option( SCAI_Content_Context::OPT_ENABLED, 1 );
            } else {
                update_option( SCAI_Content_Context::OPT_ENABLED, 1 );
            }
            if ( false === get_option( SCAI_Content_Context::OPT_PAGE_LIMIT ) ) {
                add_option( SCAI_Content_Context::OPT_PAGE_LIMIT, 30 );
            }
            if ( false === get_option( SCAI_Content_Context::OPT_CHARS_PER ) ) {
                add_option( SCAI_Content_Context::OPT_CHARS_PER, 1500 );
            }
            // Single-shot cron event: refreshes the cache ~30 seconds after
            // activation on the next page load that triggers WP-Cron.
            if ( ! wp_next_scheduled( SCAI_Content_Context::CRON_HOOK ) ) {
                wp_schedule_single_event( time() + 30, SCAI_Content_Context::CRON_HOOK );
            }
        }
    }
    
    /**
     * Deactivation
     */
    public function deactivate() {
        // Nothing to clean up — no cron events, no license server pings.
    }
    
    /**
     * Create database tables
     */
    private function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        // Conversations table
        $table_conversations = $wpdb->prefix . 'smart_chat_conversations';
        $sql_conversations = "CREATE TABLE IF NOT EXISTS $table_conversations (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            session_id varchar(255) NOT NULL,
            message text NOT NULL,
            sender varchar(20) NOT NULL,
            ai_model varchar(50) DEFAULT NULL,
            tokens_used int DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        // Call requests (callbacks) table.
        $table_callbacks = $wpdb->prefix . 'smart_chat_callbacks';
        $sql_callbacks = "CREATE TABLE IF NOT EXISTS $table_callbacks (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            session_id varchar(255) DEFAULT NULL,
            name varchar(255) NOT NULL,
            phone varchar(50) NOT NULL,
            email varchar(255) DEFAULT NULL,
            message text DEFAULT NULL,
            status varchar(20) DEFAULT 'new',
            ip_address varchar(100) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY status (status),
            KEY created_at (created_at)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_conversations);
        dbDelta($sql_callbacks);
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __( 'Midland Chat', 'smart-chat-ai' ),
            __( 'Midland Chat', 'smart-chat-ai' ),
            'manage_options',
            'smart-chat-ai',
            array($this, 'admin_dashboard_page'),
            'dashicons-format-chat',
            30
        );

        add_submenu_page(
            'smart-chat-ai',
            __( 'Leads', 'smart-chat-ai' ),
            __( 'Leads', 'smart-chat-ai' ),
            'manage_options',
            'smart-chat-callbacks',
            array($this, 'admin_callbacks_page')
        );

        add_submenu_page(
            'smart-chat-ai',
            __( 'Conversations', 'smart-chat-ai' ),
            __( 'Conversations', 'smart-chat-ai' ),
            'manage_options',
            'smart-chat-conversations',
            array($this, 'admin_conversations_page')
        );

        add_submenu_page(
            'smart-chat-ai',
            __( 'Settings', 'smart-chat-ai' ),
            __( 'Settings', 'smart-chat-ai' ),
            'manage_options',
            'smart-chat-settings',
            array($this, 'admin_settings_page')
        );

    }

    /**
     * Register settings
     */
    public function register_settings() {
        $settings = array(
            'chat_enabled',
            'chat_position',
            'chat_color',
            'chat_logo',
            'chat_title',
            'chat_subtitle',
            'ai_provider',
            'perplexity_api_key',
            'openai_api_key',
            'ai_model',
            'ai_temperature',
            'business_name',
            'business_type',
            'ai_personality',
            'preprompt',
            'sf_form_id',
        );

        foreach ($settings as $setting) {
            register_setting('scai_settings', 'smart_chat_' . $setting);
        }

        // Sitemap ingestion (Site Content) — same options the dedicated page uses,
        // exposed here so admins can configure everything from one screen.
        register_setting( 'scai_settings', SCAI_Content_Context::OPT_ENABLED, array( 'type' => 'integer', 'sanitize_callback' => 'absint' ) );
        register_setting( 'scai_settings', SCAI_Content_Context::OPT_SITEMAP_URL, array( 'type' => 'string', 'sanitize_callback' => 'esc_url_raw' ) );
        register_setting( 'scai_settings', SCAI_Content_Context::OPT_PAGE_LIMIT, array( 'type' => 'integer', 'sanitize_callback' => 'absint' ) );
        register_setting( 'scai_settings', SCAI_Content_Context::OPT_CHARS_PER, array( 'type' => 'integer', 'sanitize_callback' => 'absint' ) );

        // WhatsApp click-to-chat — one number, one prefilled greeting, no Meta app needed.
        register_setting( 'scai_settings', 'smart_chat_whatsapp_number', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ) );
        register_setting( 'scai_settings', 'smart_chat_whatsapp_greeting', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ) );

        // Call-request notification.
        register_setting( 'scai_settings', 'smart_chat_notify_email', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_email' ) );
        register_setting( 'scai_settings', 'smart_chat_enable_email_notifications', array( 'type' => 'boolean' ) );
    }
    
    /**
     * Enqueue admin scripts
     */
    public function admin_enqueue_scripts($hook) {
        if (strpos($hook, 'smart-chat') === false) {
            return;
        }

        // wp.media() — needed for the logo picker on the settings screen.
        wp_enqueue_media();

        wp_enqueue_style(
            'scai-admin',
            SCAI_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            SCAI_VERSION
        );

        wp_enqueue_script(
            'scai-admin',
            SCAI_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            SCAI_VERSION,
            true
        );
        
        wp_localize_script('scai-admin', 'scaiAdmin', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('scai_admin'),
        ));
    }
    
    /**
     * Enqueue frontend scripts
     */
    public function enqueue_scripts() {
        // Check if chat is enabled
        if (!get_option('smart_chat_chat_enabled')) {
            return;
        }
        
        wp_enqueue_style(
            'scai-widget',
            SCAI_PLUGIN_URL . 'assets/css/widget.css',
            array(),
            SCAI_VERSION
        );
        
        wp_enqueue_script(
            'scai-widget',
            SCAI_PLUGIN_URL . 'assets/js/widget.js',
            array('jquery'),
            SCAI_VERSION,
            true
        );
        
        $wa_number = preg_replace( '/[^0-9]/', '', (string) get_option( 'smart_chat_whatsapp_number', '' ) );

        // Booking link is a PER-FORM setting on the Smart Form the chat embeds
        // (Smart Forms → edit form → Booking link). Only forms meant to send
        // people to schedule a visit set it, so it's never global here.
        $booking_url = '';
        $sf_form_id  = (int) get_option( 'smart_chat_sf_form_id', 1 );
        if ( $sf_form_id && class_exists( 'SFCO_Database' ) ) {
            $sf_form = SFCO_Database::get_form( $sf_form_id );
            if ( $sf_form && ! empty( $sf_form->settings_json ) ) {
                $sf_settings = json_decode( $sf_form->settings_json, true );
                if ( is_array( $sf_settings ) && ! empty( $sf_settings['booking_url'] ) ) {
                    $booking_url = $sf_settings['booking_url'];
                }
            }
        }

        wp_localize_script('scai-widget', 'scaiConfig', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('scai_widget'),
            'position' => get_option('smart_chat_chat_position', 'bottom-right'),
            'color' => get_option('smart_chat_chat_color', '#43A94B'),
            'title' => get_option('smart_chat_chat_title', 'Chat with us!'),
            'subtitle' => get_option('smart_chat_chat_subtitle', 'We typically reply in a few minutes'),
            'businessName' => get_option('smart_chat_business_name', get_bloginfo('name')),
            'whatsappNumber' => $wa_number,
            'whatsappGreeting' => get_option( 'smart_chat_whatsapp_greeting', "Hi! I'd like to ask about your services." ),
            // From the embedded form's per-form Booking link. When present,
            // "Schedule a Visit" / booking intent shows a "Pick a time" button.
            'bookingUrl' => esc_url_raw( $booking_url ),
        ));
    }
    
    /**
     * Render chat widget
     */
    public function render_chat_widget() {
        // Check if chat is enabled
        if (!get_option('smart_chat_chat_enabled')) {
            return;
        }
        
        include SCAI_PLUGIN_DIR . 'templates/widget.php';
    }
    
    /**
     * AJAX: Send message
     */
    public function ajax_send_message() {
        check_ajax_referer('scai_widget', 'nonce');
        
        $message = sanitize_text_field($_POST['message']);
        $session_id = sanitize_text_field($_POST['session_id']);
        
        // Get AI response
        $ai_handler = new SCAI_AI_Handler();
        $response = $ai_handler->get_response($message, $session_id);
        
        // Save conversation
        global $wpdb;
        $table = $wpdb->prefix . 'smart_chat_conversations';
        
        $wpdb->insert($table, array( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            'session_id' => $session_id,
            'message' => $message,
            'sender' => 'user',
            'created_at' => current_time('mysql'),
        ));
        
        $wpdb->insert($table, array( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            'session_id' => $session_id,
            'message' => $response['message'],
            'sender' => 'ai',
            'ai_model' => $response['model'],
            'tokens_used' => $response['tokens'],
            'created_at' => current_time('mysql'),
        ));

        // Conversational lead capture. The AI is instructed to ask for name,
        // contact, and reason in chat. After each visitor turn we check whether
        // the thread now contains contact info; if so, extract it and save a
        // lead (once per session) and email ownership.
        $this->maybe_capture_lead( $session_id, $ai_handler );

        wp_send_json_success($response);
    }

    /**
     * Detect and save a lead from the conversation once the visitor has given
     * contact details. Cheap regex gate first so we only spend an extraction
     * API call when there's plausibly something to extract, and only one lead
     * is ever saved per session.
     */
    private function maybe_capture_lead( $session_id, $ai_handler ) {
        if ( '' === $session_id ) {
            return;
        }

        global $wpdb;
        $cb_table = $wpdb->prefix . 'smart_chat_callbacks';

        // Already captured this session? Stop.
        $existing = $wpdb->get_var( $wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            "SELECT id FROM {$cb_table} WHERE session_id = %s LIMIT 1",
            $session_id
        ) );
        if ( $existing ) {
            return;
        }

        // Pull the visitor's side of the conversation.
        $convo_table = $wpdb->prefix . 'smart_chat_conversations';
        $visitor_text = (string) $wpdb->get_var( $wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            "SELECT GROUP_CONCAT(message SEPARATOR ' ') FROM {$convo_table} WHERE session_id = %s AND sender = 'user'",
            $session_id
        ) );

        // Cheap gate: is there an email or a phone-like run of digits anywhere?
        $has_email = (bool) preg_match( '/[^@\s]+@[^@\s]+\.[^@\s]+/', $visitor_text );
        $digits    = preg_replace( '/\D+/', '', $visitor_text );
        $has_phone = strlen( $digits ) >= 10;
        if ( ! $has_email && ! $has_phone ) {
            return;
        }

        // Structured extraction via the provider.
        $info = $ai_handler->extract_lead_info( $session_id );
        if ( ! is_array( $info ) ) {
            return;
        }

        $name    = isset( $info['name'] )    ? sanitize_text_field( (string) $info['name'] )    : '';
        $email   = isset( $info['email'] )   ? sanitize_email( (string) $info['email'] )        : '';
        $phone   = isset( $info['phone'] )   ? sanitize_text_field( (string) $info['phone'] )   : '';
        $service = isset( $info['service_type'] ) ? sanitize_text_field( (string) $info['service_type'] ) : '';

        // "null" strings come back from the model sometimes; treat as empty.
        foreach ( array( 'name', 'email', 'phone', 'service' ) as $v ) {
            if ( 'null' === strtolower( (string) $$v ) ) { $$v = ''; }
        }
        if ( ! is_email( $email ) ) { $email = ''; }

        // Need a name plus at least one way to reach them.
        if ( '' === $name || ( '' === $email && '' === $phone ) ) {
            return;
        }

        $wpdb->insert( $cb_table, array( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            'session_id' => $session_id,
            'name'       => $name,
            'phone'      => $phone,
            'email'      => $email,
            'message'    => $service,
            'status'     => 'new',
            'ip_address' => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
            'created_at' => current_time( 'mysql' ),
        ) );
        $callback_id = (int) $wpdb->insert_id;

        // Drop a marker into the thread so the captured lead is visible in context.
        $wpdb->insert( $convo_table, array( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            'session_id' => $session_id,
            'message'    => sprintf( 'Lead captured: %s | %s | %s', $name, ( $phone ? $phone : '—' ), ( $email ? $email : '—' ) ),
            'sender'     => 'system',
            'created_at' => current_time( 'mysql' ),
        ) );

        if ( get_option( 'smart_chat_enable_email_notifications' ) ) {
            $this->send_callback_notification( $callback_id );
        }
    }

    /**
     * Email ownership about a new call request.
     */
    private function send_callback_notification($callback_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'smart_chat_callbacks';
        $cb = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $callback_id)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $cb ) { return; }

        $to = get_option('smart_chat_notify_email', get_option('admin_email'));
        if ( ! is_email($to) ) { $to = get_option('admin_email'); }

        $subject = sprintf( __( 'New chat lead: %s', 'smart-chat-ai' ), $cb->name );

        $body  = __( 'New lead captured by the website chat.', 'smart-chat-ai' ) . "\n\n";
        $body .= __( 'Name:', 'smart-chat-ai' )    . ' ' . $cb->name  . "\n";
        $body .= __( 'Phone:', 'smart-chat-ai' )   . ' ' . $cb->phone . "\n";
        $body .= __( 'Email:', 'smart-chat-ai' )   . ' ' . ( $cb->email ? $cb->email : '—' ) . "\n";
        $body .= __( 'Message:', 'smart-chat-ai' ) . ' ' . ( $cb->message ? $cb->message : '—' ) . "\n\n";
        $body .= __( 'Received:', 'smart-chat-ai' ). ' ' . $cb->created_at . "\n";
        $body .= __( 'View all leads:', 'smart-chat-ai' ) . ' ' . admin_url('admin.php?page=smart-chat-callbacks');

        $headers = array();
        if ( $cb->email && is_email($cb->email) ) {
            $headers[] = 'Reply-To: ' . $cb->name . ' <' . $cb->email . '>';
        }

        wp_mail($to, $subject, $body, $headers);
    }

    /**
     * Admin dashboard page
     */
    public function admin_dashboard_page() {
        include SCAI_PLUGIN_DIR . 'admin/dashboard.php';
    }
    
    /**
     * Admin conversations page
     */
    public function admin_conversations_page() {
        include SCAI_PLUGIN_DIR . 'admin/conversations.php';
    }

    /**
     * Admin call requests page
     */
    public function admin_callbacks_page() {
        include SCAI_PLUGIN_DIR . 'admin/callbacks.php';
    }
    
    /**
     * Admin settings page
     */
    public function admin_settings_page() {
        include SCAI_PLUGIN_DIR . 'admin/settings.php';
    }
}

// Initialize plugin
function scai_init() {
    return SCAI_Plugin::get_instance();
}

add_action('plugins_loaded', 'scai_init');
