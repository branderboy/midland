<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( ! current_user_can( 'manage_options' ) ) { return; }

global $wpdb;
$table = $wpdb->prefix . 'smart_chat_conversations';

// Single-conversation view when a session is selected.
$view_session = isset( $_GET['session'] ) ? sanitize_text_field( wp_unslash( $_GET['session'] ) ) : '';

if ( '' !== $view_session ) :
    $messages = $wpdb->get_results( $wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        "SELECT message, sender, created_at FROM {$table} WHERE session_id = %s ORDER BY created_at ASC",
        $view_session
    ) );
    $back_url = admin_url( 'admin.php?page=smart-chat-conversations' );
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'Conversation', 'smart-chat-ai' ); ?></h1>
        <p>
            <a href="<?php echo esc_url( $back_url ); ?>" class="button button-secondary">&larr; <?php esc_html_e( 'Back to all conversations', 'smart-chat-ai' ); ?></a>
            &nbsp; <code><?php echo esc_html( $view_session ); ?></code>
        </p>

        <?php if ( empty( $messages ) ) : ?>
            <p><?php esc_html_e( 'No messages in this conversation.', 'smart-chat-ai' ); ?></p>
        <?php else : ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width:160px;"><?php esc_html_e( 'Date &amp; Time', 'smart-chat-ai' ); ?></th>
                        <th style="width:80px;"><?php esc_html_e( 'Sender', 'smart-chat-ai' ); ?></th>
                        <th><?php esc_html_e( 'Message', 'smart-chat-ai' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $messages as $m ) : ?>
                        <tr>
                            <td><?php echo esc_html( date_i18n( 'M j, Y g:i:s a', strtotime( $m->created_at ) ) ); ?></td>
                            <td>
                                <?php
                                if ( 'user' === $m->sender ) {
                                    $sender_label = __( 'Visitor', 'smart-chat-ai' );
                                } elseif ( 'system' === $m->sender ) {
                                    $sender_label = __( 'System', 'smart-chat-ai' );
                                } else {
                                    $sender_label = __( 'AI', 'smart-chat-ai' );
                                }
                                ?>
                                <strong><?php echo esc_html( $sender_label ); ?></strong>
                            </td>
                            <td><?php echo esc_html( $m->message ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php
    return;
endif;

// Session list view.
$sessions = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    "SELECT session_id, MIN(created_at) as started, MAX(created_at) as last_msg, COUNT(*) as msg_count
     FROM {$table} GROUP BY session_id ORDER BY last_msg DESC LIMIT 50" // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
);
?>
<div class="wrap">
    <h1><?php esc_html_e( 'Chat Conversations', 'smart-chat-ai' ); ?></h1>

    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th><?php esc_html_e( 'Session', 'smart-chat-ai' ); ?></th>
                <th><?php esc_html_e( 'Messages', 'smart-chat-ai' ); ?></th>
                <th><?php esc_html_e( 'Started', 'smart-chat-ai' ); ?></th>
                <th><?php esc_html_e( 'Last Message', 'smart-chat-ai' ); ?></th>
                <th><?php esc_html_e( 'View', 'smart-chat-ai' ); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if ( empty( $sessions ) ) : ?>
                <tr><td colspan="5"><?php esc_html_e( 'No conversations yet.', 'smart-chat-ai' ); ?></td></tr>
            <?php else : ?>
                <?php foreach ( $sessions as $s ) :
                    $view_url = add_query_arg(
                        array( 'page' => 'smart-chat-conversations', 'session' => $s->session_id ),
                        admin_url( 'admin.php' )
                    );
                    ?>
                    <tr>
                        <td><code><?php echo esc_html( substr( $s->session_id, 0, 12 ) . '...' ); ?></code></td>
                        <td><?php echo esc_html( $s->msg_count ); ?></td>
                        <td><?php echo esc_html( date_i18n( 'M j, Y g:i a', strtotime( $s->started ) ) ); ?></td>
                        <td><?php echo esc_html( date_i18n( 'M j, Y g:i a', strtotime( $s->last_msg ) ) ); ?></td>
                        <td><a class="button button-small" href="<?php echo esc_url( $view_url ); ?>"><?php esc_html_e( 'View', 'smart-chat-ai' ); ?></a></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
