<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( ! current_user_can( 'manage_options' ) ) { return; }

global $wpdb;
$table = $wpdb->prefix . 'smart_chat_callbacks';

// Handle status update.
if ( isset( $_POST['scai_cb_action'], $_POST['cb_id'], $_POST['_scai_cb_nonce'] )
    && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_scai_cb_nonce'] ) ), 'scai_cb_status' ) ) {
    $cb_id  = absint( $_POST['cb_id'] );
    $action = sanitize_text_field( wp_unslash( $_POST['scai_cb_action'] ) );
    if ( 'mark_done' === $action ) {
        $wpdb->update( $table, array( 'status' => 'done' ), array( 'id' => $cb_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    } elseif ( 'mark_new' === $action ) {
        $wpdb->update( $table, array( 'status' => 'new' ), array( 'id' => $cb_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    } elseif ( 'delete' === $action ) {
        $wpdb->delete( $table, array( 'id' => $cb_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    }
    echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Updated.', 'smart-chat-ai' ) . '</p></div>';
}

$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    "SELECT * FROM {$table} ORDER BY created_at DESC LIMIT 200" // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
);
?>
<div class="wrap">
    <h1><?php esc_html_e( 'Chat Leads', 'smart-chat-ai' ); ?></h1>
    <p class="description"><?php esc_html_e( 'Leads captured in conversation by the chat assistant. Ownership is emailed when a new one comes in.', 'smart-chat-ai' ); ?></p>

    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th style="width:150px;"><?php esc_html_e( 'Date &amp; Time', 'smart-chat-ai' ); ?></th>
                <th><?php esc_html_e( 'Name', 'smart-chat-ai' ); ?></th>
                <th><?php esc_html_e( 'Phone', 'smart-chat-ai' ); ?></th>
                <th><?php esc_html_e( 'Email', 'smart-chat-ai' ); ?></th>
                <th><?php esc_html_e( 'Message', 'smart-chat-ai' ); ?></th>
                <th style="width:80px;"><?php esc_html_e( 'Status', 'smart-chat-ai' ); ?></th>
                <th style="width:170px;"><?php esc_html_e( 'Actions', 'smart-chat-ai' ); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if ( empty( $rows ) ) : ?>
                <tr><td colspan="7"><?php esc_html_e( 'No leads yet.', 'smart-chat-ai' ); ?></td></tr>
            <?php else : ?>
                <?php foreach ( $rows as $r ) : ?>
                    <tr>
                        <td><?php echo esc_html( date_i18n( 'M j, Y g:i a', strtotime( $r->created_at ) ) ); ?></td>
                        <td><strong><?php echo esc_html( $r->name ); ?></strong></td>
                        <td><a href="<?php echo esc_attr( 'tel:' . preg_replace( '/[^0-9+]/', '', $r->phone ) ); ?>"><?php echo esc_html( $r->phone ); ?></a></td>
                        <td><?php echo $r->email ? '<a href="' . esc_attr( 'mailto:' . $r->email ) . '">' . esc_html( $r->email ) . '</a>' : '&mdash;'; ?></td>
                        <td><?php echo $r->message ? esc_html( $r->message ) : '&mdash;'; ?></td>
                        <td>
                            <?php if ( 'done' === $r->status ) : ?>
                                <span style="color:#16794C;font-weight:600;"><?php esc_html_e( 'Done', 'smart-chat-ai' ); ?></span>
                            <?php else : ?>
                                <span style="color:#B4690E;font-weight:600;"><?php esc_html_e( 'New', 'smart-chat-ai' ); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="post" style="display:inline;">
                                <?php wp_nonce_field( 'scai_cb_status', '_scai_cb_nonce' ); ?>
                                <input type="hidden" name="cb_id" value="<?php echo esc_attr( $r->id ); ?>">
                                <?php if ( 'done' === $r->status ) : ?>
                                    <button class="button button-small" name="scai_cb_action" value="mark_new"><?php esc_html_e( 'Reopen', 'smart-chat-ai' ); ?></button>
                                <?php else : ?>
                                    <button class="button button-small button-primary" name="scai_cb_action" value="mark_done"><?php esc_html_e( 'Mark Done', 'smart-chat-ai' ); ?></button>
                                <?php endif; ?>
                                <button class="button button-small" name="scai_cb_action" value="delete" onclick="return confirm('<?php echo esc_js( __( 'Delete this request?', 'smart-chat-ai' ) ); ?>');"><?php esc_html_e( 'Delete', 'smart-chat-ai' ); ?></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
