<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SCAI_Analytics {

    public function get_stats( $days = 30 ) {
        global $wpdb;
        $convos_table = $wpdb->prefix . 'smart_chat_conversations';
        $callbacks_table = $wpdb->prefix . 'smart_chat_callbacks';

        $start = gmdate( 'Y-m-d', strtotime( "-{$days} days" ) );

        $total_conversations = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(DISTINCT session_id) FROM {$convos_table} WHERE created_at >= %s", $start // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

        $total_messages = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$convos_table} WHERE created_at >= %s", $start // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

        $total_tokens = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(SUM(tokens_used), 0) FROM {$convos_table} WHERE created_at >= %s AND sender = 'ai'", $start // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

        $total_callbacks = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$callbacks_table} WHERE created_at >= %s", $start // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

        return array(
            'total_conversations' => $total_conversations,
            'total_messages'      => $total_messages,
            'total_tokens'        => $total_tokens,
            'total_callbacks'     => $total_callbacks,
        );
    }
}
